<?php
$page_title = 'Careers & Driver Opportunities | Ashwini Logistics Solutions';
$page_description = 'Join the Ashwini Logistics team. We offer rewarding career opportunities across fleet management, operations, route planning, driver roles and commercial logistics.';
$current_page = 'career';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero">
<div class="wrap">
<span class="mini-label">CAREERS AT ASHWINI LOGISTICS</span>
<h1>The people behind<br><b>every successful mile.</b></h1>
<p class="hero-sub">We believe our drivers, operations desk and field teams are the foundation of our 3-decade reputation for reliability. Join a team built on respect, safety and long-term growth.</p>
</div>
</section>

<section class="section">
<div class="wrap">
<div class="why-grid" style="margin-bottom: 60px;">
    <article>
        <span class="reason-number">01</span>
        <svg class="icon"><use href="#i-shield"/></svg>
        <h3>Safety &amp; Well-being First</h3>
        <p>Driver safety training, regular health screenings, standardized driving hours and comprehensive vehicle maintenance ensure peace of mind on the road.</p>
    </article>
    <article>
        <span class="reason-number">02</span>
        <svg class="icon"><use href="#i-truck"/></svg>
        <h3>Modern 500+ Fleet</h3>
        <p>Operate and coordinate top-tier modern vehicles equipped with Gtropy GPS telematics, cabin comfort and predictive maintenance systems.</p>
    </article>
    <article>
        <span class="reason-number">03</span>
        <svg class="icon"><use href="#i-globe"/></svg>
        <h3>Pan-India Network</h3>
        <p>18+ branch hubs across major industrial corridors and ports provide clear advancement paths and multi-regional logistics exposure.</p>
    </article>
    <article>
        <span class="reason-number">04</span>
        <svg class="icon"><use href="#i-check"/></svg>
        <h3>Timely Compensation</h3>
        <p>Prompt salary settlements, attractive performance incentives, trip bonuses and stable career progression backed by 30+ years of trust.</p>
    </article>
</div>

<!-- Open Positions -->
<div style="margin-bottom: 60px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; flex-wrap: wrap; gap: 16px;">
        <div>
            <span class="mini-label">CURRENT OPENINGS</span>
            <h2 style="font-size: 28px; margin: 0; color: #102a38;">Explore Available Roles</h2>
        </div>
        <p style="color: #57606a; margin: 0;">Positions open across Maharashtra, Gujarat, Delhi NCR, and Southern Corridors.</p>
    </div>

    <div style="display: flex; flex-direction: column; gap: 16px;">
        <div style="background: #ffffff; border: 1px solid #e1e4e8; border-radius: 8px; padding: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="font-size: 12px; color: #ff6a00; font-weight: 700; text-transform: uppercase;">Fleet &amp; Logistics</span>
                <h3 style="margin: 4px 0 8px; font-size: 18px; color: #102a38;">Heavy Commercial Vehicle (HCV) Drivers</h3>
                <p style="margin: 0; color: #57606a; font-size: 14px;">Locations: Navi Mumbai, Bhiwandi, Chennai, Ahmedabad | Experience: 3+ years with valid Heavy Transport License</p>
            </div>
            <a href="contact.php?role=hcv-driver" class="button orange" style="padding: 10px 20px; font-size: 14px;">Apply Now <svg class="icon"><use href="#i-ne"/></svg></a>
        </div>

        <div style="background: #ffffff; border: 1px solid #e1e4e8; border-radius: 8px; padding: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="font-size: 12px; color: #ff6a00; font-weight: 700; text-transform: uppercase;">Operations</span>
                <h3 style="margin: 4px 0 8px; font-size: 18px; color: #102a38;">Hub Operations Executive / Dispatcher</h3>
                <p style="margin: 0; color: #57606a; font-size: 14px;">Locations: JNPT Belapur, Bhiwandi, Bengaluru | Experience: 2–5 years in FTL dispatching and CTYF/ERP documentation</p>
            </div>
            <a href="contact.php?role=operations-executive" class="button orange" style="padding: 10px 20px; font-size: 14px;">Apply Now <svg class="icon"><use href="#i-ne"/></svg></a>
        </div>

        <div style="background: #ffffff; border: 1px solid #e1e4e8; border-radius: 8px; padding: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="font-size: 12px; color: #ff6a00; font-weight: 700; text-transform: uppercase;">Commercial &amp; Key Accounts</span>
                <h3 style="margin: 4px 0 8px; font-size: 18px; color: #102a38;">Logistics Key Account Manager</h3>
                <p style="margin: 0; color: #57606a; font-size: 14px;">Location: CBD Belapur, Navi Mumbai | Experience: 4+ years in B2B corporate freight, warehousing or automotive logistics</p>
            </div>
            <a href="contact.php?role=key-account-manager" class="button orange" style="padding: 10px 20px; font-size: 14px;">Apply Now <svg class="icon"><use href="#i-ne"/></svg></a>
        </div>

        <div style="background: #ffffff; border: 1px solid #e1e4e8; border-radius: 8px; padding: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <span style="font-size: 12px; color: #ff6a00; font-weight: 700; text-transform: uppercase;">Maintenance</span>
                <h3 style="margin: 4px 0 8px; font-size: 18px; color: #102a38;">Fleet Maintenance Engineer / Workshop Supervisor</h3>
                <p style="margin: 0; color: #57606a; font-size: 14px;">Location: Panvel Workshop Facility | Experience: 5+ years in commercial vehicle overhaul, preventive schedules and tyre care</p>
            </div>
            <a href="contact.php?role=fleet-engineer" class="button orange" style="padding: 10px 20px; font-size: 14px;">Apply Now <svg class="icon"><use href="#i-ne"/></svg></a>
        </div>
    </div>
</div>

<!-- Send Resume Callout -->
<div style="background: #102a38; color: #ffffff; border-radius: 12px; padding: 40px; text-align: center;">
    <h3 style="color: #ffffff; font-size: 24px; margin-bottom: 12px;">Don’t see your exact role listed?</h3>
    <p style="color: #cbd5e1; max-width: 600px; margin: 0 auto 24px; font-size: 15px;">We are always looking for passionate logistics professionals, dispatch planners and transport coordinators. Send your resume directly to our HR team.</p>
    <a href="mailto:careers@ashwinilogistics.in?subject=Career%20Application%20-%20Ashwini%20Logistics" class="button orange" style="display: inline-flex; align-items: center; gap: 8px;">
        <span>Email Your Resume to careers@ashwinilogistics.in</span>
        <svg class="icon"><use href="#i-mail"/></svg>
    </a>
</div>

</div>
</section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
