<?php
$page_title = "Our Clients | Trusted by India’s Leading Brands — Ashwini Logistics";
$page_description = "Breweries, FMCG, telecom, manufacturing and shipping majors have run their supply chains on ALS — many for decades.";
$current_page = "clients";
require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-clients.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> OUR CLIENTS</div>
<h1>Relationships built<br><em>through the work we do.</em></h1>
<p>Ashwini supports businesses across breweries, FMCG, manufacturing, telecom and logistics. These relationships reflect the range of cargo and operating requirements our teams have worked with.</p>
<a class="button orange" href="contact.php">Discuss a logistics partnership <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>
<section class="clients section"><div class="wrap">
<div class="clients-heading"><div><div class="eyebrow"><span></span> SELECTED CLIENT REFERENCES</div><h2>Good company.<br>For the long run.</h2></div><p>Selected references by sector.<br>Full reference list on request.</p></div>
<div class="logo-wall">
<div class="sector-label">BREWERIES &amp; BEVERAGES</div>
<div class="logo-grid">
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/carlsberg.png" alt="Carlsberg" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/ab-inbev.svg" alt="AB InBev" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/varun-beverages.png" alt="Varun Beverages" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/hindustan-coca-cola.svg" alt="Hindustan Coca-Cola Beverages" loading="lazy"></figure>
</div>
<div class="sector-label">CHEMICALS, FMCG &amp; MANUFACTURING</div>
<div class="logo-grid">
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/kogta.png" alt="Kogta Import Export" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/galaxy-surfactants.png" alt="Galaxy Surfactants" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/sree-rayalaseema.png" alt="Sree Rayalaseema Hi-Strength Hypo" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/deccan-fine.png" alt="Deccan Fine Chemicals" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/cosmo-first.svg" alt="Cosmo First" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/garware.png" alt="Garware Hi-Tech Films" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/visaka.png" alt="Visaka Industries" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/ifb.png" alt="IFB Industries" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/canpack.svg" alt="Canpack India" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/supreme.png" alt="The Supreme Industries" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/polynova.jpg" alt="Polynova Industries" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/bajaj-auto.png" alt="Bajaj Auto" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/bkt-tyres.png" alt="BKT Tyres" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/ceat-tyres.png" alt="CEAT Tyres" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/goodyear-tyres.png" alt="Goodyear Tyres" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/nhk-bearings.png" alt="NHK Bearings" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/motherson-sumi.png" alt="Motherson Sumi" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/uflex.png" alt="Uflex Ltd" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/relaxo.png" alt="Relaxo" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/jubilant.png" alt="Jubilant" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/harman-finochem.png" alt="Harman Finochem" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/marksan-pharma.png" alt="Marksans Pharma" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/jain-irrigation.png" alt="Jain Irrigation Systems Ltd" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/jain-farm-fresh.png" alt="Jain Farm Fresh Foods" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/mega-pipes.png" alt="Mega Pipes" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/duraline.png" alt="Dura-Line" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/dlink.png" alt="D-Link" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/nlmk.png" alt="NLMK" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/ivl-dhunseri.png" alt="IVL Dhunseri" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/detmold-group.png" alt="Detmold Group" loading="lazy"></figure>
</div>
<div class="sector-label">LOGISTICS &amp; SHIPPING</div>
<div class="logo-grid">
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/infinity-ocean.png" alt="Infinity Ocean Line" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/chakiat.png" alt="Chakiat Agencies" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/issgf.png" alt="ISSGF India" loading="lazy"></figure>
<figure class="logo-card"><img src="<?php echo $base_path; ?>assets/images/logos/tristar.png" alt="Tristar International" loading="lazy"></figure>
</div>
</div>
<div class="client-foot"><span>A SELECTION — FULL REFERENCE LIST ON REQUEST</span><a class="text-link" href="contact.php">Build a lasting partnership <svg class="icon"><use href="#i-ne"/></svg></a></div>
</div></section>
<section class="logistics-refs section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> LOGISTICS RELATIONSHIPS</div><h2>Logistics and<br><span>shipping references.</span></h2></div><p>Working alongside the majors —<br>ports, lanes and container freight.</p></div>
<div class="ref-row ref-marquee"><div class="marquee-track">
<div class="marquee-set">
<figure class="m-logo"><img src="../assets/logos/dhl.svg" alt="DHL" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/maersk.png" alt="Maersk" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/jeena.png" alt="Jeena &amp; Company" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/msc.svg" alt="MSC" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/oocl.svg" alt="OOCL" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/agility.svg" alt="Agility" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/cmacgm.svg" alt="CMA CGM" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/nyk.svg" alt="NYK Line" loading="lazy"></figure>
</div>
<div class="marquee-set" aria-hidden="true">
<figure class="m-logo"><img src="../assets/logos/dhl.svg" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/maersk.png" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/jeena.png" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/msc.svg" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/oocl.svg" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/agility.svg" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/cmacgm.svg" alt="" loading="lazy"></figure>
<figure class="m-logo"><img src="../assets/logos/nyk.svg" alt="" loading="lazy"></figure>
</div>
</div></div>
</section>
<section class="stories section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> CUSTOMER STORIES</div><h2>Stories we’re<br>getting right.</h2></div><p>Every operation has<br>its own pressures.</p></div>
<div class="stories-copy">
<p>Every operation has its own pressures. Our customer stories will explain the requirement, the scope Ashwini handled and the result the client can substantiate.</p>
<p class="stories-note">A useful story needs a named or anonymised customer, dates, approved scope and evidence for the outcome.</p>
</div>
</div></section>
<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Join the<br><em>list.</em></h2><p>The shortest route to this wall<br>is one kept delivery.</p></div><a class="button orange" href="contact.php">Start the conversation <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
