<?php
$page_title = "Get a Quote | Ashwini Logistics Solutions";
$page_description = "Tell us what needs to move. Share your transport, warehousing, freight or project cargo requirement — our team responds within one business day. Helpdesk Mon–Sat, 10:00–19:00.";
$current_page = "contact";
require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-contact.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> GET A QUOTE</div>
<h1>Tell us what<br><em>needs to move.</em></h1>
<p>One shipment or a continuing logistics requirement, our team can help you assess the next step. Share the details below and select the service you need so we can understand your cargo and the scope of support.</p>
</div></section>
<section class="contact contact-light section"><div class="wrap contact-grid">
<div class="contact-copy">
<div class="eyebrow light"><span></span> TALK TO A TEAM THAT PICKS UP</div>
<h2>Five service lines.<br><em>One call.</em></h2>
<p>Tell us your cargo, your route and your timeline.<br>We respond within one business day.</p>
<a class="contact-phone" href="tel:+912****2345">+91 22 4031 2345 <svg class="icon"><use href="#i-ne"/></svg></a>
<span class="office-hours">Helpdesk: Mon–Sat, 10:00–19:00 IST</span>
<a class="contact-email" href="mailto:info@ashwinilogistics.in">info@ashwinilogistics.in <svg class="icon"><use href="#i-ne"/></svg></a>

</div>
<form id="enquiry-form" class="enquiry-form" action="<?php echo $base_path; ?>mail_handler.php" method="POST">
<input type="text" name="website_hp" style="display:none !important;" tabindex="-1" autocomplete="off">
<div class="form-title"><h3>Every great move<br>starts with a conversation.</h3><span>↗</span></div>
<div class="form-grid">
<div class="field"><label for="name">Your name <span>*</span></label><input id="name" name="name" autocomplete="name" placeholder="Full name" required maxlength="100"></div>
<div class="field"><label for="company">Company</label><input id="company" name="company" autocomplete="organization" placeholder="Company name" maxlength="160"></div>
<div class="field"><label for="email">Business email <span>*</span></label><input id="email" type="email" name="email" autocomplete="email" placeholder="you@company.com" required maxlength="200"></div>
<div class="field"><label for="phone">Phone number <span>*</span></label><input id="phone" type="tel" name="phone" autocomplete="tel" placeholder="Your contact number" required pattern="[+0-9 \(\)\-]{7,25}" title="Enter a phone number using 7–25 digits, spaces, +, brackets or hyphens." maxlength="25"></div>
<div class="field full"><label for="service">Service needed <span>*</span></label><select id="service" name="service" required>
<option value="">Select a service</option>
<option value="Road Transport / Logistics">Road transport / Logistics</option>
<option value="Warehousing">Warehousing</option>
<option value="Freight Forwarding & Customs">Freight forwarding &amp; customs</option>
<option value="ODC & Project Cargo">ODC &amp; project cargo</option>
<option value="Containerised Cargo">Containerised cargo</option>
<option value="Tanker Transport">Tanker transport</option>
<option value="Other">Something else</option>
</select></div>
</div>
<div class="service-fields">
<div class="svc-fields" data-service="Road Transport / Logistics" hidden>
<div class="field"><label for="t-origin">Origin <span>*</span></label><input id="t-origin" name="transport_origin" placeholder="Pickup city / point" maxlength="120"></div>
<div class="field"><label for="t-dest">Destination <span>*</span></label><input id="t-dest" name="transport_destination" placeholder="Drop city / point" maxlength="120"></div>
<div class="field"><label for="t-cargo">Cargo <span>*</span></label><input id="t-cargo" name="transport_cargo" placeholder="What moves" maxlength="160"></div>
<div class="field"><label for="t-weight">Approx. weight</label><input id="t-weight" name="transport_weight" placeholder="e.g. 9 MT" maxlength="60"></div>
<div class="field"><label for="t-volume">Load volume</label><input id="t-volume" name="transport_volume" placeholder="e.g. 1 x 32ft / 15 pallets" maxlength="60"></div>
<div class="field"><label for="t-dispatch">Dispatch date</label><input id="t-dispatch" name="transport_dispatch" type="date"></div>
<div class="field"><label for="t-frequency">Recurring frequency</label><select id="t-frequency" name="transport_frequency"><option value="">Select</option><option>One-off</option><option>Weekly</option><option>Fortnightly</option><option>Monthly</option><option>Daily route</option></select></div>
</div>
<div class="svc-fields" data-service="Warehousing" hidden>
<div class="field"><label for="w-location">Preferred location <span>*</span></label><input id="w-location" name="warehouse_location" placeholder="City / area" maxlength="120"></div>
<div class="field"><label for="w-cargo">Cargo <span>*</span></label><input id="w-cargo" name="warehouse_cargo" placeholder="What is stored" maxlength="160"></div>
<div class="field"><label for="w-quantity">Storage quantity <span>*</span></label><input id="w-quantity" name="warehouse_quantity" placeholder="e.g. 600 pallets / 2,000 sq ft" maxlength="80"></div>
<div class="field"><label for="w-duration">Duration</label><input id="w-duration" name="warehouse_duration" placeholder="e.g. 3 months" maxlength="80"></div>
<div class="field"><label for="w-handling">Handling needs</label><input id="w-handling" name="warehouse_handling" placeholder="Stacking, picking, temp control…" maxlength="200"></div>
</div>
<div class="svc-fields" data-service="Freight Forwarding & Customs" hidden>
<div class="field"><label for="f-origin">Origin country / city <span>*</span></label><input id="f-origin" name="freight_origin" placeholder="e.g. Jebel Ali, UAE" maxlength="120"></div>
<div class="field"><label for="f-dest">Destination country / city <span>*</span></label><input id="f-dest" name="freight_destination" placeholder="e.g. Nhava Sheva, India" maxlength="120"></div>
<div class="field"><label for="f-weight">Weight</label><input id="f-weight" name="freight_weight" placeholder="e.g. 18 MT" maxlength="60"></div>
<div class="field"><label for="f-dimensions">Dimensions</label><input id="f-dimensions" name="freight_dimensions" placeholder="L × W × H, or container count" maxlength="120"></div>
<div class="field"><label for="f-mode">Mode preference</label><select id="f-mode" name="freight_mode"><option value="">Select</option><option>Sea FCL</option><option>Sea LCL</option><option>Air</option><option>No preference — advise me</option></select></div>
<div class="field"><label for="f-date">Shipping date</label><input id="f-date" name="freight_date" type="date"></div>
</div>
<div class="svc-fields" data-service="ODC & Project Cargo" hidden>
<div class="field"><label for="p-dimensions">Dimensions <span>*</span></label><input id="p-dimensions" name="project_dimensions" placeholder="L × W × H per unit" maxlength="120"></div>
<div class="field"><label for="p-weight">Weight <span>*</span></label><input id="p-weight" name="project_weight" placeholder="e.g. 42 MT" maxlength="60"></div>
<div class="field"><label for="p-route">Route <span>*</span></label><input id="p-route" name="project_route" placeholder="Origin to destination" maxlength="200"></div>
<div class="field"><label for="p-schedule">Schedule</label><input id="p-schedule" name="project_schedule" placeholder="Target window" maxlength="120"></div>
<div class="field full"><label for="p-drawings">Drawings or photographs</label><input id="p-drawings" name="project_drawings" placeholder="Note: attach files when you send the email" maxlength="200"></div>
</div>
</div>
<div class="form-grid">
<div class="field full"><label for="message">Requirement summary <span>*</span></label><textarea id="message" name="message" rows="3" placeholder="Your cargo, your route, your timeline…" required maxlength="3000"></textarea></div>
</div>
<div class="form-submit"><button class="button orange" type="submit">Send your enquiry <svg class="icon"><use href="#i-ne"/></svg></button><span>Your details stay private — no spam, no sharing, ever. Just a real conversation about your cargo.</span></div>
<p class="form-status" id="form-status" hidden></p>
<button class="copy-enquiry" id="copy-enquiry" type="button" hidden>Copy enquiry text</button>
</form>
</div></section>

<section class="map-band" id="find-us">
<div class="map-info">
<span class="eyebrow light"><span></span> FIND US</span>
<h2>Our corporate office.</h2>
<address>
B701, 702 &amp; 703, Shelton Sapphire,<br>
Plot No. 18 &amp; 19, near Sessions Court,<br>
Sector 15, CBD Belapur,<br>
Navi Mumbai, Maharashtra 400614
</address>
<div class="map-contact-rows">
<a href="tel:+912****2345"><svg class="icon"><use href="#i-phone"/></svg> +91 22 4031 2345</a>
<a href="mailto:info@ashwinilogistics.in"><svg class="icon"><use href="#i-mail"/></svg> info@ashwinilogistics.in</a>
</div>
<a class="button orange" href="https://www.google.com/maps/search/?api=1&query=Shelton+Sapphire+Sector+15+CBD+Belapur+Navi+Mumbai" target="_blank" rel="noopener noreferrer">Get directions <svg class="icon"><use href="#i-ne"/></svg></a>
</div>
<div class="map-frame">
<iframe title="Ashwini Logistics Solutions — corporate office map" src="https://www.google.com/maps?q=Shelton%20Sapphire%2C%20Sector%2015%2C%20CBD%20Belapur%2C%20Navi%20Mumbai%2C%20Maharashtra%20400614&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
</div>
</section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
