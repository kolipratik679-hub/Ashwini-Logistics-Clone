<?php
require_once __DIR__ . '/config.php';

if (!isset($base_path)) {
    $base_path = file_exists('includes/header.php') ? './' : '../';
}

if (!isset($page_title)) {
    $page_title = 'Ashwini Logistics Solutions | Reliability, Delivered.';
}

if (!isset($page_description)) {
    $page_description = 'Move your business forward with Ashwini Logistics Solutions. 500+ owned vehicles, 18+ branches across India, 3+ decades of experience and global warehousing.';
}

if (!isset($current_page)) {
    $current_page = 'home';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#102a38">
<title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></title>
<meta name="description" content="<?php echo htmlspecialchars($page_description, ENT_QUOTES, 'UTF-8'); ?>">
<link rel="icon" href="<?php echo $base_path; ?>assets/images/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/fonts.css?v=20261018c">
<link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css?v=20261018c">
<link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/pages.css?v=20261018c">
<link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/solutions.css?v=20261018c">
<?php if (!empty($extra_css)): ?>
<?php echo $extra_css; ?>
<?php endif; ?>
<script src="<?php echo $base_path; ?>assets/js/script.js?v=20261018c" defer></script>
<?php if (!empty($extra_js)): ?>
<?php echo $extra_js; ?>
<?php endif; ?>
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>

<!-- Inline SVG Sprites Library -->
<svg class="svg-library" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><defs>
<symbol id="i-ne" viewBox="0 0 24 24"><path d="M6 18 18 6M6 6h12v12"/></symbol>
<symbol id="i-pin" viewBox="0 0 24 24"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></symbol>
<symbol id="i-phone" viewBox="0 0 24 24"><path d="m7 3 3 5-3 3a15 15 0 0 0 6 6l3-3 5 3c0 3-2 5-5 4C8 19 3 14 2 7c0-3 2-5 5-4Z"/></symbol>
<symbol id="i-check" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></symbol>
<symbol id="i-shield" viewBox="0 0 24 24"><path d="m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6l9-4Z"/><path d="m7 12 3 3 6-6"/></symbol>
<symbol id="i-box" viewBox="0 0 24 24"><path d="m12 2 10 5v10l-10 5-10-5V7l10-5Zm0 10v10M2 7l10 5 10-5M7 4.5l10 5V15"/></symbol>
<symbol id="i-globe" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><ellipse cx="12" cy="12" rx="4" ry="10"/><path d="M2 12h20"/></symbol>
<symbol id="i-truck" viewBox="0 0 24 24"><path d="M1 5h14v12H1V5Zm14 4h4l4 5v3h-8M16 9v5h7"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="18" r="2"/></symbol>
<symbol id="i-mail" viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="1"/><path d="m2 5 10 8L22 5"/></symbol>
<symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
<symbol id="i-anchor" viewBox="0 0 24 24"><circle cx="12" cy="5" r="2.5"/><path d="M12 7.5V22M12 22a8 8 0 0 1-8-8h3.5M12 22a8 8 0 0 0 8-8h-3.5M5 11h14"/></symbol>
<symbol id="i-warehouse" viewBox="0 0 24 24"><path d="m3 9 9-6 9 6v12H3V9Z"/><path d="M7 21v-8h10v8M7 17h10M10 13v4M14 13v4"/></symbol>
</defs></svg>

<!-- Utility Top Bar -->
<div class="utility"><div class="wrap"><span><span class="status-dot"></span> PAN-INDIA STRENGTH. GLOBAL POSSIBILITIES.</span><a href="tel:<?php echo CONTACT_PHONE_RAW; ?>">Let’s talk logistics <b><?php echo CONTACT_PHONE; ?></b> <svg class="icon"><use href="#i-ne"/></svg></a></div></div>

<!-- Main Site Header -->
<header class="header">
<div class="wrap nav-wrap">
<a class="brand" href="<?php echo $base_path; ?>index.php" aria-label="Ashwini Logistics Solutions home"><img class="brand-logo" src="<?php echo $base_path; ?>assets/images/logo.svg" alt="Ashwini Logistics Solutions" width="150" height="56"></a>
<button class="menu-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="navigation"><span></span><span></span></button>
<nav id="navigation" aria-label="Main navigation">
<a href="<?php echo $base_path; ?>index.php" class="<?php echo ($current_page === 'home') ? 'active' : ''; ?>" <?php echo ($current_page === 'home') ? 'aria-current="page"' : ''; ?>>Home</a>
<div class="nav-drop">
<button class="nav-drop-btn <?php echo (strpos($current_page, 'solutions') !== false || $current_page === 'services') ? 'active' : ''; ?>" type="button" aria-expanded="false" aria-controls="solutions-menu">Our solutions <svg class="icon nav-drop-chev" aria-hidden="true"><use href="#i-plus"/></svg></button>
<div class="nav-drop-menu" id="solutions-menu">
<a class="drop-all <?php echo ($current_page === 'services') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>services.php">All solutions</a>
<a class="<?php echo ($current_page === 'pan-india-transport') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/pan-india-transport.php">Pan-India Transport</a>
<a class="<?php echo ($current_page === 'global-warehousing') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/global-warehousing.php">Global Warehousing</a>
<a class="<?php echo ($current_page === 'freight-forwarding-customs') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/freight-forwarding-customs.php">Freight Forwarding &amp; Customs</a>
<a class="<?php echo ($current_page === 'odc-project-cargo') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/odc-project-cargo.php">ODC &amp; Project Cargo</a>
<a class="<?php echo ($current_page === 'containerised-cargo') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/containerised-cargo.php">Containerised Cargo</a>
<a class="<?php echo ($current_page === 'tanker-transport') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>solutions/tanker-transport.php">Tanker Transport</a>
</div>
</div>
<a href="<?php echo $base_path; ?>fleet.php" class="<?php echo ($current_page === 'fleet') ? 'active' : ''; ?>">Fleet &amp; Infrastructure</a>
<a href="<?php echo $base_path; ?>about.php" class="<?php echo ($current_page === 'about') ? 'active' : ''; ?>">About us</a>
<a href="<?php echo $base_path; ?>network.php" class="<?php echo ($current_page === 'network') ? 'active' : ''; ?>">Our network</a>
<a href="<?php echo $base_path; ?>clients.php" class="<?php echo ($current_page === 'clients') ? 'active' : ''; ?>">Our clients</a>
<a href="<?php echo $base_path; ?>career.php" class="<?php echo ($current_page === 'career') ? 'active' : ''; ?>">Careers</a>
<a class="nav-track <?php echo ($current_page === 'tracking') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>tracking.php"><svg class="icon"><use href="#i-pin"/></svg> Track shipment</a>
<a class="nav-quote <?php echo ($current_page === 'contact') ? 'active' : ''; ?>" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a>
</nav>
</div>
</header>
