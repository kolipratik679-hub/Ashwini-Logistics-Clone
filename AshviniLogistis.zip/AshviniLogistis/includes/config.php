<?php
/**
 * Ashwini Logistics Solutions - Configuration File
 */

// Define Environment & Base URL
if (!defined('BASE_URL')) {
    // Dynamic detection of HTTP scheme and host
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    // If inside solutions/ subfolder, strip /solutions
    $projectDir = preg_replace('/\/solutions$/i', '', $scriptDir);
    define('BASE_URL', rtrim($protocol . $host . $projectDir, '/') . '/');
}

// Company Contact Info
define('SITE_NAME', 'Ashwini Logistics Solutions');
define('SITE_TAGLINE', 'Reliability, Delivered.');
define('CONTACT_PHONE', '+91 22 4031 2345');
define('CONTACT_PHONE_RAW', '+912240312345');
define('CONTACT_EMAIL', 'info@ashwinilogistics.in');
define('TRACKING_EMAIL', 'tracking@ashwinilogistics.in');
define('OFFICE_ADDRESS', 'Shelton Sapphire, CBD Belapur, Navi Mumbai, Maharashtra 400614, India');

// Tracking Configuration (CTYF ERP Portal & Gtropy Fleet GPS)
define('CTYF_PORTAL_URL', 'https://ctyf.co.in/SiteLogin.aspx');
define('GTROPY_PORTAL_URL', 'https://gtropy.com');

// Mailer / SMTP Configuration
// Change MAIL_DRIVER to 'smtp' if using remote SMTP credentials (Gmail, SendGrid, Zoho, etc.)
define('MAIL_DRIVER', 'mail'); // 'mail' or 'smtp'
define('SMTP_HOST', 'smtp.ashwinilogistics.in');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // 'tls' or 'ssl'
define('SMTP_USER', 'info@ashwinilogistics.in');
define('SMTP_PASS', 'your_smtp_password_here');
define('MAIL_FROM_ADDRESS', 'noreply@ashwinilogistics.in');
define('MAIL_FROM_NAME', 'Ashwini Logistics Website');
define('MAIL_TO_ADDRESS', 'info@ashwinilogistics.in');

// Enquiry Log File Path (ensures zero lost leads even when mail server is offline)
define('ENQUIRY_LOG_FILE', __DIR__ . '/../data/enquiries.json');
define('ENQUIRY_CSV_FILE', __DIR__ . '/../data/enquiries.csv');
