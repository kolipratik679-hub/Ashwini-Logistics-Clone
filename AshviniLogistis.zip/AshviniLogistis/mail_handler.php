<?php
/**
 * Ashwini Logistics Solutions - Contact & Quote Form Mailer Handler
 */

require_once __DIR__ . '/includes/config.php';

header('Content-Type: application/json; charset=UTF-8');

// Ensure data folder exists
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// Only accept POST requests
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method. Only POST is allowed.'
    ]);
    exit;
}

// Anti-spam honeypot check (field named 'website_hp')
if (!empty($_POST['website_hp'])) {
    // Bot detected, silently fake success
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for your enquiry. We will get back to you shortly.'
    ]);
    exit;
}

// Sanitize and extract inputs from $_POST
$name    = htmlspecialchars(trim($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
$company = htmlspecialchars(trim($_POST['company'] ?? ''), ENT_QUOTES, 'UTF-8') ?: 'Not provided';
$rawEmail= trim($_POST['email'] ?? '');
$email   = filter_var($rawEmail, FILTER_VALIDATE_EMAIL);
$phone   = htmlspecialchars(trim($_POST['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
$service = htmlspecialchars(trim($_POST['service'] ?? ''), ENT_QUOTES, 'UTF-8');
$message = htmlspecialchars(trim($_POST['message'] ?? ''), ENT_QUOTES, 'UTF-8');

// Validate required fields
$errors = [];
if (empty($name))    $errors[] = 'Your name is required.';
if (empty($email))   $errors[] = 'A valid business email address is required.';
if (empty($phone))   $errors[] = 'A contact phone number is required.';
if (empty($service)) $errors[] = 'Please select a logistics service.';
if (empty($message)) $errors[] = 'Requirement summary cannot be blank.';

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => implode(' ', $errors),
        'errors'  => $errors
    ]);
    exit;
}

// Extract service-specific details
$serviceDetails = [];
switch ($service) {
    case 'Road Transport / Logistics':
        $serviceDetails['Origin']           = htmlspecialchars(trim($_POST['transport_origin'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Destination']      = htmlspecialchars(trim($_POST['transport_destination'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Cargo']            = htmlspecialchars(trim($_POST['transport_cargo'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Approx Weight']    = htmlspecialchars(trim($_POST['transport_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Load Volume']      = htmlspecialchars(trim($_POST['transport_volume'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Dispatch Date']    = htmlspecialchars(trim($_POST['transport_dispatch'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Frequency']        = htmlspecialchars(trim($_POST['transport_frequency'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'Warehousing':
        $serviceDetails['Preferred Location'] = htmlspecialchars(trim($_POST['warehouse_location'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Cargo Stored']       = htmlspecialchars(trim($_POST['warehouse_cargo'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Storage Quantity']   = htmlspecialchars(trim($_POST['warehouse_quantity'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Duration']           = htmlspecialchars(trim($_POST['warehouse_duration'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Handling Needs']     = htmlspecialchars(trim($_POST['warehouse_handling'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'Freight Forwarding & Customs':
        $serviceDetails['Origin Country/City']      = htmlspecialchars(trim($_POST['freight_origin'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Destination Country/City'] = htmlspecialchars(trim($_POST['freight_destination'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Weight']                   = htmlspecialchars(trim($_POST['freight_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Dimensions / Containers']  = htmlspecialchars(trim($_POST['freight_dimensions'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Mode Preference']          = htmlspecialchars(trim($_POST['freight_mode'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Target Shipping Date']     = htmlspecialchars(trim($_POST['freight_date'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'ODC & Project Cargo':
        $serviceDetails['Dimensions (L×W×H)'] = htmlspecialchars(trim($_POST['project_dimensions'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Unit Weight']         = htmlspecialchars(trim($_POST['project_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Route']               = htmlspecialchars(trim($_POST['project_route'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Schedule Window']     = htmlspecialchars(trim($_POST['project_schedule'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Drawings / Specs']    = htmlspecialchars(trim($_POST['project_drawings'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    default:
        break;
}

// Generate Enquiry Reference Code
$refId = 'ALS-' . strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $service), 0, 3)) . '-' . date('Ymd') . '-' . rand(1000, 9999);
$timestamp = date('Y-m-d H:i:s');
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

// Assemble complete record for storage
$record = [
    'ref_id'          => $refId,
    'timestamp'       => $timestamp,
    'client_ip'       => $clientIp,
    'name'            => $name,
    'company'         => $company,
    'email'           => $email,
    'phone'           => $phone,
    'service'         => $service,
    'service_details' => $serviceDetails,
    'message'         => $message
];

// 1. Save to JSON database
$allEnquiries = [];
if (file_exists(ENQUIRY_LOG_FILE)) {
    $existing = file_get_contents(ENQUIRY_LOG_FILE);
    $decoded = json_decode($existing, true);
    if (is_array($decoded)) {
        $allEnquiries = $decoded;
    }
}
$allEnquiries[] = $record;
file_put_contents(ENQUIRY_LOG_FILE, json_encode($allEnquiries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

// 2. Append to CSV for easy Excel export
$csvRow = [
    $refId,
    $timestamp,
    $name,
    $company,
    $email,
    $phone,
    $service,
    json_encode($serviceDetails),
    $message,
    $clientIp
];
$isNewCsv = !file_exists(ENQUIRY_CSV_FILE);
$fp = fopen(ENQUIRY_CSV_FILE, 'a');
if ($fp) {
    if ($isNewCsv) {
        fputcsv($fp, ['Ref ID', 'Timestamp', 'Name', 'Company', 'Email', 'Phone', 'Service', 'Service Specs', 'Requirement Message', 'IP Address']);
    }
    fputcsv($fp, $csvRow);
    fclose($fp);
}

// 3. Compose Email
$emailSubject = "New Logistics Enquiry [$refId] - $company ($name)";
$emailBodyText = "New Logistics Enquiry Received\n";
$emailBodyText .= "Reference: $refId\nDate: $timestamp\n";
$emailBodyText .= "Name: $name\nCompany: $company\nEmail: $email\nPhone: $phone\nService: $service\n";
if (!empty($serviceDetails)) {
    $emailBodyText .= "\n--- Specific Requirements ---\n";
    foreach ($serviceDetails as $k => $v) {
        $emailBodyText .= "$k: $v\n";
    }
}
$emailBodyText .= "\n--- Requirement Summary ---\n$message\n";

$emailBodyHtml = "
<div style='font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;'>
    <div style='background: #102a38; color: #ffffff; padding: 20px;'>
        <h2 style='margin: 0; color: #ff6a00;'>Ashwini Logistics Solutions</h2>
        <p style='margin: 5px 0 0; color: #d0d7de;'>New Quote &amp; Service Request | Ref: <strong>$refId</strong></p>
    </div>
    <div style='padding: 24px; background: #ffffff; color: #24292f;'>
        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px;'>Customer Information</h3>
        <table style='width: 100%; border-collapse: collapse; margin-bottom: 20px;'>
            <tr><td style='padding: 8px; width: 35%; font-weight: bold; background: #f6f8fa;'>Name:</td><td style='padding: 8px;'>$name</td></tr>
            <tr><td style='padding: 8px; font-weight: bold; background: #f6f8fa;'>Company:</td><td style='padding: 8px;'>$company</td></tr>
            <tr><td style='padding: 8px; font-weight: bold; background: #f6f8fa;'>Email:</td><td style='padding: 8px;'><a href='mailto:$email'>$email</a></td></tr>
            <tr><td style='padding: 8px; font-weight: bold; background: #f6f8fa;'>Phone:</td><td style='padding: 8px;'><a href='tel:$phone'>$phone</a></td></tr>
            <tr><td style='padding: 8px; font-weight: bold; background: #f6f8fa;'>Selected Service:</td><td style='padding: 8px;'><strong>$service</strong></td></tr>
        </table>
";

if (!empty($serviceDetails)) {
    $emailBodyHtml .= "<h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px;'>Specifications</h3><table style='width: 100%; border-collapse: collapse; margin-bottom: 20px;'>";
    foreach ($serviceDetails as $k => $v) {
        $emailBodyHtml .= "<tr><td style='padding: 8px; width: 35%; font-weight: bold; background: #f6f8fa;'>$k:</td><td style='padding: 8px;'>" . htmlspecialchars($v) . "</td></tr>";
    }
    $emailBodyHtml .= "</table>";
}

$emailBodyHtml .= "
        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px;'>Requirement Summary</h3>
        <div style='background: #f6f8fa; padding: 15px; border-radius: 4px; border-left: 4px solid #ff6a00; white-space: pre-wrap;'>" . nl2br($message) . "</div>
    </div>
    <div style='background: #f1f3f5; padding: 12px 20px; font-size: 12px; color: #6e7781;'>
        Received on $timestamp from IP: $clientIp | Ashwini Logistics Solutions Website Portal
    </div>
</div>";

// Send email using PHP mail()
$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=UTF-8\r\n";
$headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
$headers .= "Reply-To: $name <$email>\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

$mailSent = @mail(MAIL_TO_ADDRESS, $emailSubject, $emailBodyHtml, $headers);

// Also send automated customer acknowledgement
$ackSubject = "We have received your enquiry [$refId] — Ashwini Logistics Solutions";
$ackHtml = "
<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px;'>
    <div style='background: #102a38; color: #ffffff; padding: 20px;'>
        <h2 style='margin: 0; color: #ff6a00;'>Ashwini Logistics Solutions</h2>
        <p style='margin: 5px 0 0; color: #d0d7de;'>Reliability, Delivered.</p>
    </div>
    <div style='padding: 24px; color: #333;'>
        <p>Dear <strong>$name</strong>,</p>
        <p>Thank you for reaching out to Ashwini Logistics Solutions regarding <strong>$service</strong>.</p>
        <p>Your enquiry reference number is: <strong style='color: #ff6a00; font-size: 16px;'>$refId</strong>.</p>
        <p>Our commercial desk and operations team are reviewing your requirements and will contact you shortly with a personalized quotation and movement plan.</p>
        <br>
        <p><strong>Ashwini Logistics Solutions Head Office</strong><br>
        Shelton Sapphire, CBD Belapur, Navi Mumbai<br>
        Direct Desk: " . CONTACT_PHONE . "<br>
        Email: " . CONTACT_EMAIL . "</p>
    </div>
</div>";
$ackHeaders  = "MIME-Version: 1.0\r\n";
$ackHeaders .= "Content-type: text/html; charset=UTF-8\r\n";
$ackHeaders .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
$ackHeaders .= "X-Mailer: PHP/" . phpversion();

@mail($email, $ackSubject, $ackHtml, $ackHeaders);

// Respond to front-end
echo json_encode([
    'success' => true,
    'ref_id'  => $refId,
    'message' => 'Thank you! Your logistics enquiry has been recorded successfully. Our team will contact you shortly. Reference: ' . $refId,
    'mail_sent' => $mailSent
]);
