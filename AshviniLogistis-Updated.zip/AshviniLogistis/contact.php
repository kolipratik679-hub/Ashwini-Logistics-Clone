<?php
$page_title = "Contact & Careers | Ashwini Logistics Solutions";
$page_description = "Request a freight quote or apply for driver, fleet management and operations positions at Ashwini Logistics Solutions. Helpdesk Mon–Sat, 10:00–19:00 IST.";
$current_page = "contact";
require_once __DIR__ . '/includes/header.php';

$activeTab = ($_GET['tab'] ?? '') === 'career' || !empty($_GET['role']) ? 'career' : 'quote';
$preselectedRole = strtolower(trim($_GET['role'] ?? ''));
$sourceSection = htmlspecialchars($_GET['source_section'] ?? 'Contact Page', ENT_QUOTES, 'UTF-8');
$sourceButton  = htmlspecialchars($_GET['source_button'] ?? 'Direct Navigation', ENT_QUOTES, 'UTF-8');
?>

<main id="main">
<section class="page-hero photo-hero">
<img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-contact.jpg" alt="" aria-hidden="true">
<div class="hero-veil"></div>
<div class="wrap">
<div class="eyebrow light"><span></span> GET IN TOUCH &amp; JOIN OUR TEAM</div>
<h1>Tell us what<br><em>needs to move.</em></h1>
<p>One shipment, a long-term logistics contract, or joining our 500+ fleet and operations team. Select the relevant form below to connect directly with the right department.</p>
</div>
</section>

<section class="contact contact-light section" id="contact-section">
<div class="wrap contact-grid">

<!-- Left Column: Company Contact Information -->
<div class="contact-copy">
<div class="eyebrow light"><span></span> TALK TO A TEAM THAT PICKS UP</div>
<h2>Five service lines.<br><em>One call.</em></h2>
<p>Tell us your cargo, your route and your timeline.<br>We respond within one business day.</p>
<a class="contact-phone" href="tel:<?php echo CONTACT_PHONE_RAW; ?>"><?php echo CONTACT_PHONE; ?> <svg class="icon"><use href="#i-ne"/></svg></a>
<span class="office-hours">Helpdesk: Mon–Sat, 10:00–19:00 IST</span>
<a class="contact-email" href="mailto:<?php echo CONTACT_EMAIL; ?>"><?php echo CONTACT_EMAIL; ?> <svg class="icon"><use href="#i-ne"/></svg></a>

<div style="margin-top: 36px; padding: 22px; background: #ffffff; border: 1px solid #e1e4e8; border-radius: 8px;">
    <span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: #ff6a00; text-transform: uppercase;">Direct Contact Points</span>
    <ul style="list-style: none; padding: 0; margin: 12px 0 0; font-size: 14.5px; color: #334155; line-height: 1.8;">
        <li><strong>Commercial &amp; FTL Desk:</strong> <?php echo CONTACT_PHONE; ?></li>
        <li><strong>Fleet GPS Telematics Desk:</strong> <?php echo CONTACT_PHONE; ?></li>
        <li><strong>HR &amp; Driver Recruitment:</strong> careers@ashwinilogistics.in</li>
        <li><strong>Corporate Office:</strong> Shelton Sapphire, CBD Belapur, Navi Mumbai</li>
    </ul>
</div>
</div>

<!-- Right Column: Interactive Dual Form (Quote Form & Career Form) -->
<div class="contact-form-wrapper" style="position: relative;">

    <!-- Top Tab Selector -->
    <div class="form-mode-tabs" role="tablist" style="display: flex; gap: 8px; background: #eef2f5; padding: 6px; border-radius: 8px; margin-bottom: 20px; box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);">
        <button type="button" id="tab-btn-quote" role="tab" aria-selected="<?php echo ($activeTab === 'quote') ? 'true' : 'false'; ?>" 
                onclick="switchContactTab('quote')"
                style="flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 16px; border: none; border-radius: 6px; font-weight: 700; font-size: 15px; cursor: pointer; transition: all 0.2s; <?php echo ($activeTab === 'quote') ? 'background: #102a38; color: #ffffff; box-shadow: 0 2px 6px rgba(0,0,0,0.15);' : 'background: transparent; color: #57606a;'; ?>">
            <svg class="icon" style="width: 17px; height: 17px;"><use href="#i-mail"/></svg>
            <span>Service Quote / Enquiry</span>
        </button>
        <button type="button" id="tab-btn-career" role="tab" aria-selected="<?php echo ($activeTab === 'career') ? 'true' : 'false'; ?>" 
                onclick="switchContactTab('career')"
                style="flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 16px; border: none; border-radius: 6px; font-weight: 700; font-size: 15px; cursor: pointer; transition: all 0.2s; <?php echo ($activeTab === 'career') ? 'background: #102a38; color: #ffffff; box-shadow: 0 2px 6px rgba(0,0,0,0.15);' : 'background: transparent; color: #57606a;'; ?>">
            <svg class="icon" style="width: 17px; height: 17px;"><use href="#i-truck"/></svg>
            <span>Career Application</span>
        </button>
    </div>

    <!-- FORM 1: SERVICE QUOTE / ENQUIRY FORM -->
    <form id="enquiry-form" class="enquiry-form" action="<?php echo $base_path; ?>mail_handler.php" method="POST" style="<?php echo ($activeTab === 'quote') ? 'display: block;' : 'display: none;'; ?>">
        <input type="hidden" name="form_type" value="quote_enquiry">
        <input type="hidden" name="source_section" id="quote-source-section" value="<?php echo $sourceSection; ?>">
        <input type="hidden" name="source_button" id="quote-source-button" value="<?php echo $sourceButton; ?>">
        <input type="text" name="website_hp" style="display:none !important;" tabindex="-1" autocomplete="off">
        
        <div class="form-title">
            <h3>Every great move<br>starts with a conversation.</h3>
            <span>↗</span>
        </div>
        
        <div class="form-grid">
            <div class="field"><label for="name">Your name <span>*</span></label><input id="name" name="name" autocomplete="name" placeholder="Full name" required maxlength="100"></div>
            <div class="field"><label for="company">Company</label><input id="company" name="company" autocomplete="organization" placeholder="Company name" maxlength="160"></div>
            <div class="field"><label for="email">Business email <span>*</span></label><input id="email" type="email" name="email" autocomplete="email" placeholder="you@company.com" required maxlength="200"></div>
            <div class="field"><label for="phone">Phone number <span>*</span></label><input id="phone" type="tel" name="phone" autocomplete="tel" placeholder="Your contact number" required pattern="[+0-9 \(\)\-]{7,25}" title="Enter a phone number using 7–25 digits, spaces, +, brackets or hyphens." maxlength="25"></div>
            <div class="field full"><label for="service">Service needed <span>*</span></label>
                <select id="service" name="service" required>
                    <option value="">Select a service</option>
                    <option value="Road Transport / Logistics">Road transport / Logistics (FTL / PTL)</option>
                    <option value="Warehousing">Warehousing &amp; Distribution</option>
                    <option value="Freight Forwarding & Customs">Freight forwarding &amp; customs</option>
                    <option value="ODC & Project Cargo">ODC &amp; project cargo</option>
                    <option value="Containerised Cargo">Containerised cargo</option>
                    <option value="Tanker Transport">Tanker transport</option>
                    <option value="Other">Something else</option>
                </select>
            </div>
        </div>

        <div class="service-fields">
            <div class="svc-fields" data-service="Road Transport / Logistics" hidden>
                <div class="field"><label for="t-origin">Origin <span>*</span></label><input id="t-origin" name="transport_origin" placeholder="Pickup city / point" maxlength="120"></div>
                <div class="field"><label for="t-dest">Destination <span>*</span></label><input id="t-dest" name="transport_destination" placeholder="Drop city / point" maxlength="120"></div>
                <div class="field"><label for="t-cargo">Cargo <span>*</span></label><input id="t-cargo" name="transport_cargo" placeholder="What moves" maxlength="160"></div>
                <div class="field"><label for="t-weight">Approx. weight</label><input id="t-weight" name="transport_weight" placeholder="e.g. 24 MT" maxlength="60"></div>
                <div class="field"><label for="t-volume">Load volume</label><input id="t-volume" name="transport_volume" placeholder="e.g. 1 x 32ft / 15 pallets" maxlength="60"></div>
                <div class="field"><label for="t-dispatch">Dispatch date</label><input id="t-dispatch" name="transport_dispatch" type="date"></div>
                <div class="field"><label for="t-frequency">Recurring frequency</label><select id="t-frequency" name="transport_frequency"><option value="">Select</option><option>One-off</option><option>Weekly</option><option>Fortnightly</option><option>Monthly</option><option>Daily route</option></select></div>
            </div>
            <div class="svc-fields" data-service="Warehousing" hidden>
                <div class="field"><label for="w-location">Preferred location <span>*</span></label><input id="w-location" name="warehouse_location" placeholder="City / area" maxlength="120"></div>
                <div class="field"><label for="w-cargo">Cargo <span>*</span></label><input id="w-cargo" name="warehouse_cargo" placeholder="What is stored" maxlength="160"></div>
                <div class="field"><label for="w-quantity">Storage quantity <span>*</span></label><input id="w-quantity" name="warehouse_quantity" placeholder="e.g. 600 pallets / 2,000 sq ft" maxlength="80"></div>
                <div class="field"><label for="w-duration">Duration</label><input id="w-duration" name="warehouse_duration" placeholder="e.g. 3 months" maxlength="80"></div>
                <div class="field"><label for="w-handling">Handling needs</label><input id="w-handling" name="warehouse_handling" placeholder="Stacking, picking, temp control…" maxlength="200"></div>
            </div>
            <div class="svc-fields" data-service="Freight Forwarding & Customs" hidden>
                <div class="field"><label for="f-origin">Origin country / city <span>*</span></label><input id="f-origin" name="freight_origin" placeholder="e.g. Jebel Ali, UAE" maxlength="120"></div>
                <div class="field"><label for="f-dest">Destination country / city <span>*</span></label><input id="f-dest" name="freight_destination" placeholder="e.g. Nhava Sheva, India" maxlength="120"></div>
                <div class="field"><label for="f-weight">Weight</label><input id="f-weight" name="freight_weight" placeholder="e.g. 18 MT" maxlength="60"></div>
                <div class="field"><label for="f-dimensions">Dimensions</label><input id="f-dimensions" name="freight_dimensions" placeholder="L × W × H, or container count" maxlength="120"></div>
                <div class="field"><label for="f-mode">Mode preference</label><select id="f-mode" name="freight_mode"><option value="">Select</option><option>Sea FCL</option><option>Sea LCL</option><option>Air</option><option>No preference — advise me</option></select></div>
                <div class="field"><label for="f-date">Shipping date</label><input id="f-date" name="freight_date" type="date"></div>
            </div>
            <div class="svc-fields" data-service="ODC & Project Cargo" hidden>
                <div class="field"><label for="p-dimensions">Dimensions <span>*</span></label><input id="p-dimensions" name="project_dimensions" placeholder="L × W × H per unit" maxlength="120"></div>
                <div class="field"><label for="p-weight">Weight <span>*</span></label><input id="p-weight" name="project_weight" placeholder="e.g. 42 MT" maxlength="60"></div>
                <div class="field"><label for="p-route">Route <span>*</span></label><input id="p-route" name="project_route" placeholder="Origin to destination" maxlength="200"></div>
                <div class="field"><label for="p-schedule">Schedule</label><input id="p-schedule" name="project_schedule" placeholder="Target window" maxlength="120"></div>
                <div class="field full"><label for="p-drawings">Drawings or photographs</label><input id="p-drawings" name="project_drawings" placeholder="Note: describe specs or mention if attaching" maxlength="200"></div>
            </div>
        </div>

        <div class="form-grid">
            <div class="field full"><label for="message">Requirement summary <span>*</span></label><textarea id="message" name="message" rows="3" placeholder="Your cargo, your route, your timeline…" required maxlength="3000"></textarea></div>
        </div>

        <div class="form-submit">
            <button class="button orange" type="submit" id="quote-submit-btn">Send your enquiry <svg class="icon"><use href="#i-ne"/></svg></button>
            <span>Your details stay private — no spam, no sharing, ever. Just a real conversation about your cargo.</span>
        </div>
        <p class="form-status" id="form-status" hidden></p>
        <button class="copy-enquiry" id="copy-enquiry" type="button" hidden>Copy enquiry text</button>
    </form>

    <!-- FORM 2: CAREER APPLICATION FORM (WITH RESUME UPLOAD) -->
    <form id="career-form" class="enquiry-form" action="<?php echo $base_path; ?>mail_handler.php" method="POST" enctype="multipart/form-data" style="<?php echo ($activeTab === 'career') ? 'display: block;' : 'display: none;'; ?>">
        <input type="hidden" name="form_type" value="career_application">
        <input type="hidden" name="source_section" id="career-source-section" value="<?php echo $sourceSection; ?>">
        <input type="hidden" name="source_button" id="career-source-button" value="<?php echo $sourceButton; ?>">
        <input type="text" name="website_hp" style="display:none !important;" tabindex="-1" autocomplete="off">

        <div class="form-title" style="margin-bottom: 12px;">
            <div>
                <span class="mini-label" style="font-size: 11px; margin-bottom: 4px; display: inline-block;">JOIN OUR TEAM</span>
                <h3 style="margin: 0;">Career Application —<br>Build your future with us.</h3>
            </div>
            <span>↗</span>
        </div>
        <p style="color: #64748b; font-size: 14.5px; margin: 0 0 20px; line-height: 1.5;">Apply for fleet driving, hub operations, warehouse management or commercial freight careers across our 18+ pan-India network.</p>

        <div class="form-grid">
            <div class="field">
                <label for="c-name">Full Name <span>*</span></label>
                <input id="c-name" name="full_name" autocomplete="name" placeholder="Your complete name" required maxlength="100">
            </div>
            <div class="field">
                <label for="c-phone">Phone Number <span>*</span></label>
                <input id="c-phone" type="tel" name="phone" autocomplete="tel" placeholder="e.g. +91 98200 12345" required pattern="[+0-9 \(\)\-]{7,25}" title="Enter a valid contact phone number." maxlength="25">
            </div>
            <div class="field">
                <label for="c-email">Email Address <span>*</span></label>
                <input id="c-email" type="email" name="email" autocomplete="email" placeholder="you@example.com" required maxlength="200">
            </div>
            <div class="field">
                <label for="c-role">Position Applied For <span>*</span></label>
                <select id="c-role" name="job_role" required>
                    <option value="">Select a position</option>
                    <option value="Heavy Commercial Vehicle (HCV) Driver" <?php echo ($preselectedRole === 'hcv-driver') ? 'selected' : ''; ?>>Heavy Commercial Vehicle (HCV) Driver</option>
                    <option value="Hub Operations Executive / Dispatcher" <?php echo ($preselectedRole === 'operations-executive') ? 'selected' : ''; ?>>Hub Operations Executive / Dispatcher</option>
                    <option value="Logistics Key Account Manager" <?php echo ($preselectedRole === 'key-account-manager') ? 'selected' : ''; ?>>Logistics Key Account Manager</option>
                    <option value="Fleet Maintenance Engineer / Workshop Supervisor" <?php echo ($preselectedRole === 'fleet-engineer') ? 'selected' : ''; ?>>Fleet Maintenance Engineer / Workshop Supervisor</option>
                    <option value="Fleet Coordinator / GPS Telematics Officer">Fleet Coordinator / GPS Telematics Officer</option>
                    <option value="Warehouse Inventory Executive">Warehouse Inventory Executive</option>
                    <option value="Port &amp; CFS Logistics Officer">Port &amp; CFS Logistics Officer</option>
                    <option value="Other Logistics / Transport Role" <?php echo ($preselectedRole === 'other') ? 'selected' : ''; ?>>Other Logistics / Transport Role</option>
                </select>
            </div>
            <div class="field">
                <label for="c-exp">Years of Experience <span>*</span></label>
                <select id="c-exp" name="experience" required>
                    <option value="">Select experience</option>
                    <option value="Fresher / Less than 1 Year">Fresher / Less than 1 Year</option>
                    <option value="1 – 3 Years">1 – 3 Years</option>
                    <option value="3 – 5 Years" selected>3 – 5 Years</option>
                    <option value="5 – 8 Years">5 – 8 Years</option>
                    <option value="8+ Years / Senior Level">8+ Years / Senior Level</option>
                </select>
            </div>
            <div class="field">
                <label for="c-location">Preferred Work Location / Hub <span>*</span></label>
                <select id="c-location" name="preferred_location" required>
                    <option value="">Select location</option>
                    <option value="Navi Mumbai / CBD Belapur (Head Office)">Navi Mumbai / CBD Belapur (Head Office)</option>
                    <option value="JNPT / Nhava Sheva Hub">JNPT / Nhava Sheva Hub</option>
                    <option value="Bhiwandi Logistics Corridor">Bhiwandi Logistics Corridor</option>
                    <option value="Ahmedabad / Gujarat Depot">Ahmedabad / Gujarat Depot</option>
                    <option value="Chennai Port Hub">Chennai Port Hub</option>
                    <option value="Bengaluru Industrial Area">Bengaluru Industrial Area</option>
                    <option value="Delhi NCR / Neemrana">Delhi NCR / Neemrana</option>
                    <option value="Other Pan-India Branch">Other Pan-India Branch</option>
                </select>
            </div>
            <div class="field full">
                <label for="c-license">Commercial Driving License / Badge Details (if applying for Driver/Fleet)</label>
                <input id="c-license" name="driving_license" placeholder="e.g. Heavy Transport License No., Badge validity, etc." maxlength="100">
            </div>

            <!-- Upload Resume Interactive Drag & Drop Box -->
            <div class="field full">
                <label for="career-resume">Upload Resume / CV / Documents (PDF, DOC, DOCX, Max 10MB) <span>*</span></label>
                <input type="file" id="career-resume" name="resume" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg" required style="display: none;">
                <div id="drop-zone" onclick="document.getElementById('career-resume').click()" 
                     style="border: 2px dashed #cbd5e1; border-radius: 8px; padding: 26px 16px; text-align: center; cursor: pointer; background: #f8fafc; transition: all 0.2s;">
                    <svg class="icon" style="width: 34px; height: 34px; margin: 0 auto 8px; color: #ff6a00;"><use href="#i-box"/></svg>
                    <p style="margin: 0; font-size: 15px; font-weight: 700; color: #102a38;">
                        Drag &amp; drop your resume here, or <span style="color: #ff6a00; text-decoration: underline;">browse file</span>
                    </p>
                    <span style="font-size: 12.5px; color: #64748b; display: block; margin-top: 4px;">Supports PDF, DOC, DOCX, JPG, PNG (Max 10MB)</span>
                    <div id="file-info" style="display: none; margin-top: 12px; font-size: 14px; color: #137333; font-weight: 700; background: #e6f4ea; padding: 8px 14px; border-radius: 6px; display: inline-flex; align-items: center; gap: 8px;">
                        <span id="file-name-display"></span> <span id="file-size-display" style="font-weight: normal; color: #57606a;"></span> ✓
                    </div>
                </div>
            </div>

            <div class="field full">
                <label for="c-message">Cover Letter / Experience Summary <span>*</span></label>
                <textarea id="c-message" name="experience_summary" rows="3" placeholder="Briefly describe your driving, fleet coordination, or logistics background..." required maxlength="2500"></textarea>
            </div>
        </div>

        <div class="form-submit">
            <button class="button orange" type="submit" id="career-submit-btn">Submit Career Application <svg class="icon"><use href="#i-ne"/></svg></button>
            <span>Your application and uploaded documents remain strictly confidential with Ashwini Logistics HR.</span>
        </div>
        <p class="form-status" id="career-form-status" hidden></p>
    </form>

</div>
</div>
</section>

<!-- Office Map Section -->
<section class="map-band" id="find-us">
<div class="map-info">
<span class="eyebrow light"><span></span> FIND US</span>
<h2>Our corporate office.</h2>
<address>
B701, 702 &amp; 703, Shelton Sapphire,<br>
Plot No. 18 &amp; 19, near Sessions Court,<br>
Sector 15, CBD Belapur,<br>
Navi Mumbai, Maharashtra 400614
</address>
<div class="map-contact-rows">
<a href="tel:<?php echo CONTACT_PHONE_RAW; ?>"><svg class="icon"><use href="#i-phone"/></svg> <?php echo CONTACT_PHONE; ?></a>
<a href="mailto:<?php echo CONTACT_EMAIL; ?>"><svg class="icon"><use href="#i-mail"/></svg> <?php echo CONTACT_EMAIL; ?></a>
</div>
<a class="button orange" href="https://www.google.com/maps/search/?api=1&query=Shelton+Sapphire+Sector+15+CBD+Belapur+Navi+Mumbai" target="_blank" rel="noopener noreferrer">Get directions <svg class="icon"><use href="#i-ne"/></svg></a>
</div>
<div class="map-frame">
<iframe title="Ashwini Logistics Solutions — corporate office map" src="https://www.google.com/maps?q=Shelton%20Sapphire%2C%20Sector%2015%2C%20CBD%20Belapur%2C%20Navi%20Mumbai%2C%20Maharashtra%20400614&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
</div>
</section>
</main>

<script>
function switchContactTab(tab) {
    const quoteForm = document.getElementById('enquiry-form');
    const careerForm = document.getElementById('career-form');
    const quoteBtn = document.getElementById('tab-btn-quote');
    const careerBtn = document.getElementById('tab-btn-career');

    if (tab === 'career') {
        quoteForm.style.display = 'none';
        careerForm.style.display = 'block';

        quoteBtn.style.background = 'transparent';
        quoteBtn.style.color = '#57606a';
        quoteBtn.style.boxShadow = 'none';
        quoteBtn.setAttribute('aria-selected', 'false');

        careerBtn.style.background = '#102a38';
        careerBtn.style.color = '#ffffff';
        careerBtn.style.boxShadow = '0 2px 6px rgba(0,0,0,0.15)';
        careerBtn.setAttribute('aria-selected', 'true');
    } else {
        careerForm.style.display = 'none';
        quoteForm.style.display = 'block';

        careerBtn.style.background = 'transparent';
        careerBtn.style.color = '#57606a';
        careerBtn.style.boxShadow = 'none';
        careerBtn.setAttribute('aria-selected', 'false');

        quoteBtn.style.background = '#102a38';
        quoteBtn.style.color = '#ffffff';
        quoteBtn.style.boxShadow = '0 2px 6px rgba(0,0,0,0.15)';
        quoteBtn.setAttribute('aria-selected', 'true');
    }
}

// File Drag & Drop + Browse file visual display
const resumeInput = document.getElementById('career-resume');
const dropZone = document.getElementById('drop-zone');
const fileInfo = document.getElementById('file-info');
const fileNameDisplay = document.getElementById('file-name-display');
const fileSizeDisplay = document.getElementById('file-size-display');

if (resumeInput && dropZone) {
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, e => {
            e.preventDefault();
            dropZone.style.borderColor = '#ff6a00';
            dropZone.style.background = '#fff8f2';
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, e => {
            e.preventDefault();
            dropZone.style.borderColor = '#cbd5e1';
            dropZone.style.background = '#f8fafc';
        });
    });

    dropZone.addEventListener('drop', e => {
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            resumeInput.files = e.dataTransfer.files;
            handleFileSelect(e.dataTransfer.files[0]);
        }
    });

    resumeInput.addEventListener('change', () => {
        if (resumeInput.files && resumeInput.files.length > 0) {
            handleFileSelect(resumeInput.files[0]);
        }
    });

    function handleFileSelect(file) {
        fileNameDisplay.textContent = file.name;
        const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
        fileSizeDisplay.textContent = '(' + sizeMb + ' MB)';
        fileInfo.style.display = 'inline-flex';
    }
}

// Career Form AJAX Submission
const careerForm = document.getElementById('career-form');
if (careerForm) {
    const careerStatus = document.getElementById('career-form-status');
    const careerSubmitBtn = document.getElementById('career-submit-btn');

    careerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        if (!careerForm.reportValidity()) return;

        if (careerSubmitBtn) {
            careerSubmitBtn.disabled = true;
            careerSubmitBtn.innerHTML = 'Submitting application... <svg class="icon"><use href="#i-ne"/></svg>';
        }

        const formData = new FormData(careerForm);

        fetch(careerForm.action || 'mail_handler.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (careerSubmitBtn) {
                careerSubmitBtn.disabled = false;
                careerSubmitBtn.innerHTML = 'Submit Career Application <svg class="icon"><use href="#i-ne"/></svg>';
            }
            if (data.success) {
                if (careerStatus) {
                    careerStatus.style.display = 'block';
                    careerStatus.style.background = '#e6f4ea';
                    careerStatus.style.color = '#137333';
                    careerStatus.style.padding = '14px 18px';
                    careerStatus.style.borderRadius = '6px';
                    careerStatus.style.marginTop = '16px';
                    careerStatus.textContent = data.message || 'Thank you! Your career application and resume have been submitted successfully.';
                    careerStatus.hidden = false;
                }
                careerForm.reset();
                if (fileInfo) fileInfo.style.display = 'none';
            } else {
                if (careerStatus) {
                    careerStatus.style.display = 'block';
                    careerStatus.style.background = '#fce8e6';
                    careerStatus.style.color = '#c5221f';
                    careerStatus.style.padding = '14px 18px';
                    careerStatus.style.borderRadius = '6px';
                    careerStatus.style.marginTop = '16px';
                    careerStatus.textContent = data.message || 'An error occurred while submitting your application.';
                    careerStatus.hidden = false;
                }
            }
        })
        .catch(err => {
            console.error('Career form submission error:', err);
            if (careerSubmitBtn) {
                careerSubmitBtn.disabled = false;
                careerSubmitBtn.innerHTML = 'Submit Career Application <svg class="icon"><use href="#i-ne"/></svg>';
            }
            if (careerStatus) {
                careerStatus.style.display = 'block';
                careerStatus.style.background = '#fce8e6';
                careerStatus.style.color = '#c5221f';
                careerStatus.style.padding = '14px 18px';
                careerStatus.style.borderRadius = '6px';
                careerStatus.style.marginTop = '16px';
                careerStatus.textContent = 'Network error. Please email your resume directly to careers@ashwinilogistics.in.';
                careerStatus.hidden = false;
            }
        });
    });
}

// Auto-switch tab if url contains tab=career or role parameter
window.addEventListener('DOMContentLoaded', () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('tab') === 'career' || params.get('role')) {
        switchContactTab('career');
        const contactSec = document.getElementById('contact-section');
        if (contactSec) {
            contactSec.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
});
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
