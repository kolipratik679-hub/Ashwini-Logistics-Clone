<?php
if (!isset($base_path)) {
    $base_path = file_exists('includes/header.php') ? './' : '../';
}
?>
<!-- Main Site Footer -->
<footer>
<div class="wrap footer-top">
<a class="brand footer-brand" href="<?php echo $base_path; ?>index.php" aria-label="Ashwini Logistics Solutions home">
    <img class="brand-logo" src="<?php echo $base_path; ?>assets/images/logo-white.svg" alt="Ashwini Logistics Solutions" width="150" height="56">
</a>
<p>Indian roots. Global horizons.<br><b>Reliability, delivered.</b></p>
<a class="footer-track" href="<?php echo $base_path; ?>tracking.php">
    <svg class="icon"><use href="#i-pin"/></svg> Track your shipment <svg class="icon"><use href="#i-ne"/></svg>
</a>
</div>

<div class="wrap footer-solutions">
<span class="mini-label">SOLUTIONS</span>
<nav aria-label="Solution pages">
<a href="<?php echo $base_path; ?>solutions/pan-india-transport.php">Pan-India Transport</a>
<a href="<?php echo $base_path; ?>solutions/global-warehousing.php">Global Warehousing</a>
<a href="<?php echo $base_path; ?>solutions/freight-forwarding-customs.php">Freight Forwarding &amp; Customs</a>
<a href="<?php echo $base_path; ?>solutions/odc-project-cargo.php">ODC &amp; Project Cargo</a>
<a href="<?php echo $base_path; ?>solutions/containerised-cargo.php">Containerised Cargo</a>
<a href="<?php echo $base_path; ?>solutions/tanker-transport.php">Tanker Transport</a>
</nav>
</div>

<div class="wrap footer-bottom">
<span>© <span id="year"><?php echo date('Y'); ?></span> Ashwini Logistics Solutions. All rights reserved.</span>
<nav aria-label="Footer navigation">
<a href="<?php echo $base_path; ?>about.php">About us</a>
<a href="<?php echo $base_path; ?>services.php">Solutions</a>
<a href="<?php echo $base_path; ?>fleet.php">Fleet &amp; Infrastructure</a>
<a href="<?php echo $base_path; ?>network.php">Network</a>
<a href="<?php echo $base_path; ?>clients.php">Clients</a>
<a href="<?php echo $base_path; ?>career.php">Careers</a>
<a href="<?php echo $base_path; ?>tracking.php">Tracking</a>
<a href="<?php echo $base_path; ?>contact.php">Contact</a>
</nav>
<a class="back-top" href="#">BACK TO TOP ↑</a>
</div>
</footer>

<script>document.getElementById("year").textContent = new Date().getFullYear();</script>
<script>
if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  document.querySelectorAll(".hero-bg").forEach(function(v){ v.pause(); v.removeAttribute("autoplay"); });
}
</script>
</body>
</html>
