'use strict';
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('#navigation');
function closeMenu() { if (!nav || !menuButton) return; nav.classList.remove('open'); menuButton.setAttribute('aria-expanded', 'false'); menuButton.setAttribute('aria-label', 'Open menu'); }
if (menuButton && nav) {
  menuButton.addEventListener('click', () => { const open = menuButton.getAttribute('aria-expanded') !== 'true'; nav.classList.toggle('open', open); menuButton.setAttribute('aria-expanded', String(open)); menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu'); });
  nav.addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && nav.classList.contains('open')) { closeMenu(); menuButton.focus(); } });
  document.addEventListener('click', e => { if (!e.target.closest('.header')) closeMenu(); });
  window.matchMedia('(min-width: 851px)').addEventListener('change', e => { if (e.matches) closeMenu(); });
}

const fleet = {
  trucks: { code: '01 / ROAD TRANSPORT', kicker: 'THE EVERYDAY ENGINE OF INDUSTRY', title: 'Big on capacity.\nPersonal on commitment.', copy: 'Full-truckload or part-load, our trucks connect businesses across India. Flexible road transport backed by an owned fleet and people who know your route.', pills: ['Full-truckload', 'Part-load', 'Pan-India routes'], service: 'Logistics', link: 'Find your transport solution' },
  containers: { code: '02 / CONTAINERISED CARGO', kicker: 'PROTECTION FROM ORIGIN TO DESTINATION', title: 'Sealed for the journey.\nReady for the road.', copy: 'Containerised movement for sensitive and high-value freight. Sealed, tracked and transported door to door, with the accountability of our own fleet behind every shipment.', pills: ['Sealed movement', 'Door-to-door', 'Vehicle tracking'], service: 'Containerised Cargo', link: 'Plan your container movement' },
  tankers: { code: '03 / TANKER TRANSPORT', kicker: 'A FLEET BUILT FOR DIFFERENT NEEDS', title: 'Your cargo requirement.\nThe right conversation.', copy: 'Tanker transport is part of our pan-India fleet offering. Share your cargo, route and handling requirements with our team so we can discuss the right vehicle for your movement.', pills: ['Tanker fleet', 'Route planning', 'Dedicated enquiry'], service: 'Tankers', link: 'Discuss your tanker requirement' }
};
const fleetTabs = [...document.querySelectorAll('[data-fleet]')];
if (fleetTabs.length) {
  function selectFleet(key) {
    const data = fleet[key];
    fleetTabs.forEach(tab => { const active = tab.dataset.fleet === key; tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1; const v = document.querySelector('#vehicle-' + tab.dataset.fleet); if (v) v.toggleAttribute('hidden', !active); });
    const fp = document.querySelector('#fleet-panel'); if (fp) fp.setAttribute('aria-labelledby', 'tab-' + key);
    const vi = document.querySelector('#vehicle-illustration'); if (vi) vi.setAttribute('aria-label', 'Illustration of a ' + (key === 'tankers' ? 'tanker truck' : key === 'containers' ? 'container truck' : 'freight truck'));
    const vc = document.querySelector('#vehicle-code'); if (vc) vc.textContent = data.code;
    const fk = document.querySelector('#fleet-kicker'); if (fk) fk.textContent = data.kicker;
    const title = document.querySelector('#fleet-title'); 
    if (title) {
      title.replaceChildren();
      data.title.split('\n').forEach((line, i) => { if (i) title.append(document.createElement('br')); title.append(document.createTextNode(line)); });
    }
    const fc = document.querySelector('#fleet-copy'); if (fc) fc.textContent = data.copy;
    const fpills = document.querySelector('#fleet-pills'); 
    if (fpills) fpills.replaceChildren(...data.pills.map(text => { const span = document.createElement('span'); span.textContent = text; return span; }));
    const link = document.querySelector('#fleet-enquiry'); 
    if (link) { link.firstChild.textContent = data.link + ' '; link.dataset.service = data.service; }
  }
  fleetTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectFleet(tab.dataset.fleet));
    tab.addEventListener('keydown', e => {
      let next;
      if (e.key === 'ArrowRight') next = (index + 1) % fleetTabs.length;
      if (e.key === 'ArrowLeft') next = (index - 1 + fleetTabs.length) % fleetTabs.length;
      if (e.key === 'Home') next = 0;
      if (e.key === 'End') next = fleetTabs.length - 1;
      if (next !== undefined) { e.preventDefault(); fleetTabs[next].focus(); selectFleet(fleetTabs[next].dataset.fleet); }
    });
  });
}

const branches = {
  north: ['Delhi', 'Noida', 'Nuh', 'Neemrana', 'Alwar'],
  west: ['Nhava Sheva / JNPT', 'Indore', 'Solapur', 'Pune', 'Wada', 'Aurangabad', 'Lonand', 'Jalgaon', 'Goa', 'Vapi', 'Navi Mumbai', 'Ankleshwar', 'Mundra'],
  south: ['Hyderabad', 'Chennai', 'Bengaluru', 'Kurnool'],
  east: ['Haldia', 'Kolkata']
};
const allBranches = ['Delhi', 'Noida', 'Nuh', 'Neemrana', 'Alwar', 'Nhava Sheva / JNPT', 'Indore', 'Solapur', 'Pune', 'Wada', 'Aurangabad', 'Lonand', 'Jalgaon', 'Goa', 'Vapi', 'Navi Mumbai', 'Ankleshwar', 'Mundra', 'Hyderabad', 'Chennai', 'Bengaluru', 'Kurnool', 'Haldia', 'Kolkata'];
if (document.querySelector('#branch-list')) {
  document.querySelectorAll('[data-region]').forEach(button => button.addEventListener('click', () => {
    const region = button.dataset.region;
    document.querySelectorAll('[data-region]').forEach(b => { const active = b === button; b.classList.toggle('active', active); b.setAttribute('aria-pressed', String(active)); });
    const bl = document.querySelector('#branch-list');
    if (bl) bl.textContent = (region === 'all' ? allBranches : branches[region]).join(' · ');
    document.querySelectorAll('.map-dot-group').forEach(g => g.classList.toggle('dimmed', region !== 'all' && g.dataset.mapRegion !== region));
  }));
}

const yearEl = document.querySelector('#year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* --- Solutions nav dropdown (touch/click + a11y) --- */
document.querySelectorAll('.nav-drop').forEach(drop => {
  const btn = drop.querySelector('.nav-drop-btn');
  if (!btn) return;
  function setOpen(open) { if (open) { document.querySelectorAll('.nav-drop').forEach(other => { if (other !== drop) { other.classList.remove('open'); const otherBtn = other.querySelector('.nav-drop-btn'); if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false'); } }); } drop.classList.toggle('open', open); btn.setAttribute('aria-expanded', String(open)); }
  btn.addEventListener('click', e => { e.preventDefault(); setOpen(btn.getAttribute('aria-expanded') !== 'true'); });
  drop.addEventListener('keydown', e => { if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') { setOpen(false); btn.focus(); } });
  document.addEventListener('click', e => { if (!drop.contains(e.target)) setOpen(false); });
  drop.addEventListener('focusout', e => { if (!drop.contains(e.relatedTarget)) setOpen(false); });
});

/* --- Get a Quote form: per-service fields + PHP AJAX mailer --- */
const enquiryForm = document.querySelector('#enquiry-form');
if (enquiryForm) {
  const serviceSelect = enquiryForm.querySelector('#service');
  const svcPanels = [...enquiryForm.querySelectorAll('.svc-fields')];
  const requiredIn = panel => panel ? [...panel.querySelectorAll('[name]')] : [];
  function syncServiceFields() {
    const val = serviceSelect.value;
    svcPanels.forEach(panel => {
      const show = panel.dataset.service === val;
      panel.hidden = !show;
      requiredIn(panel).forEach(inp => { if (show) inp.setAttribute('required', ''); else inp.removeAttribute('required'); });
    });
  }
  if (serviceSelect) {
    serviceSelect.addEventListener('change', syncServiceFields);
    syncServiceFields();
  }

  const status = enquiryForm.querySelector('#form-status');
  const copyBtn = enquiryForm.querySelector('#copy-enquiry');
  const submitBtn = enquiryForm.querySelector('button[type="submit"]');

  function labelFor(input) {
    const label = enquiryForm.querySelector('label[for="' + input.id + '"]');
    return label ? label.textContent.replace(/\s*\*\s*$/, '').trim() : input.name;
  }

  enquiryForm.addEventListener('submit', function(e) {
    e.preventDefault();
    if (!enquiryForm.reportValidity()) return;

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'Sending enquiry... <svg class="icon"><use href="#i-ne"/></svg>';
    }

    const formData = new FormData(enquiryForm);
    const lines = [];
    enquiryForm.querySelectorAll('input[name], select[name], textarea[name]').forEach(input => {
      if (input.closest('.svc-fields') && input.closest('.svc-fields').hidden) return;
      if (!input.value.trim()) return;
      lines.push(labelFor(input) + ': ' + input.value.trim());
    });
    const summaryText = lines.join('\n');

    fetch(enquiryForm.action || 'mail_handler.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Send your enquiry <svg class="icon"><use href="#i-ne"/></svg>';
      }
      if (data.success) {
        if (status) {
          status.style.display = 'block';
          status.style.background = '#e6f4ea';
          status.style.color = '#137333';
          status.style.padding = '14px 18px';
          status.style.borderRadius = '6px';
          status.style.marginTop = '16px';
          status.textContent = data.message || 'Thank you for sharing your requirement. Our team will review the details and contact you shortly.';
          status.hidden = false;
        }
        if (copyBtn) {
          copyBtn.hidden = false;
          copyBtn.dataset.summary = summaryText;
        }
        enquiryForm.reset();
        if (serviceSelect) syncServiceFields();
      } else {
        if (status) {
          status.style.display = 'block';
          status.style.background = '#fce8e6';
          status.style.color = '#c5221f';
          status.style.padding = '14px 18px';
          status.style.borderRadius = '6px';
          status.style.marginTop = '16px';
          status.textContent = data.message || 'An error occurred while submitting. Please call us directly.';
          status.hidden = false;
        }
      }
    })
    .catch(err => {
      console.error('Submission error:', err);
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Send your enquiry <svg class="icon"><use href="#i-ne"/></svg>';
      }
      // Mailto fallback if network or local server is completely offline
      const body = encodeURIComponent(summaryText);
      const subject = encodeURIComponent('Logistics enquiry — ' + (enquiryForm.querySelector('#company').value.trim() || enquiryForm.querySelector('#name').value.trim()));
      if (status) {
        status.style.display = 'block';
        status.style.background = '#e6f4ea';
        status.style.color = '#137333';
        status.style.padding = '14px 18px';
        status.style.borderRadius = '6px';
        status.style.marginTop = '16px';
        status.textContent = 'Enquiry prepared. Redirecting to your default mail application...';
        status.hidden = false;
      }
      window.location.href = 'mailto:info@ashwinilogistics.in?subject=' + subject + '&body=' + body;
    });
  });

  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const text = copyBtn.dataset.summary || (status ? status.textContent : '');
      const done = () => { copyBtn.textContent = 'Copied ✓'; setTimeout(() => { copyBtn.textContent = 'Copy enquiry text'; }, 2000); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, done);
      else done();
    });
  }
}
