<?php
/**
 * Ashwini Logistics Solutions - Contact, Quote & Career Application Mailer Handler
 * Handles both Quote Enquiries and Career Applications with file attachments and lead origin tracking
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/smtp_mailer.php';

header('Content-Type: application/json; charset=UTF-8');

// Ensure data and uploads folders exist
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}
$uploadsDir = __DIR__ . '/uploads/resumes';
if (!is_dir($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}

// Only accept POST requests
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method. Only POST is allowed.'
    ]);
    exit;
}

// Anti-spam honeypot check (field named 'website_hp')
if (!empty($_POST['website_hp'])) {
    // Bot detected, silently return success
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for your submission. We will get back to you shortly.'
    ]);
    exit;
}

$formType = trim($_POST['form_type'] ?? 'quote_enquiry');
$sourceSection = htmlspecialchars(trim($_POST['source_section'] ?? 'Contact Page'), ENT_QUOTES, 'UTF-8');
$sourceButton  = htmlspecialchars(trim($_POST['source_button'] ?? 'Submit Button'), ENT_QUOTES, 'UTF-8');
$clientIp      = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$timestamp     = date('Y-m-d H:i:s');

/* ==========================================================================
   CASE A: CAREER APPLICATION FORM (WITH RESUME ATTACHMENT)
   ========================================================================== */
if ($formType === 'career_application') {
    $name              = htmlspecialchars(trim($_POST['full_name'] ?? $_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
    $rawEmail          = trim($_POST['email'] ?? '');
    $email             = filter_var($rawEmail, FILTER_VALIDATE_EMAIL);
    $phone             = htmlspecialchars(trim($_POST['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
    $jobRole           = htmlspecialchars(trim($_POST['job_role'] ?? ''), ENT_QUOTES, 'UTF-8');
    $experience        = htmlspecialchars(trim($_POST['experience'] ?? ''), ENT_QUOTES, 'UTF-8');
    $preferredLocation = htmlspecialchars(trim($_POST['preferred_location'] ?? ''), ENT_QUOTES, 'UTF-8');
    $drivingLicense    = htmlspecialchars(trim($_POST['driving_license'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
    $experienceSummary = htmlspecialchars(trim($_POST['experience_summary'] ?? $_POST['message'] ?? ''), ENT_QUOTES, 'UTF-8');

    // Validation
    $errors = [];
    if (empty($name))              $errors[] = 'Your full name is required.';
    if (empty($email))             $errors[] = 'A valid email address is required.';
    if (empty($phone))             $errors[] = 'A contact phone number is required.';
    if (empty($jobRole))           $errors[] = 'Please select the position you are applying for.';
    if (empty($experience))        $errors[] = 'Please specify your years of experience.';
    if (empty($preferredLocation)) $errors[] = 'Please select your preferred work location/hub.';

    // Validate and process uploaded resume file
    $uploadedFile = null;
    $attachments = [];

    if (isset($_FILES['resume']) && $_FILES['resume']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['resume'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Error uploading resume document. Error code: ' . $file['error'];
        } else {
            $maxBytes = 10 * 1024 * 1024; // 10MB
            if ($file['size'] > $maxBytes) {
                $errors[] = 'Uploaded document exceeds maximum allowed size of 10MB.';
            }

            $origName = $file['name'];
            $fileExt = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
            $allowedExts = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

            if (!in_array($fileExt, $allowedExts)) {
                $errors[] = 'Invalid file type. Allowed formats: PDF, DOC, DOCX, JPG, PNG.';
            } else {
                $safeName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', pathinfo($origName, PATHINFO_FILENAME));
                $newFilename = 'Resume_' . date('Ymd_His') . '_' . rand(100, 999) . '_' . substr($safeName, 0, 30) . '.' . $fileExt;
                $destPath = $uploadsDir . '/' . $newFilename;

                $moved = @move_uploaded_file($file['tmp_name'], $destPath);
                if (!$moved && file_exists($file['tmp_name'])) {
                    $moved = @copy($file['tmp_name'], $destPath);
                }

                if ($moved) {
                    $uploadedFile = [
                        'original_name' => $origName,
                        'saved_path'    => $destPath,
                        'file_size'     => $file['size'],
                        'mime_type'     => $file['type'] ?: 'application/octet-stream'
                    ];

                    $attachments[] = [
                        'path' => $destPath,
                        'name' => $origName,
                        'mime' => $uploadedFile['mime_type']
                    ];
                } else {
                    $errors[] = 'Failed to save uploaded resume file on server.';
                }
            }
        }
    } else {
        $errors[] = 'Please upload your resume or qualifications document.';
    }

    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => implode(' ', $errors),
            'errors'  => $errors
        ]);
        exit;
    }

    // Ref ID for Career Application
    $refId = 'ALS-CAR-' . date('Ymd') . '-' . rand(1000, 9999);

    // Save to data/careers.json and data/careers.csv
    $careerRecord = [
        'ref_id'             => $refId,
        'timestamp'          => $timestamp,
        'source_section'     => $sourceSection,
        'source_button'      => $sourceButton,
        'name'               => $name,
        'phone'              => $phone,
        'email'              => $email,
        'job_role'           => $jobRole,
        'experience'         => $experience,
        'preferred_location' => $preferredLocation,
        'driving_license'    => $drivingLicense,
        'resume_file'        => $uploadedFile ? $uploadedFile['original_name'] : 'N/A',
        'experience_summary' => $experienceSummary,
        'client_ip'          => $clientIp
    ];

    $careersJsonFile = $dataDir . '/careers.json';
    $careersCsvFile  = $dataDir . '/careers.csv';

    $allCareers = [];
    if (file_exists($careersJsonFile)) {
        $existing = file_get_contents($careersJsonFile);
        $decoded = json_decode($existing, true);
        if (is_array($decoded)) $allCareers = $decoded;
    }
    $allCareers[] = $careerRecord;
    file_put_contents($careersJsonFile, json_encode($allCareers, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    $isNewCsv = !file_exists($careersCsvFile);
    $fp = fopen($careersCsvFile, 'a');
    if ($fp) {
        if ($isNewCsv) {
            fputcsv($fp, ['Ref ID', 'Timestamp', 'Source Section', 'Source Button', 'Name', 'Phone', 'Email', 'Position', 'Experience', 'Location', 'License', 'Resume File', 'Summary', 'IP Address']);
        }
        fputcsv($fp, [
            $refId,
            $timestamp,
            $sourceSection,
            $sourceButton,
            $name,
            $phone,
            $email,
            $jobRole,
            $experience,
            $preferredLocation,
            $drivingLicense,
            $uploadedFile ? $uploadedFile['original_name'] : 'N/A',
            $experienceSummary,
            $clientIp
        ]);
        fclose($fp);
    }

    // Compose Admin Notification Email
    $emailSubject = "CAREER APPLICATION: $jobRole - $name (From: $sourceSection > $sourceButton) [$refId]";

    $emailBodyText = "New Career Application Received\n";
    $emailBodyText .= "Reference: $refId\nDate: $timestamp\n";
    $emailBodyText .= "Source Section: $sourceSection\nSource Button: $sourceButton\n";
    $emailBodyText .= "Candidate Name: $name\nPhone: $phone\nEmail: $email\n";
    $emailBodyText .= "Position Applied: $jobRole\nExperience: $experience\nPreferred Location: $preferredLocation\n";
    $emailBodyText .= "Commercial License: $drivingLicense\n";
    $emailBodyText .= "Attached Resume: " . ($uploadedFile ? $uploadedFile['original_name'] : 'None') . "\n\n";
    $emailBodyText .= "Experience Summary:\n$experienceSummary\n";

    $emailBodyHtml = "
<div style='font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; border: 1px solid #d0d7de; border-radius: 8px; overflow: hidden; background: #ffffff;'>
    <div style='background: #102a38; color: #ffffff; padding: 22px;'>
        <h2 style='margin: 0; color: #ff6a00; font-size: 20px;'>Ashwini Logistics Solutions — Careers Desk</h2>
        <p style='margin: 6px 0 0; color: #d0d7de; font-size: 14px;'>New Job Application | Ref: <strong>$refId</strong></p>
    </div>
    
    <div style='padding: 24px;'>
        <!-- Lead Origin / Source Callout Banner -->
        <div style='background: #e0f2fe; border-left: 4px solid #0284c7; padding: 14px 18px; margin-bottom: 24px; border-radius: 4px;'>
            <span style='font-size: 11px; text-transform: uppercase; letter-spacing: 0.8px; color: #0369a1; font-weight: bold;'>Application Origin &amp; Button Trigger:</span>
            <div style='margin-top: 6px; font-size: 14px; color: #0c4a6e; line-height: 1.6;'>
                • <strong>Origin Section:</strong> {$sourceSection}<br>
                • <strong>Trigger Button:</strong> {$sourceButton}<br>
                • <strong>Position Applied:</strong> <span style='color: #0284c7; font-weight: bold;'>{$jobRole}</span><br>
                • <strong>Attached Resume:</strong> " . ($uploadedFile ? htmlspecialchars($uploadedFile['original_name']) : 'None') . " (Attached to this email)
            </div>
        </div>

        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px; margin: 0 0 16px; color: #102a38; font-size: 16px;'>Candidate Profile</h3>
        <table style='width: 100%; border-collapse: collapse; margin-bottom: 22px; font-size: 14px;'>
            <tr><td style='padding: 9px 12px; width: 35%; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Full Name:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$name</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Phone Number:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><a href='tel:$phone' style='color: #0969da; font-weight: bold;'>$phone</a></td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Email Address:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><a href='mailto:$email' style='color: #0969da;'>$email</a></td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Position Applied:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><strong style='color: #102a38;'>$jobRole</strong></td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Experience:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$experience</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Preferred Location:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$preferredLocation</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Commercial License:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$drivingLicense</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Resume Document:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8; color: #137333; font-weight: bold;'>" . ($uploadedFile ? htmlspecialchars($uploadedFile['original_name']) : 'None') . " (Attached ✓)</td></tr>
        </table>

        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px; margin: 0 0 12px; color: #102a38; font-size: 16px;'>Experience Summary / Cover Note</h3>
        <div style='background: #f8fafc; padding: 16px; border-radius: 6px; border-left: 4px solid #ff6a00; font-size: 14px; line-height: 1.6; color: #334155; white-space: pre-wrap;'>" . (!empty($experienceSummary) ? nl2br($experienceSummary) : 'No additional note provided.') . "</div>
    </div>
    
    <div style='background: #f1f5f9; padding: 14px 24px; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;'>
        Received on $timestamp | Candidate IP: $clientIp | Ashwini Logistics Solutions Careers System
    </div>
</div>";

    $mailSent = false;
    $smtpError = null;

    if (defined('MAIL_DRIVER') && MAIL_DRIVER === 'smtp') {
        $mailRes = send_smtp_email(
            MAIL_TO_ADDRESS,
            $emailSubject,
            $emailBodyHtml,
            $emailBodyText,
            $email,
            $name,
            $attachments
        );
        $mailSent = $mailRes['success'];
        if (!$mailSent) $smtpError = $mailRes['error'] ?? 'SMTP Error';
    } else {
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
        $headers .= "Reply-To: $name <$email>\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();
        $mailSent = @mail(MAIL_TO_ADDRESS, $emailSubject, $emailBodyHtml, $headers);
    }

    // Candidate Acknowledgement Email
    $ackSubject = "We have received your career application [$refId] — Ashwini Logistics Solutions";
    $ackHtml = "
<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;'>
    <div style='background: #102a38; color: #ffffff; padding: 20px;'>
        <h2 style='margin: 0; color: #ff6a00;'>Ashwini Logistics Solutions</h2>
        <p style='margin: 5px 0 0; color: #d0d7de;'>Human Resources &amp; Fleet Operations</p>
    </div>
    <div style='padding: 24px; color: #333;'>
        <p>Dear <strong>$name</strong>,</p>
        <p>Thank you for applying for the <strong>$jobRole</strong> position at Ashwini Logistics Solutions.</p>
        <p>Your application reference number is: <strong style='color: #ff6a00; font-size: 16px;'>$refId</strong>.</p>
        <p>Our recruitment desk is reviewing your profile and resume. If your experience matches our operational requirements, our team will get in touch with you for the next steps.</p>
        <br>
        <p><strong>Ashwini Logistics Solutions Head Office</strong><br>
        Shelton Sapphire, CBD Belapur, Navi Mumbai<br>
        Careers Desk: careers@ashwinilogistics.in<br>
        Helpline: " . CONTACT_PHONE . "</p>
    </div>
</div>";

    if (defined('MAIL_DRIVER') && MAIL_DRIVER === 'smtp') {
        @send_smtp_email($email, $ackSubject, $ackHtml, "Thank you for applying at Ashwini Logistics. Reference: $refId");
    } else {
        $ackHeaders  = "MIME-Version: 1.0\r\n";
        $ackHeaders .= "Content-type: text/html; charset=UTF-8\r\n";
        $ackHeaders .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
        $ackHeaders .= "X-Mailer: PHP/" . phpversion();
        @mail($email, $ackSubject, $ackHtml, $ackHeaders);
    }

    echo json_encode([
        'success'    => true,
        'form_type'  => 'career_application',
        'ref_id'     => $refId,
        'message'    => 'Thank you! Your career application and resume have been submitted successfully. Our HR team will contact you shortly. Reference: ' . $refId,
        'mail_sent'  => $mailSent,
        'driver'     => defined('MAIL_DRIVER') ? MAIL_DRIVER : 'mail',
        'debug_error'=> $smtpError
    ]);
    exit;
}

/* ==========================================================================
   CASE B: SERVICE QUOTE / LOGISTICS ENQUIRY FORM
   ========================================================================== */
$name    = htmlspecialchars(trim($_POST['name'] ?? ''), ENT_QUOTES, 'UTF-8');
$company = htmlspecialchars(trim($_POST['company'] ?? ''), ENT_QUOTES, 'UTF-8') ?: 'Not provided';
$rawEmail= trim($_POST['email'] ?? '');
$email   = filter_var($rawEmail, FILTER_VALIDATE_EMAIL);
$phone   = htmlspecialchars(trim($_POST['phone'] ?? ''), ENT_QUOTES, 'UTF-8');
$service = htmlspecialchars(trim($_POST['service'] ?? ''), ENT_QUOTES, 'UTF-8');
$message = htmlspecialchars(trim($_POST['message'] ?? ''), ENT_QUOTES, 'UTF-8');

// Validate required fields
$errors = [];
if (empty($name))    $errors[] = 'Your name is required.';
if (empty($email))   $errors[] = 'A valid business email address is required.';
if (empty($phone))   $errors[] = 'A contact phone number is required.';
if (empty($service)) $errors[] = 'Please select a logistics service.';
if (empty($message)) $errors[] = 'Requirement summary cannot be blank.';

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => implode(' ', $errors),
        'errors'  => $errors
    ]);
    exit;
}

// Extract service-specific details
$serviceDetails = [];
switch ($service) {
    case 'Road Transport / Logistics':
        $serviceDetails['Origin']           = htmlspecialchars(trim($_POST['transport_origin'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Destination']      = htmlspecialchars(trim($_POST['transport_destination'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Cargo']            = htmlspecialchars(trim($_POST['transport_cargo'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Approx Weight']    = htmlspecialchars(trim($_POST['transport_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Load Volume']      = htmlspecialchars(trim($_POST['transport_volume'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Dispatch Date']    = htmlspecialchars(trim($_POST['transport_dispatch'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Frequency']        = htmlspecialchars(trim($_POST['transport_frequency'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'Warehousing':
        $serviceDetails['Preferred Location'] = htmlspecialchars(trim($_POST['warehouse_location'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Cargo Stored']       = htmlspecialchars(trim($_POST['warehouse_cargo'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Storage Quantity']   = htmlspecialchars(trim($_POST['warehouse_quantity'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Duration']           = htmlspecialchars(trim($_POST['warehouse_duration'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Handling Needs']     = htmlspecialchars(trim($_POST['warehouse_handling'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'Freight Forwarding & Customs':
        $serviceDetails['Origin Country/City']      = htmlspecialchars(trim($_POST['freight_origin'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Destination Country/City'] = htmlspecialchars(trim($_POST['freight_destination'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Weight']                   = htmlspecialchars(trim($_POST['freight_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Dimensions / Containers']  = htmlspecialchars(trim($_POST['freight_dimensions'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Mode Preference']          = htmlspecialchars(trim($_POST['freight_mode'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Target Shipping Date']     = htmlspecialchars(trim($_POST['freight_date'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    case 'ODC & Project Cargo':
        $serviceDetails['Dimensions (L×W×H)'] = htmlspecialchars(trim($_POST['project_dimensions'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Unit Weight']         = htmlspecialchars(trim($_POST['project_weight'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Route']               = htmlspecialchars(trim($_POST['project_route'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Schedule Window']     = htmlspecialchars(trim($_POST['project_schedule'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        $serviceDetails['Drawings / Specs']    = htmlspecialchars(trim($_POST['project_drawings'] ?? 'N/A'), ENT_QUOTES, 'UTF-8');
        break;
    default:
        break;
}

// Generate Enquiry Reference Code
$refId = 'ALS-REQ-' . strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $service), 0, 3)) . '-' . date('Ymd') . '-' . rand(1000, 9999);

$record = [
    'ref_id'          => $refId,
    'timestamp'       => $timestamp,
    'source_section'  => $sourceSection,
    'source_button'   => $sourceButton,
    'client_ip'       => $clientIp,
    'name'            => $name,
    'company'         => $company,
    'email'           => $email,
    'phone'           => $phone,
    'service'         => $service,
    'service_details' => $serviceDetails,
    'message'         => $message
];

// Save to data/enquiries.json and data/enquiries.csv
$allEnquiries = [];
if (file_exists(ENQUIRY_LOG_FILE)) {
    $existing = file_get_contents(ENQUIRY_LOG_FILE);
    $decoded = json_decode($existing, true);
    if (is_array($decoded)) $allEnquiries = $decoded;
}
$allEnquiries[] = $record;
file_put_contents(ENQUIRY_LOG_FILE, json_encode($allEnquiries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

$isNewCsv = !file_exists(ENQUIRY_CSV_FILE);
$fp = fopen(ENQUIRY_CSV_FILE, 'a');
if ($fp) {
    if ($isNewCsv) {
        fputcsv($fp, ['Ref ID', 'Timestamp', 'Source Section', 'Source Button', 'Name', 'Company', 'Email', 'Phone', 'Service', 'Service Specs', 'Requirement Message', 'IP Address']);
    }
    fputcsv($fp, [
        $refId,
        $timestamp,
        $sourceSection,
        $sourceButton,
        $name,
        $company,
        $email,
        $phone,
        $service,
        json_encode($serviceDetails),
        $message,
        $clientIp
    ]);
    fclose($fp);
}

// Compose Email
$emailSubject = "QUOTE ENQUIRY: $service - $company ($name) (From: $sourceSection > $sourceButton) [$refId]";

$emailBodyText = "New Logistics Enquiry Received\n";
$emailBodyText .= "Reference: $refId\nDate: $timestamp\n";
$emailBodyText .= "Source Section: $sourceSection\nSource Button: $sourceButton\n";
$emailBodyText .= "Name: $name\nCompany: $company\nEmail: $email\nPhone: $phone\nService: $service\n";
if (!empty($serviceDetails)) {
    $emailBodyText .= "\n--- Specific Requirements ---\n";
    foreach ($serviceDetails as $k => $v) {
        $emailBodyText .= "$k: $v\n";
    }
}
$emailBodyText .= "\n--- Requirement Summary ---\n$message\n";

$emailBodyHtml = "
<div style='font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; background: #ffffff;'>
    <div style='background: #102a38; color: #ffffff; padding: 22px;'>
        <h2 style='margin: 0; color: #ff6a00; font-size: 20px;'>Ashwini Logistics Solutions — Commercial Desk</h2>
        <p style='margin: 6px 0 0; color: #d0d7de; font-size: 14px;'>New Quote &amp; Service Request | Ref: <strong>$refId</strong></p>
    </div>
    
    <div style='padding: 24px; color: #24292f;'>
        <!-- Lead Origin / Source Callout Banner -->
        <div style='background: #fff7ed; border-left: 4px solid #ea580c; padding: 14px 18px; margin-bottom: 24px; border-radius: 4px;'>
            <span style='font-size: 11px; text-transform: uppercase; letter-spacing: 0.8px; color: #c2410c; font-weight: bold;'>Lead Origin &amp; Button Trigger:</span>
            <div style='margin-top: 6px; font-size: 14px; color: #7c2d12; line-height: 1.6;'>
                • <strong>Origin Section:</strong> {$sourceSection}<br>
                • <strong>Trigger Button:</strong> {$sourceButton}<br>
                • <strong>Selected Service:</strong> <span style='color: #ea580c; font-weight: bold;'>{$service}</span>
            </div>
        </div>

        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px; margin: 0 0 16px; color: #102a38; font-size: 16px;'>Customer Information</h3>
        <table style='width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;'>
            <tr><td style='padding: 9px 12px; width: 35%; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Name:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$name</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Company:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>$company</td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Email:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><a href='mailto:$email' style='color: #0969da;'>$email</a></td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Phone:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><a href='tel:$phone' style='color: #0969da; font-weight: bold;'>$phone</a></td></tr>
            <tr><td style='padding: 9px 12px; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>Service Needed:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'><strong style='color: #102a38;'>$service</strong></td></tr>
        </table>
";

if (!empty($serviceDetails)) {
    $emailBodyHtml .= "<h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px; margin: 0 0 16px; color: #102a38; font-size: 16px;'>Service Specifications</h3><table style='width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;'>";
    foreach ($serviceDetails as $k => $v) {
        $emailBodyHtml .= "<tr><td style='padding: 9px 12px; width: 35%; font-weight: bold; background: #f6f8fa; border: 1px solid #e1e4e8;'>$k:</td><td style='padding: 9px 12px; border: 1px solid #e1e4e8;'>" . htmlspecialchars($v) . "</td></tr>";
    }
    $emailBodyHtml .= "</table>";
}

$emailBodyHtml .= "
        <h3 style='border-bottom: 2px solid #ff6a00; padding-bottom: 8px; margin: 0 0 12px; color: #102a38; font-size: 16px;'>Requirement Summary</h3>
        <div style='background: #f8fafc; padding: 16px; border-radius: 6px; border-left: 4px solid #ff6a00; white-space: pre-wrap; font-size: 14px; line-height: 1.6; color: #334155;'>" . nl2br($message) . "</div>
    </div>
    
    <div style='background: #f1f5f9; padding: 14px 24px; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0;'>
        Received on $timestamp | Client IP: $clientIp | Ashwini Logistics Solutions Website Portal
    </div>
</div>";

$mailSent = false;
$smtpError = null;

if (defined('MAIL_DRIVER') && MAIL_DRIVER === 'smtp') {
    $mailRes = send_smtp_email(
        MAIL_TO_ADDRESS,
        $emailSubject,
        $emailBodyHtml,
        $emailBodyText,
        $email,
        $name
    );
    $mailSent = $mailRes['success'];
    if (!$mailSent) $smtpError = $mailRes['error'] ?? 'SMTP Error';
} else {
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
    $headers .= "Reply-To: $name <$email>\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    $mailSent = @mail(MAIL_TO_ADDRESS, $emailSubject, $emailBodyHtml, $headers);
}

// Client Acknowledgement
$ackSubject = "We have received your enquiry [$refId] — Ashwini Logistics Solutions";
$ackHtml = "
<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;'>
    <div style='background: #102a38; color: #ffffff; padding: 20px;'>
        <h2 style='margin: 0; color: #ff6a00;'>Ashwini Logistics Solutions</h2>
        <p style='margin: 5px 0 0; color: #d0d7de;'>Reliability, Delivered.</p>
    </div>
    <div style='padding: 24px; color: #333;'>
        <p>Dear <strong>$name</strong>,</p>
        <p>Thank you for reaching out to Ashwini Logistics Solutions regarding <strong>$service</strong>.</p>
        <p>Your enquiry reference number is: <strong style='color: #ff6a00; font-size: 16px;'>$refId</strong>.</p>
        <p>Our commercial desk and operations team are reviewing your requirements and will contact you shortly with a personalized quotation and movement plan.</p>
        <br>
        <p><strong>Ashwini Logistics Solutions Head Office</strong><br>
        Shelton Sapphire, CBD Belapur, Navi Mumbai<br>
        Direct Desk: " . CONTACT_PHONE . "<br>
        Email: " . CONTACT_EMAIL . "</p>
    </div>
</div>";

if (defined('MAIL_DRIVER') && MAIL_DRIVER === 'smtp') {
    @send_smtp_email($email, $ackSubject, $ackHtml, "Thank you for contacting Ashwini Logistics. Reference: $refId");
} else {
    $ackHeaders  = "MIME-Version: 1.0\r\n";
    $ackHeaders .= "Content-type: text/html; charset=UTF-8\r\n";
    $ackHeaders .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
    $ackHeaders .= "X-Mailer: PHP/" . phpversion();
    @mail($email, $ackSubject, $ackHtml, $ackHeaders);
}

echo json_encode([
    'success'    => true,
    'form_type'  => 'quote_enquiry',
    'ref_id'     => $refId,
    'message'    => 'Thank you! Your logistics enquiry has been recorded successfully. Our team will contact you shortly. Reference: ' . $refId,
    'mail_sent'  => $mailSent,
    'driver'     => defined('MAIL_DRIVER') ? MAIL_DRIVER : 'mail',
    'debug_error'=> $smtpError
]);
