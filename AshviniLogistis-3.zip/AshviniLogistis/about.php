<?php
$page_title = "About Us | 3 Decades of Reliable Transport — Ashwini Logistics";
$page_description = "From a single-office transport operator to 500+ vehicles and global warehousing — the story of how Ashwini Logistics earned its reliability, year by year.";
$current_page = "about";
require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-about.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> OUR STORY</div>
<h1>Experience on the road.<br><em>Commitment to your business.</em></h1>
<p>For over three decades, Ashwini Logistics Solutions has supported businesses with logistics and transportation across India. Our work brings together owned transport capacity, experienced people and a network built around the needs of customers.</p>
<div class="hero-facts"><span><b>500+</b> owned vehicles</span><span><b>18+</b> branches</span></div>
<a class="button orange" href="#core-team">Meet the people behind Ashwini <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>
<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> WHAT GUIDES THE OPERATION</div><h2>What guides<br>the operation.</h2></div><p>Mission, vision and approach.<br>The same three commitments every day.</p></div>
<div class="values-grid">
<article class="pcard"><span class="pnum">01</span><h3>Our mission.</h3><p>To make Ashwini Logistics Solutions one of India’s most reliable logistics companies through consistent service and accountability.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Our vision.</h3><p>To earn lasting trust through our commitments to customers, employees and business partners.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Our approach.</h3><p>Practical planning, responsible transport operations, clear communication and respect for the people who make every movement possible.</p></article>
</div>
</div></section>
<section class="team section wrap" id="core-team">
<div class="section-heading"><div><div class="eyebrow"><span></span> THE PEOPLE BEHIND EVERY MOVEMENT</div><h2>The core team.</h2></div><p>Experienced leadership<br>across operations, accounts and sales.</p></div>
<div class="team-grid">
<article class="pcard team-card"><img class="team-photo" src="<?php echo $base_path; ?>assets/images/team/kuldeep.jpg" alt="Kuldeep Singh Bhalothia" width="800" height="741" loading="lazy"><div class="team-body"><span class="pnum">01</span><h3>Kuldeep Singh Bhalothia</h3><span class="team-role">Managing Director</span><p>Provides leadership grounded in experience in logistics and transportation.</p></div></article>
<article class="pcard team-card"><img class="team-photo" src="<?php echo $base_path; ?>assets/images/team/rajguru.jpg" alt="Rajguru Singh Bhalothia" width="800" height="800" loading="lazy"><div class="team-body"><span class="pnum">02</span><h3>Rajguru Singh Bhalothia</h3><span class="team-role">Director</span><p>Helps guide the company’s service commitment and business direction.</p></div></article>
<article class="pcard"><span class="pnum">03</span><h3>Pankaj Goenka</h3><span class="team-role">General Manager – Finance &amp; Operation</span><p>Leads the finance and operational strategy, driving planning, budgeting and process discipline across the network.</p></article>
<article class="pcard"><span class="pnum">04</span><h3>Somnath Koli</h3><span class="team-role">General Manager – Audit &amp; Statutory Compliance</span><p>Leads complete Audit with a background in supply chain management.</p></article>
</div>
</section>
<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Move with<br><em>a partner.</em></h2><p>See what three decades of kept promises<br>could do for your supply chain.</p></div><a class="button orange" href="contact.php">Start the conversation <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
