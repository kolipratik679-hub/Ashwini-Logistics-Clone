<?php
$page_title = "Our Network | 18+ Branches Across India — Ashwini Logistics";
$page_description = "From manufacturing hubs to port cities — 18+ branches across India and warehousing across the globe, one connected network.";
$current_page = "network";
$extra_js = '<script src="<?php echo $base_path; ?>assets/js/map.js?v=20261018c" defer></script>';
require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-network.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> OUR NETWORK</div>
<h1>Local teams.<br><em>Connected across India.</em></h1>
<p>A connected network helps turn a transport requirement into a coordinated movement. With 18+ branches across India, Ashwini supports customers through teams familiar with their operating locations and logistics needs.</p>
<a class="button orange" href="contact.php">Check your route with our team <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>
<section class="network section"><div class="wrap network-grid">
<div class="network-copy">
<div class="eyebrow light"><span></span> 18+ BRANCHES. ONE STANDARD.</div>
<h2>The map is<br><em>the promise.</em></h2>
<p>Find a location below, or share your origin and destination with us to discuss the route.</p>
<div class="network-stat"><strong>18+</strong><span>branches.<br>One connected network.</span></div>
<div class="region-picker" role="group" aria-label="Explore branch locations by region"><button class="active" type="button" data-region="all" aria-pressed="true">All regions</button><button type="button" data-region="north" aria-pressed="false">North</button><button type="button" data-region="west" aria-pressed="false">West &amp; Central</button><button type="button" data-region="south" aria-pressed="false">South</button><button type="button" data-region="east" aria-pressed="false">East</button></div>
<p class="branch-list" id="branch-list" aria-live="polite">Delhi · Noida · Nuh · Neemrana · Alwar · Nhava Sheva / JNPT · Indore · Solapur · Pune · Wada · Aurangabad · Lonand · Jalgaon · Goa · Vapi · Hyderabad · Ankleshwar · Chennai · Bengaluru · Kurnool · Mundra · Kolkata · Haldia · Navi Mumbai</p>
<a class="text-link light-link" href="contact.php">Tell us your route <svg class="icon"><use href="#i-ne"/></svg></a>
</div>
<div class="network-map"><div id="india-map" aria-label="Illustrative map of India's transport network"></div><small>INDICATIVE COVERAGE MAP — NOT A POLITICAL BOUNDARY REFERENCE</small></div>
</div></section>
<section class="locations section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> OPERATING LOCATIONS</div><h2>Where we<br>operate.</h2></div><p>Branch teams across four regions,<br>reporting into one network.</p></div>
<div class="region-grid">
<article class="pcard"><span class="pnum">NORTH</span><h3>North.</h3><ul class="region-list"><li>Delhi</li><li>Noida</li><li>Nuh</li><li>Neemrana</li><li>Alwar</li></ul></article>
<article class="pcard"><span class="pnum">WEST &amp; CENTRAL</span><h3>West and Central.</h3><ul class="region-list"><li>Nhava Sheva / JNPT</li><li>Indore</li><li>Solapur</li><li>Pune</li><li>Wada</li><li>Aurangabad</li><li>Lonand</li><li>Jalgaon</li><li>Goa</li><li>Vapi</li><li>Navi Mumbai</li><li>Ankleshwar</li><li>Mundra</li></ul></article>
<article class="pcard"><span class="pnum">SOUTH</span><h3>South.</h3><ul class="region-list"><li>Hyderabad</li><li>Chennai</li><li>Bengaluru</li><li>Kurnool</li></ul></article>
<article class="pcard"><span class="pnum">EAST</span><h3>East.</h3><ul class="region-list"><li>Haldia</li><li>Kolkata</li></ul></article>
</div>
<div class="office"><svg class="icon"><use href="#i-pin"/></svg><div><b>Head office</b><address>Shelton Sapphire, B701–703, Plot 18 &amp; 19, Sector 15, CBD Belapur, Navi Mumbai, Maharashtra 400614</address></div></div>
</section>
<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Your lane.<br><em>Our map.</em></h2><p>This network keeps growing.<br>Ask us about yours.</p></div><a class="button orange" href="contact.php">Tell us your route <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
