<?php
require_once __DIR__ . '/auth.php';
require_auth();

$enquiries = get_enquiries();
$message = '';
$error = '';

// Handle CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ashwini_leads_' . date('Ymd_His') . '.csv"');
    $out = fopen('php://output', 'w');
    // Header row
    fputcsv($out, ['Ref ID', 'Timestamp', 'Client IP', 'Customer Name', 'Company', 'Email', 'Phone', 'Service', 'Origin', 'Destination', 'Cargo', 'Weight', 'Status', 'Message']);
    foreach ($enquiries as $row) {
        fputcsv($out, [
            $row['ref_id'] ?? '',
            $row['timestamp'] ?? '',
            $row['client_ip'] ?? '',
            $row['name'] ?? '',
            $row['company'] ?? '',
            $row['email'] ?? '',
            $row['phone'] ?? '',
            $row['service'] ?? '',
            $row['service_details']['Origin'] ?? $row['service_details']['Preferred Location'] ?? '',
            $row['service_details']['Destination'] ?? '',
            $row['service_details']['Cargo'] ?? $row['service_details']['Cargo Stored'] ?? '',
            $row['service_details']['Approx Weight'] ?? $row['service_details']['Storage Quantity'] ?? '',
            $row['status'] ?? 'New',
            $row['message'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}

// Handle Status Update or Delete POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $refId  = trim($_POST['ref_id'] ?? '');
    $csrf   = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Invalid security token. Please refresh and try again.';
    } elseif ($action === 'update_status') {
        $newStatus = trim($_POST['status'] ?? 'New');
        $found = false;
        foreach ($enquiries as &$item) {
            if (($item['ref_id'] ?? '') === $refId) {
                $item['status'] = $newStatus;
                $found = true;
                break;
            }
        }
        if ($found) {
            save_enquiries($enquiries);
            $message = "Lead status for <b>{$refId}</b> updated to <b>{$newStatus}</b>.";
        } else {
            $error = 'Lead reference not found.';
        }
    } elseif ($action === 'delete_lead') {
        $initialCount = count($enquiries);
        $enquiries = array_values(array_filter($enquiries, fn($e) => ($e['ref_id'] ?? '') !== $refId));
        if (count($enquiries) < $initialCount) {
            save_enquiries($enquiries);
            $message = "Lead <b>{$refId}</b> has been deleted.";
        } else {
            $error = 'Lead not found or already deleted.';
        }
    }
}

// Search and Filter
$search = trim($_GET['q'] ?? '');
$filterStatus = trim($_GET['status'] ?? '');
$selectedRef = trim($_GET['ref'] ?? '');

$filteredEnquiries = $enquiries;

if (!empty($search)) {
    $filteredEnquiries = array_filter($filteredEnquiries, function($e) use ($search) {
        $haystack = strtolower(($e['name'] ?? '') . ' ' . ($e['company'] ?? '') . ' ' . ($e['email'] ?? '') . ' ' . ($e['phone'] ?? '') . ' ' . ($e['ref_id'] ?? '') . ' ' . ($e['service'] ?? ''));
        return str_contains($haystack, strtolower($search));
    });
}

if (!empty($filterStatus) && $filterStatus !== 'all') {
    $filteredEnquiries = array_filter($filteredEnquiries, fn($e) => strcasecmp($e['status'] ?? 'New', $filterStatus) === 0);
}

// Sort newest first
usort($filteredEnquiries, fn($a, $b) => strcmp($b['timestamp'] ?? '', $a['timestamp'] ?? ''));

// Selected lead details for modal
$selectedLead = null;
if (!empty($selectedRef)) {
    foreach ($enquiries as $enq) {
        if (($enq['ref_id'] ?? '') === $selectedRef) {
            $selectedLead = $enq;
            break;
        }
    }
}

$pageTitle = 'Quote Enquiries & Leads';
$pageSubtitle = 'Manage logistics enquiries, cargo details, contact leads and follow-ups';
require_once __DIR__ . '/header.php';
?>

<?php if ($message): ?>
  <div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>

<?php if ($error): ?>
  <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- Top Toolbar -->
<div class="card" style="padding: 16px 20px;">
  <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
    <!-- Search and Status filters -->
    <form method="GET" action="enquiries.php" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; flex: 1;">
      <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name, company, ref ID or phone..." 
             style="min-width: 260px; padding: 8px 14px; border: 1px solid var(--line); border-radius: 6px; font-size: 13.5px; outline: none;">
      
      <select name="status" style="padding: 8px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 13.5px; outline: none; background: #fff;">
        <option value="all" <?php echo ($filterStatus === 'all' || empty($filterStatus)) ? 'selected' : ''; ?>>All Statuses</option>
        <option value="New" <?php echo ($filterStatus === 'New') ? 'selected' : ''; ?>>New Leads</option>
        <option value="Contacted" <?php echo ($filterStatus === 'Contacted') ? 'selected' : ''; ?>>Contacted</option>
        <option value="Converted" <?php echo ($filterStatus === 'Converted') ? 'selected' : ''; ?>>Converted / Active</option>
        <option value="Archived" <?php echo ($filterStatus === 'Archived') ? 'selected' : ''; ?>>Archived</option>
      </select>

      <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
      <?php if (!empty($search) || (!empty($filterStatus) && $filterStatus !== 'all')): ?>
        <a href="enquiries.php" class="btn btn-sm" style="color: #64748b;">Clear Filter</a>
      <?php endif; ?>
    </form>

    <!-- Export Action -->
    <div>
      <a href="enquiries.php?export=csv" class="btn btn-primary btn-sm">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <span>Export to CSV</span>
      </a>
    </div>
  </div>
</div>

<!-- Main Enquiries Table -->
<div class="card">
  <div class="card-header">
    <div>
      <h2>All Customer Enquiries (<?php echo count($filteredEnquiries); ?>)</h2>
      <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Click "Review" on any lead to inspect full cargo specifications</p>
    </div>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Ref ID</th>
          <th>Received On</th>
          <th>Customer Name</th>
          <th>Company</th>
          <th>Contact Info</th>
          <th>Service Line</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($filteredEnquiries)): ?>
          <tr><td colspan="8" style="text-align: center; color: var(--muted); padding: 40px;">No enquiries match your criteria.</td></tr>
        <?php else: ?>
          <?php foreach ($filteredEnquiries as $enq): ?>
            <?php 
              $st = $enq['status'] ?? 'New';
              $pillClass = match(strtolower($st)) {
                'new' => 'status-new',
                'contacted' => 'status-contacted',
                'converted' => 'status-converted',
                default => 'status-archived'
              };
            ?>
            <tr style="<?php echo ($selectedRef === ($enq['ref_id'] ?? '')) ? 'background: #fff7ed;' : ''; ?>">
              <td><code style="font-weight: 700; color: var(--navy);"><?php echo htmlspecialchars($enq['ref_id'] ?? '—'); ?></code></td>
              <td style="font-size: 13px; white-space: nowrap;"><?php echo date('d M Y, H:i', strtotime($enq['timestamp'] ?? 'now')); ?></td>
              <td><strong><?php echo htmlspecialchars($enq['name'] ?? '—'); ?></strong></td>
              <td><?php echo htmlspecialchars($enq['company'] ?? '—'); ?></td>
              <td style="font-size: 13px;">
                <div><a href="tel:<?php echo htmlspecialchars($enq['phone'] ?? ''); ?>" style="color: var(--orange); font-weight: 700;"><?php echo htmlspecialchars($enq['phone'] ?? '—'); ?></a></div>
                <div style="color: var(--muted);"><?php echo htmlspecialchars($enq['email'] ?? '—'); ?></div>
              </td>
              <td><span style="font-weight: 600; color: var(--navy);"><?php echo htmlspecialchars($enq['service'] ?? 'General Enquiry'); ?></span></td>
              <td>
                <form method="POST" action="enquiries.php" style="display: inline-block;">
                  <input type="hidden" name="action" value="update_status">
                  <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($enq['ref_id'] ?? ''); ?>">
                  <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                  <select name="status" onchange="this.form.submit()" style="font-size: 12px; font-weight: 700; border-radius: 12px; padding: 3px 8px; border: 1px solid var(--line); cursor: pointer; background: #fff;">
                    <option value="New" <?php echo ($st === 'New') ? 'selected' : ''; ?>>New</option>
                    <option value="Contacted" <?php echo ($st === 'Contacted') ? 'selected' : ''; ?>>Contacted</option>
                    <option value="Converted" <?php echo ($st === 'Converted') ? 'selected' : ''; ?>>Converted</option>
                    <option value="Archived" <?php echo ($st === 'Archived') ? 'selected' : ''; ?>>Archived</option>
                  </select>
                </form>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="enquiries.php?ref=<?php echo urlencode($enq['ref_id'] ?? ''); ?>" class="btn btn-secondary btn-sm" title="Inspect full cargo and route specifications">
                    Review
                  </a>
                  <form method="POST" action="enquiries.php" onsubmit="return confirm('Are you sure you want to delete lead <?php echo htmlspecialchars($enq['ref_id'] ?? ''); ?>?');" style="display: inline;">
                    <input type="hidden" name="action" value="delete_lead">
                    <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($enq['ref_id'] ?? ''); ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                    <button type="submit" class="btn btn-danger btn-sm" title="Delete lead">&times;</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal / Drawer for Selected Lead Details -->
<?php if ($selectedLead): ?>
  <div style="position: fixed; inset: 0; background: rgba(11,32,44,0.65); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: #ffffff; border-radius: 12px; width: 100%; max-width: 650px; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 60px rgba(0,0,0,0.3); border: 1px solid var(--line);">
      <div style="padding: 20px 24px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; background: var(--navy); color: #fff; border-radius: 12px 12px 0 0;">
        <div>
          <span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: var(--orange); text-transform: uppercase;">Lead Specification Dossier</span>
          <h2 style="font-size: 18px; margin-top: 4px; color: #fff;"><?php echo htmlspecialchars($selectedLead['ref_id'] ?? ''); ?></h2>
        </div>
        <a href="enquiries.php<?php echo (!empty($search) ? '?q='.urlencode($search) : ''); ?>" style="color: #fff; font-size: 24px; text-decoration: none; line-height: 1;">&times;</a>
      </div>

      <div style="padding: 24px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid var(--line);">
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Customer Name</span>
            <strong style="font-size: 15px; color: var(--navy);"><?php echo htmlspecialchars($selectedLead['name'] ?? '—'); ?></strong>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Company</span>
            <strong style="font-size: 15px; color: var(--navy);"><?php echo htmlspecialchars($selectedLead['company'] ?? '—'); ?></strong>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Phone Number</span>
            <a href="tel:<?php echo htmlspecialchars($selectedLead['phone'] ?? ''); ?>" style="color: var(--orange); font-weight: 700; font-size: 15px;"><?php echo htmlspecialchars($selectedLead['phone'] ?? '—'); ?></a>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Email Address</span>
            <a href="mailto:<?php echo htmlspecialchars($selectedLead['email'] ?? ''); ?>" style="color: #0284c7; font-size: 14px;"><?php echo htmlspecialchars($selectedLead['email'] ?? '—'); ?></a>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Service Line</span>
            <span style="font-weight: 700;"><?php echo htmlspecialchars($selectedLead['service'] ?? '—'); ?></span>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Submission Timestamp</span>
            <span style="font-size: 13px;"><?php echo htmlspecialchars($selectedLead['timestamp'] ?? '—'); ?> (IP: <?php echo htmlspecialchars($selectedLead['client_ip'] ?? '—'); ?>)</span>
          </div>
        </div>

        <h3 style="font-size: 14px; font-weight: 700; color: var(--navy); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Cargo &amp; Route Parameters</h3>
        <div style="background: #ffffff; border: 1px solid var(--line); border-radius: 8px; padding: 14px 18px; margin-bottom: 20px;">
          <?php if (!empty($selectedLead['service_details'])): ?>
            <table style="width: 100%; font-size: 13.5px; border-collapse: collapse;">
              <?php foreach ($selectedLead['service_details'] as $k => $v): ?>
                <tr>
                  <td style="padding: 6px 0; color: var(--muted); width: 40%; font-weight: 600;"><?php echo htmlspecialchars($k); ?>:</td>
                  <td style="padding: 6px 0; color: var(--ink); font-weight: 700;"><?php echo htmlspecialchars($v); ?></td>
                </tr>
              <?php endforeach; ?>
            </table>
          <?php else: ?>
            <p style="color: var(--muted); font-size: 13px;">No specific cargo parameters provided.</p>
          <?php endif; ?>
        </div>

        <h3 style="font-size: 14px; font-weight: 700; color: var(--navy); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">Customer Message / Instructions</h3>
        <div style="background: #f8fafc; border: 1px solid var(--line); border-radius: 8px; padding: 14px 18px; font-size: 14px; line-height: 1.7; color: #334155; margin-bottom: 24px;">
          <?php echo nl2br(htmlspecialchars($selectedLead['message'] ?? 'No additional instructions provided.')); ?>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center;">
          <form method="POST" action="enquiries.php" style="display: flex; align-items: center; gap: 8px;">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($selectedLead['ref_id'] ?? ''); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <label style="font-size: 13px; font-weight: 700; color: var(--navy);">Update Status:</label>
            <select name="status" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--line); font-size: 13px;">
              <option value="New" <?php echo (($selectedLead['status'] ?? '') === 'New') ? 'selected' : ''; ?>>New</option>
              <option value="Contacted" <?php echo (($selectedLead['status'] ?? '') === 'Contacted') ? 'selected' : ''; ?>>Contacted</option>
              <option value="Converted" <?php echo (($selectedLead['status'] ?? '') === 'Converted') ? 'selected' : ''; ?>>Converted</option>
              <option value="Archived" <?php echo (($selectedLead['status'] ?? '') === 'Archived') ? 'selected' : ''; ?>>Archived</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Save</button>
          </form>

          <a href="enquiries.php<?php echo (!empty($search) ? '?q='.urlencode($search) : ''); ?>" class="btn btn-secondary btn-sm">Close Window</a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
