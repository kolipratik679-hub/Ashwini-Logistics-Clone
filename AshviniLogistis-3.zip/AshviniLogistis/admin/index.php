<?php
$pageTitle = 'Dashboard Overview';
$pageSubtitle = 'Real-time overview of customer quotes, career applications, and key metrics';
require_once __DIR__ . '/header.php';

$enquiries = get_enquiries();
$careers = get_careers();

$totalEnquiries = count($enquiries);
$totalCareers = count($careers);

$todayDate = date('Y-m-d');
$todayEnquiries = count(array_filter($enquiries, fn($e) => str_starts_with($e['timestamp'] ?? '', $todayDate)));
$todayCareers = count(array_filter($careers, fn($c) => str_starts_with($c['timestamp'] ?? '', $todayDate)));

// Sort newest first
usort($enquiries, fn($a, $b) => strcmp($b['timestamp'] ?? '', $a['timestamp'] ?? ''));
usort($careers, fn($a, $b) => strcmp($b['timestamp'] ?? '', $a['timestamp'] ?? ''));

$recentEnquiries = array_slice($enquiries, 0, 5);
$recentCareers = array_slice($careers, 0, 5);
?>

<!-- Metric Cards Grid -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-icon" style="background: #e0f2fe; color: #0284c7;">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
    </div>
    <div class="stat-info">
      <span>Total Quote Enquiries</span>
      <strong><?php echo $totalEnquiries; ?></strong>
      <div style="font-size: 12px; color: #0284c7; margin-top: 4px;">+<?php echo $todayEnquiries; ?> received today</div>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon" style="background: #fef3c7; color: #d97706;">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
    </div>
    <div class="stat-info">
      <span>New Leads Pending Action</span>
      <strong style="color: #d97706;"><?php echo $newEnquiriesCount; ?></strong>
      <div style="font-size: 12px; color: var(--muted); margin-top: 4px;">Awaiting response</div>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon" style="background: #dcfce7; color: #16a34a;">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
    </div>
    <div class="stat-info">
      <span>Job Applications</span>
      <strong><?php echo $totalCareers; ?></strong>
      <div style="font-size: 12px; color: #16a34a; margin-top: 4px;">+<?php echo $todayCareers; ?> applied today</div>
    </div>
  </div>

  <div class="stat-card">
    <div class="stat-icon" style="background: #ffedd5; color: #ea580c;">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 5h14v12H1V5Zm14 4h4l4 5v3h-8M16 9v5h7"/><circle cx="5" cy="18" r="2"/><circle cx="19" cy="18" r="2"/></svg>
    </div>
    <div class="stat-info">
      <span>Active Fleet Size</span>
      <strong><?php echo htmlspecialchars(STAT_VEHICLES); ?></strong>
      <div style="font-size: 12px; color: var(--muted); margin-top: 4px;">Across 18+ national hubs</div>
    </div>
  </div>
</div>

<!-- Recent Quote Enquiries -->
<div class="card">
  <div class="card-header">
    <div>
      <h2>Recent Customer Quotes &amp; Enquiries</h2>
      <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Latest logistics and transport service quote requests</p>
    </div>
    <div style="display: flex; gap: 8px;">
      <a href="enquiries.php" class="btn btn-secondary btn-sm">View All Leads (<?php echo $totalEnquiries; ?>)</a>
    </div>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Ref ID</th>
          <th>Date &amp; Time</th>
          <th>Customer / Company</th>
          <th>Service Line</th>
          <th>Route / Origin &rarr; Dest</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentEnquiries)): ?>
          <tr><td colspan="7" style="text-align: center; color: var(--muted); padding: 32px;">No quote enquiries recorded yet.</td></tr>
        <?php else: ?>
          <?php foreach ($recentEnquiries as $enq): ?>
            <?php 
              $st = $enq['status'] ?? 'New';
              $pillClass = match(strtolower($st)) {
                'new' => 'status-new',
                'contacted' => 'status-contacted',
                'converted' => 'status-converted',
                default => 'status-archived'
              };
              $origin = $enq['service_details']['Origin'] ?? $enq['service_details']['Preferred Location'] ?? '—';
              $destination = $enq['service_details']['Destination'] ?? '—';
            ?>
            <tr>
              <td><code style="font-weight: 700; color: var(--navy);"><?php echo htmlspecialchars($enq['ref_id'] ?? '—'); ?></code></td>
              <td><?php echo date('d M Y, H:i', strtotime($enq['timestamp'] ?? 'now')); ?></td>
              <td>
                <strong><?php echo htmlspecialchars($enq['name'] ?? '—'); ?></strong>
                <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($enq['company'] ?? ''); ?></div>
              </td>
              <td><span style="font-weight: 600;"><?php echo htmlspecialchars($enq['service'] ?? 'General Enquiry'); ?></span></td>
              <td style="font-size: 13px;"><?php echo htmlspecialchars($origin); ?> &rarr; <?php echo htmlspecialchars($destination); ?></td>
              <td><span class="status-pill <?php echo $pillClass; ?>"><?php echo htmlspecialchars($st); ?></span></td>
              <td>
                <a href="enquiries.php?ref=<?php echo urlencode($enq['ref_id'] ?? ''); ?>" class="btn btn-secondary btn-sm">Review</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Recent Job Applications -->
<div class="card">
  <div class="card-header">
    <div>
      <h2>Recent Job &amp; Driver Applications</h2>
      <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Candidates applying for drivers, fleet management and CFS operations</p>
    </div>
    <div style="display: flex; gap: 8px;">
      <a href="careers.php" class="btn btn-secondary btn-sm">View All Applications (<?php echo $totalCareers; ?>)</a>
    </div>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Ref ID</th>
          <th>Date Applied</th>
          <th>Applicant Name</th>
          <th>Position Applied For</th>
          <th>Experience</th>
          <th>Contact Phone</th>
          <th>Resume File</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentCareers)): ?>
          <tr><td colspan="8" style="text-align: center; color: var(--muted); padding: 32px;">No career applications submitted yet.</td></tr>
        <?php else: ?>
          <?php foreach ($recentCareers as $car): ?>
            <tr>
              <td><code><?php echo htmlspecialchars($car['ref_id'] ?? '—'); ?></code></td>
              <td><?php echo date('d M Y, H:i', strtotime($car['timestamp'] ?? 'now')); ?></td>
              <td><strong><?php echo htmlspecialchars($car['name'] ?? '—'); ?></strong></td>
              <td><span style="font-weight: 600; color: var(--navy);"><?php echo htmlspecialchars($car['job_role'] ?? 'General Application'); ?></span></td>
              <td><?php echo htmlspecialchars($car['experience'] ?? '—'); ?></td>
              <td><a href="tel:<?php echo htmlspecialchars($car['phone'] ?? ''); ?>" style="color: var(--orange); font-weight: 700;"><?php echo htmlspecialchars($car['phone'] ?? '—'); ?></a></td>
              <td>
                <?php if (!empty($car['resume_file'])): ?>
                  <a href="../uploads/resumes/<?php echo urlencode($car['resume_file']); ?>" target="_blank" class="btn btn-secondary btn-sm" style="color: #0284c7;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    <span>Download</span>
                  </a>
                <?php else: ?>
                  <span style="color: var(--muted); font-size: 12px;">No file</span>
                <?php endif; ?>
              </td>
              <td>
                <a href="careers.php?ref=<?php echo urlencode($car['ref_id'] ?? ''); ?>" class="btn btn-secondary btn-sm">Details</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
