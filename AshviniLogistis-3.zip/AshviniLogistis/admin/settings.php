<?php
require_once __DIR__ . '/auth.php';
require_auth();

$siteContent = get_site_content();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf   = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Invalid security token. Please refresh the page.';
    } elseif ($action === 'save_content') {
        $siteContent['top_announcement']   = trim($_POST['top_announcement'] ?? '');
        $siteContent['top_cta_text']       = trim($_POST['top_cta_text'] ?? '');
        $siteContent['contact_phone']       = trim($_POST['contact_phone'] ?? '');
        $siteContent['contact_phone_raw']   = trim($_POST['contact_phone_raw'] ?? '');
        $siteContent['contact_email']       = trim($_POST['contact_email'] ?? '');
        $siteContent['tracking_email']      = trim($_POST['tracking_email'] ?? '');
        $siteContent['office_address']      = trim($_POST['office_address'] ?? '');
        $siteContent['helpdesk_hours']      = trim($_POST['helpdesk_hours'] ?? '');
        $siteContent['stat_vehicles']       = trim($_POST['stat_vehicles'] ?? '');
        $siteContent['stat_branches']       = trim($_POST['stat_branches'] ?? '');
        $siteContent['stat_experience']     = trim($_POST['stat_experience'] ?? '');
        $siteContent['stat_trips_month']    = trim($_POST['stat_trips_month'] ?? '');
        $siteContent['stat_warehouse_sqft'] = trim($_POST['stat_warehouse_sqft'] ?? '');

        if (save_site_content($siteContent)) {
            $message = 'Site content, notice banner, and company details successfully updated!';
        } else {
            $error = 'Failed to save settings. Please check directory permissions.';
        }
    } elseif ($action === 'change_password') {
        $currentPass = trim($_POST['current_password'] ?? '');
        $newPass     = trim($_POST['new_password'] ?? '');
        $confirmPass = trim($_POST['confirm_password'] ?? '');

        if (empty($currentPass) || empty($newPass)) {
            $error = 'Please enter both current and new passwords.';
        } elseif ($newPass !== $confirmPass) {
            $error = 'New password and confirmation password do not match.';
        } elseif (strlen($newPass) < 8) {
            $error = 'New password must be at least 8 characters long.';
        } else {
            $users = get_admin_users();
            $userFound = false;

            foreach ($users as &$u) {
                if ($u['id'] == ($_SESSION['als_admin_id'] ?? 0)) {
                    if (password_verify($currentPass, $u['password_hash'])) {
                        $u['password_hash'] = password_hash($newPass, PASSWORD_BCRYPT);
                        $userFound = true;
                        break;
                    } else {
                        $error = 'Current password entered is incorrect.';
                    }
                }
            }

            if ($userFound) {
                save_admin_users($users);
                $message = 'Admin password successfully updated. Please use your new password for your next login.';
            }
        }
    }
}

$pageTitle = 'Site Content & Settings';
$pageSubtitle = 'Manage top announcement banner, company phone/email, proof stats, and security';
require_once __DIR__ . '/header.php';
?>

<?php if ($message): ?>
  <div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>

<?php if ($error): ?>
  <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 2fr 1.2fr; gap: 24px; align-items: start;">

  <!-- Main Content & Notice Settings Form -->
  <div class="card">
    <div class="card-header">
      <div>
        <h2>Key Site Content &amp; Announcement</h2>
        <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Changes reflect instantly across the header, footer, and homepage</p>
      </div>
    </div>

    <form method="POST" action="settings.php">
      <input type="hidden" name="action" value="save_content">
      <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">

      <h3 style="font-size: 14px; font-weight: 800; color: var(--navy); margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px;">1. Top Utility Announcement Bar</h3>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Announcement Text</label>
          <input type="text" name="top_announcement" value="<?php echo htmlspecialchars($siteContent['top_announcement'] ?? 'PAN-INDIA STRENGTH. GLOBAL POSSIBILITIES.'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">CTA Button Text</label>
          <input type="text" name="top_cta_text" value="<?php echo htmlspecialchars($siteContent['top_cta_text'] ?? 'Let’s talk logistics'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
      </div>

      <h3 style="font-size: 14px; font-weight: 800; color: var(--navy); margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px;">2. Contact Points &amp; Office</h3>

      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Display Contact Phone</label>
          <input type="text" name="contact_phone" value="<?php echo htmlspecialchars($siteContent['contact_phone'] ?? '+91 22 4031 2345'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Raw Phone (tel: link)</label>
          <input type="text" name="contact_phone_raw" value="<?php echo htmlspecialchars($siteContent['contact_phone_raw'] ?? '+912240312345'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">General Contact Email</label>
          <input type="email" name="contact_email" value="<?php echo htmlspecialchars($siteContent['contact_email'] ?? 'info@ashwinilogistics.in'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Helpdesk Working Hours</label>
          <input type="text" name="helpdesk_hours" value="<?php echo htmlspecialchars($siteContent['helpdesk_hours'] ?? 'Mon–Sat, 10:00–19:00 IST'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
      </div>

      <div style="margin-bottom: 24px;">
        <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Corporate Head Office Address</label>
        <textarea name="office_address" rows="2" style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none; font-family: inherit;"><?php echo htmlspecialchars($siteContent['office_address'] ?? 'Shelton Sapphire, CBD Belapur, Navi Mumbai, Maharashtra 400614, India'); ?></textarea>
      </div>

      <h3 style="font-size: 14px; font-weight: 800; color: var(--navy); margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px;">3. Proof Numbers &amp; Capacity Figures</h3>

      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin-bottom: 24px;">
        <div>
          <label style="display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px;">Owned Vehicles</label>
          <input type="text" name="stat_vehicles" value="<?php echo htmlspecialchars($siteContent['stat_vehicles'] ?? '500+'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px;">Branches in India</label>
          <input type="text" name="stat_branches" value="<?php echo htmlspecialchars($siteContent['stat_branches'] ?? '18+'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px;">Decades Experience</label>
          <input type="text" name="stat_experience" value="<?php echo htmlspecialchars($siteContent['stat_experience'] ?? '3+'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px;">Monthly Trips</label>
          <input type="text" name="stat_trips_month" value="<?php echo htmlspecialchars($siteContent['stat_trips_month'] ?? '10,000+'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
        <div>
          <label style="display: block; font-size: 12.5px; font-weight: 700; color: #334155; margin-bottom: 6px;">Warehousing (sq ft)</label>
          <input type="text" name="stat_warehouse_sqft" value="<?php echo htmlspecialchars($siteContent['stat_warehouse_sqft'] ?? '400,000+'); ?>" 
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>
      </div>

      <button type="submit" class="btn btn-primary" style="padding: 12px 24px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        <span>Save All Content Changes</span>
      </button>
    </form>
  </div>

  <!-- Security & Password Box -->
  <div>
    <div class="card">
      <div class="card-header">
        <div>
          <h2>Account Security</h2>
          <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Update your admin password</p>
        </div>
      </div>

      <form method="POST" action="settings.php">
        <input type="hidden" name="action" value="change_password">
        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">

        <div style="margin-bottom: 14px;">
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Current Password</label>
          <input type="password" name="current_password" required placeholder="••••••••••••"
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>

        <div style="margin-bottom: 14px;">
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">New Password</label>
          <input type="password" name="new_password" required placeholder="Minimum 8 characters"
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>

        <div style="margin-bottom: 20px;">
          <label style="display: block; font-size: 13px; font-weight: 700; color: #334155; margin-bottom: 6px;">Confirm New Password</label>
          <input type="password" name="confirm_password" required placeholder="Re-type new password"
                 style="width: 100%; padding: 10px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 14px; outline: none;">
        </div>

        <button type="submit" class="btn btn-secondary" style="width: 100%; padding: 11px;">
          <span>Update Password</span>
        </button>
      </form>
    </div>

    <!-- Quick Info Card -->
    <div class="card" style="background: #f8fafc;">
      <h3 style="font-size: 14px; font-weight: 800; color: var(--navy); margin-bottom: 8px;">CMS Fast Tips</h3>
      <ul style="font-size: 13px; color: var(--muted); line-height: 1.7; padding-left: 18px;">
        <li>All quote inquiries submitted on the frontend contact page appear instantly under <b>Quote Leads</b>.</li>
        <li>Driver &amp; operations applicants with PDF resumes are indexed under <b>Careers / Resumes</b>.</li>
        <li>Top notice changes appear immediately across the site without requiring server restarts.</li>
      </ul>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>
