<?php
require_once __DIR__ . '/auth.php';

$error = '';
$message = '';

if (isset($_GET['logged_out'])) {
    $message = 'You have been successfully logged out.';
}

if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $csrf     = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Invalid session token. Please try again.';
    } elseif (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $users = get_admin_users();
        $authenticatedUser = null;

        foreach ($users as &$user) {
            if (strcasecmp($user['username'], $username) === 0 && password_verify($password, $user['password_hash'])) {
                $authenticatedUser = $user;
                $user['last_login'] = date('Y-m-d H:i:s');
                break;
            }
        }

        if ($authenticatedUser) {
            save_admin_users($users);
            session_regenerate_id(true);
            $_SESSION['als_admin_id'] = $authenticatedUser['id'];
            $_SESSION['als_admin_user'] = $authenticatedUser['username'];
            $_SESSION['als_admin_name'] = $authenticatedUser['name'];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Incorrect username or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login | Ashwini Logistics Solutions CMS</title>
<link rel="icon" href="../assets/images/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../assets/css/fonts.css">
<style>
  :root {
    --navy: #102a38;
    --navy-deep: #0b202c;
    --orange: #fa6b39;
    --paper: #f5f4ee;
    --white: #ffffff;
    --ink: #17313f;
    --muted: #64748b;
    --line: #e2e8f0;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Gilmer', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: var(--navy-deep);
    color: var(--ink);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    background-image: radial-gradient(circle at 80% 20%, rgba(250, 107, 57, 0.12), transparent 40%),
                      radial-gradient(circle at 20% 80%, rgba(16, 42, 56, 0.4), transparent 50%);
  }
  .login-card {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.35);
    width: 100%;
    max-width: 440px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.15);
  }
  .login-header {
    background: var(--navy);
    padding: 32px 32px 28px;
    text-align: center;
    color: #ffffff;
    border-bottom: 3px solid var(--orange);
  }
  .login-header img {
    height: 48px;
    margin-bottom: 16px;
  }
  .login-header h1 {
    font-size: 20px;
    font-weight: 700;
    letter-spacing: -0.5px;
    color: #ffffff;
  }
  .login-header p {
    font-size: 13px;
    color: #94a3b8;
    margin-top: 4px;
  }
  .login-body {
    padding: 32px;
  }
  .alert {
    padding: 12px 16px;
    border-radius: 6px;
    font-size: 14px;
    margin-bottom: 20px;
    line-height: 1.5;
  }
  .alert-error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
  }
  .alert-success {
    background: #f0fdf4;
    color: #166534;
    border: 1px solid #bbf7d0;
  }
  .field {
    margin-bottom: 20px;
  }
  .field label {
    display: block;
    font-size: 13.5px;
    font-weight: 700;
    color: #334155;
    margin-bottom: 8px;
  }
  .field input {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 15px;
    color: var(--ink);
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  .field input:focus {
    border-color: var(--orange);
    box-shadow: 0 0 0 3px rgba(250, 107, 57, 0.18);
  }
  .btn-submit {
    width: 100%;
    background: var(--orange);
    color: #0b202c;
    border: none;
    padding: 14px;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 800;
    cursor: pointer;
    transition: background 0.2s, transform 0.1s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }
  .btn-submit:hover {
    background: #ff8559;
    transform: translateY(-1px);
  }
  .login-footer {
    padding: 16px 32px 24px;
    text-align: center;
    font-size: 12.5px;
    color: #64748b;
    border-top: 1px solid #f1f5f9;
    background: #f8fafc;
  }
  .login-footer a {
    color: var(--orange);
    text-decoration: none;
    font-weight: 600;
  }
  .login-footer a:hover {
    text-decoration: underline;
  }
  .default-hint {
    margin-top: 8px;
    font-size: 11.5px;
    color: #94a3b8;
  }
</style>
</head>
<body>

<div class="login-card">
  <div class="login-header">
    <img src="../assets/images/logo-white.svg" alt="Ashwini Logistics Solutions">
    <h1>Fast &amp; Easy Admin CMS</h1>
    <p>Manage quotes, leads, careers &amp; key site content</p>
  </div>

  <div class="login-body">
    <?php if ($error): ?>
      <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($message): ?>
      <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php" autocomplete="off">
      <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
      
      <div class="field">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="e.g. admin" required autofocus>
      </div>

      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="••••••••••••" required>
      </div>

      <button type="submit" class="btn-submit">
        <span>Sign in to Dashboard</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </button>
    </form>
  </div>

  <div class="login-footer">
    <span>© <?php echo date('Y'); ?> Ashwini Logistics Solutions</span> &bull; 
    <a href="../index.php" target="_blank">Back to Live Website &rarr;</a>
    <div class="default-hint">Default credentials: <b>admin</b> / <b>Ashwini@2026</b></div>
  </div>
</div>

</body>
</html>
