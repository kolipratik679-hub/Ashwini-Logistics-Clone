<?php
require_once __DIR__ . '/auth.php';
require_auth();

$careers = get_careers();
$message = '';
$error = '';

// Handle Status Update or Delete POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $refId  = trim($_POST['ref_id'] ?? '');
    $csrf   = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = 'Invalid security token. Please refresh and try again.';
    } elseif ($action === 'update_status') {
        $newStatus = trim($_POST['status'] ?? 'New');
        $found = false;
        foreach ($careers as &$item) {
            if (($item['ref_id'] ?? '') === $refId) {
                $item['status'] = $newStatus;
                $found = true;
                break;
            }
        }
        if ($found) {
            save_careers($careers);
            $message = "Application status for <b>{$refId}</b> updated to <b>{$newStatus}</b>.";
        } else {
            $error = 'Application reference not found.';
        }
    } elseif ($action === 'delete_career') {
        $initialCount = count($careers);
        $careers = array_values(array_filter($careers, fn($c) => ($c['ref_id'] ?? '') !== $refId));
        if (count($careers) < $initialCount) {
            save_careers($careers);
            $message = "Application <b>{$refId}</b> has been deleted.";
        } else {
            $error = 'Application not found or already deleted.';
        }
    }
}

// Search and Filter
$search = trim($_GET['q'] ?? '');
$filterStatus = trim($_GET['status'] ?? '');
$selectedRef = trim($_GET['ref'] ?? '');

$filteredCareers = $careers;

if (!empty($search)) {
    $filteredCareers = array_filter($filteredCareers, function($c) use ($search) {
        $haystack = strtolower(($c['name'] ?? '') . ' ' . ($c['job_role'] ?? '') . ' ' . ($c['email'] ?? '') . ' ' . ($c['phone'] ?? '') . ' ' . ($c['ref_id'] ?? '') . ' ' . ($c['driving_license'] ?? ''));
        return str_contains($haystack, strtolower($search));
    });
}

if (!empty($filterStatus) && $filterStatus !== 'all') {
    $filteredCareers = array_filter($filteredCareers, fn($c) => strcasecmp($c['status'] ?? 'New', $filterStatus) === 0);
}

// Sort newest first
usort($filteredCareers, fn($a, $b) => strcmp($b['timestamp'] ?? '', $a['timestamp'] ?? ''));

// Selected candidate details for modal
$selectedCandidate = null;
if (!empty($selectedRef)) {
    foreach ($careers as $c) {
        if (($c['ref_id'] ?? '') === $selectedRef) {
            $selectedCandidate = $c;
            break;
        }
    }
}

$pageTitle = 'Career Applications & Resumes';
$pageSubtitle = 'Review driver profiles, fleet managers, CFS operations applicants and download resumes';
require_once __DIR__ . '/header.php';
?>

<?php if ($message): ?>
  <div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>

<?php if ($error): ?>
  <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- Top Toolbar -->
<div class="card" style="padding: 16px 20px;">
  <form method="GET" action="careers.php" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
    <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; flex: 1;">
      <input type="text" name="q" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by candidate name, role, phone, license..." 
             style="min-width: 260px; padding: 8px 14px; border: 1px solid var(--line); border-radius: 6px; font-size: 13.5px; outline: none;">
      
      <select name="status" style="padding: 8px 12px; border: 1px solid var(--line); border-radius: 6px; font-size: 13.5px; outline: none; background: #fff;">
        <option value="all" <?php echo ($filterStatus === 'all' || empty($filterStatus)) ? 'selected' : ''; ?>>All Statuses</option>
        <option value="New" <?php echo ($filterStatus === 'New') ? 'selected' : ''; ?>>New</option>
        <option value="Shortlisted" <?php echo ($filterStatus === 'Shortlisted') ? 'selected' : ''; ?>>Shortlisted</option>
        <option value="Interviewed" <?php echo ($filterStatus === 'Interviewed') ? 'selected' : ''; ?>>Interviewed</option>
        <option value="Hired" <?php echo ($filterStatus === 'Hired') ? 'selected' : ''; ?>>Hired</option>
        <option value="Rejected" <?php echo ($filterStatus === 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
      </select>

      <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
      <?php if (!empty($search) || (!empty($filterStatus) && $filterStatus !== 'all')): ?>
        <a href="careers.php" class="btn btn-sm" style="color: #64748b;">Clear Filter</a>
      <?php endif; ?>
    </div>
    
    <div>
      <span style="font-size: 13px; color: var(--muted); font-weight: 600;">Total Applicants: <b><?php echo count($careers); ?></b></span>
    </div>
  </form>
</div>

<!-- Main Applications Table -->
<div class="card">
  <div class="card-header">
    <div>
      <h2>Candidate Submissions (<?php echo count($filteredCareers); ?>)</h2>
      <p style="font-size: 13px; color: var(--muted); margin-top: 2px;">Review uploaded resume PDFs and driver credentials</p>
    </div>
  </div>

  <div class="table-responsive">
    <table class="data-table">
      <thead>
        <tr>
          <th>Ref ID</th>
          <th>Applied On</th>
          <th>Candidate Name</th>
          <th>Job Role</th>
          <th>Experience</th>
          <th>Phone &amp; Email</th>
          <th>Resume File</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($filteredCareers)): ?>
          <tr><td colspan="9" style="text-align: center; color: var(--muted); padding: 40px;">No career applications match your criteria.</td></tr>
        <?php else: ?>
          <?php foreach ($filteredCareers as $car): ?>
            <?php 
              $st = $car['status'] ?? 'New';
              $pillClass = match(strtolower($st)) {
                'new' => 'status-new',
                'shortlisted' => 'status-converted',
                'interviewed' => 'status-contacted',
                default => 'status-archived'
              };
            ?>
            <tr style="<?php echo ($selectedRef === ($car['ref_id'] ?? '')) ? 'background: #fff7ed;' : ''; ?>">
              <td><code style="font-weight: 700; color: var(--navy);"><?php echo htmlspecialchars($car['ref_id'] ?? '—'); ?></code></td>
              <td style="font-size: 13px; white-space: nowrap;"><?php echo date('d M Y, H:i', strtotime($car['timestamp'] ?? 'now')); ?></td>
              <td><strong><?php echo htmlspecialchars($car['name'] ?? '—'); ?></strong></td>
              <td><span style="font-weight: 600; color: var(--navy);"><?php echo htmlspecialchars($car['job_role'] ?? '—'); ?></span></td>
              <td><?php echo htmlspecialchars($car['experience'] ?? '—'); ?></td>
              <td style="font-size: 13px;">
                <div><a href="tel:<?php echo htmlspecialchars($car['phone'] ?? ''); ?>" style="color: var(--orange); font-weight: 700;"><?php echo htmlspecialchars($car['phone'] ?? '—'); ?></a></div>
                <div style="color: var(--muted);"><?php echo htmlspecialchars($car['email'] ?? '—'); ?></div>
              </td>
              <td>
                <?php if (!empty($car['resume_file'])): ?>
                  <a href="../uploads/resumes/<?php echo urlencode($car['resume_file']); ?>" target="_blank" class="btn btn-secondary btn-sm" style="color: #0284c7; font-weight: 700;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    <span>Download</span>
                  </a>
                <?php else: ?>
                  <span style="color: var(--muted); font-size: 12px;">No file</span>
                <?php endif; ?>
              </td>
              <td>
                <form method="POST" action="careers.php" style="display: inline-block;">
                  <input type="hidden" name="action" value="update_status">
                  <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($car['ref_id'] ?? ''); ?>">
                  <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                  <select name="status" onchange="this.form.submit()" style="font-size: 12px; font-weight: 700; border-radius: 12px; padding: 3px 8px; border: 1px solid var(--line); cursor: pointer; background: #fff;">
                    <option value="New" <?php echo ($st === 'New') ? 'selected' : ''; ?>>New</option>
                    <option value="Shortlisted" <?php echo ($st === 'Shortlisted') ? 'selected' : ''; ?>>Shortlisted</option>
                    <option value="Interviewed" <?php echo ($st === 'Interviewed') ? 'selected' : ''; ?>>Interviewed</option>
                    <option value="Hired" <?php echo ($st === 'Hired') ? 'selected' : ''; ?>>Hired</option>
                    <option value="Rejected" <?php echo ($st === 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                  </select>
                </form>
              </td>
              <td>
                <div style="display: flex; gap: 6px;">
                  <a href="careers.php?ref=<?php echo urlencode($car['ref_id'] ?? ''); ?>" class="btn btn-secondary btn-sm" title="View candidate profile">
                    Details
                  </a>
                  <form method="POST" action="careers.php" onsubmit="return confirm('Are you sure you want to delete application <?php echo htmlspecialchars($car['ref_id'] ?? ''); ?>?');" style="display: inline;">
                    <input type="hidden" name="action" value="delete_career">
                    <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($car['ref_id'] ?? ''); ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                    <button type="submit" class="btn btn-danger btn-sm" title="Delete application">&times;</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal / Drawer for Candidate Profile -->
<?php if ($selectedCandidate): ?>
  <div style="position: fixed; inset: 0; background: rgba(11,32,44,0.65); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px;">
    <div style="background: #ffffff; border-radius: 12px; width: 100%; max-width: 600px; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 60px rgba(0,0,0,0.3); border: 1px solid var(--line);">
      <div style="padding: 20px 24px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; background: var(--navy); color: #fff; border-radius: 12px 12px 0 0;">
        <div>
          <span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: var(--orange); text-transform: uppercase;">Candidate Application Dossier</span>
          <h2 style="font-size: 18px; margin-top: 4px; color: #fff;"><?php echo htmlspecialchars($selectedCandidate['name'] ?? ''); ?></h2>
        </div>
        <a href="careers.php<?php echo (!empty($search) ? '?q='.urlencode($search) : ''); ?>" style="color: #fff; font-size: 24px; text-decoration: none; line-height: 1;">&times;</a>
      </div>

      <div style="padding: 24px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid var(--line);">
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Position Applied For</span>
            <strong style="font-size: 15px; color: var(--navy);"><?php echo htmlspecialchars($selectedCandidate['job_role'] ?? '—'); ?></strong>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Experience</span>
            <strong style="font-size: 15px; color: var(--navy);"><?php echo htmlspecialchars($selectedCandidate['experience'] ?? '—'); ?></strong>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Contact Phone</span>
            <a href="tel:<?php echo htmlspecialchars($selectedCandidate['phone'] ?? ''); ?>" style="color: var(--orange); font-weight: 700; font-size: 15px;"><?php echo htmlspecialchars($selectedCandidate['phone'] ?? '—'); ?></a>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Email</span>
            <a href="mailto:<?php echo htmlspecialchars($selectedCandidate['email'] ?? ''); ?>" style="color: #0284c7; font-size: 14px;"><?php echo htmlspecialchars($selectedCandidate['email'] ?? '—'); ?></a>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Preferred Base Hub</span>
            <span style="font-weight: 600;"><?php echo htmlspecialchars($selectedCandidate['preferred_location'] ?? '—'); ?></span>
          </div>
          <div>
            <span style="font-size: 12px; color: var(--muted); display: block;">Driving License Info</span>
            <span style="font-weight: 600; color: #166534;"><?php echo htmlspecialchars($selectedCandidate['driving_license'] ?? 'N/A'); ?></span>
          </div>
        </div>

        <h3 style="font-size: 14px; font-weight: 700; color: var(--navy); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">Experience Summary / Background</h3>
        <div style="background: #f8fafc; border: 1px solid var(--line); border-radius: 8px; padding: 14px 18px; font-size: 14px; line-height: 1.7; color: #334155; margin-bottom: 20px;">
          <?php echo nl2br(htmlspecialchars($selectedCandidate['experience_summary'] ?? 'No additional summary provided.')); ?>
        </div>

        <div style="background: #ffffff; border: 1px solid var(--line); border-radius: 8px; padding: 16px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between;">
          <div>
            <strong style="font-size: 14px; color: var(--navy); display: block;">Uploaded Resume File</strong>
            <span style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($selectedCandidate['resume_file'] ?? 'None attached'); ?></span>
          </div>
          <?php if (!empty($selectedCandidate['resume_file'])): ?>
            <a href="../uploads/resumes/<?php echo urlencode($selectedCandidate['resume_file']); ?>" target="_blank" class="btn btn-primary btn-sm">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              <span>Download Resume</span>
            </a>
          <?php endif; ?>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center;">
          <form method="POST" action="careers.php" style="display: flex; align-items: center; gap: 8px;">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="ref_id" value="<?php echo htmlspecialchars($selectedCandidate['ref_id'] ?? ''); ?>">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
            <label style="font-size: 13px; font-weight: 700; color: var(--navy);">Status:</label>
            <select name="status" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--line); font-size: 13px;">
              <option value="New" <?php echo (($selectedCandidate['status'] ?? '') === 'New') ? 'selected' : ''; ?>>New</option>
              <option value="Shortlisted" <?php echo (($selectedCandidate['status'] ?? '') === 'Shortlisted') ? 'selected' : ''; ?>>Shortlisted</option>
              <option value="Interviewed" <?php echo (($selectedCandidate['status'] ?? '') === 'Interviewed') ? 'selected' : ''; ?>>Interviewed</option>
              <option value="Hired" <?php echo (($selectedCandidate['status'] ?? '') === 'Hired') ? 'selected' : ''; ?>>Hired</option>
              <option value="Rejected" <?php echo (($selectedCandidate['status'] ?? '') === 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Update</button>
          </form>

          <a href="careers.php<?php echo (!empty($search) ? '?q='.urlencode($search) : ''); ?>" class="btn btn-secondary btn-sm">Close Window</a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
