<?php
/**
 * Ashwini Logistics Solutions - Admin Authentication & Data Helper
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DATA_DIR', __DIR__ . '/../data');
define('ENQUIRIES_JSON', DATA_DIR . '/enquiries.json');
define('ENQUIRIES_CSV', DATA_DIR . '/enquiries.csv');
define('CAREERS_JSON', DATA_DIR . '/careers.json');
define('CAREERS_CSV', DATA_DIR . '/careers.csv');
define('SITE_CONTENT_JSON', DATA_DIR . '/site_content.json');
define('ADMIN_USERS_JSON', DATA_DIR . '/admin_users.json');
define('UPLOADS_RESUMES_DIR', __DIR__ . '/../uploads/resumes');

function is_logged_in(): bool {
    return !empty($_SESSION['als_admin_id']) && !empty($_SESSION['als_admin_user']);
}

function require_auth(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function get_csrf_token(): string {
    if (empty($_SESSION['als_csrf_token'])) {
        $_SESSION['als_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['als_csrf_token'];
}

function verify_csrf_token(?string $token): bool {
    if (empty($token) || empty($_SESSION['als_csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['als_csrf_token'], $token);
}

function get_admin_users(): array {
    if (!file_exists(ADMIN_USERS_JSON)) {
        return [];
    }
    $raw = file_get_contents(ADMIN_USERS_JSON);
    return json_decode($raw, true) ?: [];
}

function save_admin_users(array $users): bool {
    return file_put_contents(ADMIN_USERS_JSON, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
}

function get_enquiries(): array {
    if (!file_exists(ENQUIRIES_JSON)) {
        return [];
    }
    $raw = file_get_contents(ENQUIRIES_JSON);
    $data = json_decode($raw, true) ?: [];
    // Ensure default status
    foreach ($data as &$item) {
        if (!isset($item['status'])) {
            $item['status'] = 'New';
        }
    }
    return $data;
}

function save_enquiries(array $enquiries): bool {
    return file_put_contents(ENQUIRIES_JSON, json_encode($enquiries, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
}

function get_careers(): array {
    if (!file_exists(CAREERS_JSON)) {
        return [];
    }
    $raw = file_get_contents(CAREERS_JSON);
    $data = json_decode($raw, true) ?: [];
    foreach ($data as &$item) {
        if (!isset($item['status'])) {
            $item['status'] = 'New';
        }
    }
    return $data;
}

function save_careers(array $careers): bool {
    return file_put_contents(CAREERS_JSON, json_encode($careers, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
}

function get_site_content(): array {
    if (!file_exists(SITE_CONTENT_JSON)) {
        return [];
    }
    $raw = file_get_contents(SITE_CONTENT_JSON);
    return json_decode($raw, true) ?: [];
}

function save_site_content(array $content): bool {
    return file_put_contents(SITE_CONTENT_JSON, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
}
