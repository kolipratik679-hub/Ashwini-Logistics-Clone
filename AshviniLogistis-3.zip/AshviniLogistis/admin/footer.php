  </main>
  <footer style="padding: 18px 32px; border-top: 1px solid var(--line); font-size: 13px; color: var(--muted); display: flex; justify-content: space-between; align-items: center; background: #ffffff;">
    <span>Ashwini Logistics Solutions &bull; Fast &amp; Clean Admin CMS</span>
    <span>PHP <?php echo PHP_VERSION; ?> &bull; Active &amp; Secure</span>
  </footer>
</div>

</body>
</html>
