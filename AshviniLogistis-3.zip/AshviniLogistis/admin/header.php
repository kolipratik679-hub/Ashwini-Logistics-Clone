<?php
require_once __DIR__ . '/auth.php';
require_auth();

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$allEnquiries = get_enquiries();
$allCareers = get_careers();

$newEnquiriesCount = count(array_filter($allEnquiries, fn($e) => ($e['status'] ?? 'New') === 'New'));
$newCareersCount = count(array_filter($allCareers, fn($c) => ($c['status'] ?? 'New') === 'New'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo htmlspecialchars($pageTitle ?? 'Admin CMS'); ?> | Ashwini Logistics Solutions</title>
<link rel="icon" href="../assets/images/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../assets/css/fonts.css">
<style>
  :root {
    --navy: #102a38;
    --navy-deep: #0b202c;
    --navy-light: #183849;
    --orange: #fa6b39;
    --orange-hover: #ff8559;
    --bg-page: #f8fafc;
    --card-bg: #ffffff;
    --ink: #0f172a;
    --muted: #64748b;
    --line: #e2e8f0;
    --sidebar-width: 260px;
    --success: #16a34a;
    --success-bg: #dcfce7;
    --warning: #ca8a04;
    --warning-bg: #fef9c3;
    --danger: #dc2626;
    --danger-bg: #fee2e2;
    --info: #0284c7;
    --info-bg: #e0f2fe;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Gilmer', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: var(--bg-page);
    color: var(--ink);
    min-height: 100vh;
    display: flex;
  }
  a { color: inherit; text-decoration: none; }

  /* Sidebar */
  .sidebar {
    width: var(--sidebar-width);
    background: var(--navy-deep);
    color: #e2e8f0;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    z-index: 100;
    border-right: 1px solid rgba(255, 255, 255, 0.08);
  }
  .sidebar-brand {
    padding: 24px 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .sidebar-brand img {
    height: 38px;
    width: auto;
  }
  .sidebar-brand span {
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    color: var(--orange);
    text-transform: uppercase;
    display: block;
    margin-top: 4px;
  }
  .sidebar-nav {
    flex: 1;
    padding: 20px 12px;
    display: flex;
    flex-direction: column;
    gap: 6px;
    overflow-y: auto;
  }
  .nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 14.5px;
    font-weight: 600;
    color: #cbd5e1;
    transition: all 0.2s ease;
  }
  .nav-item:hover {
    background: rgba(255, 255, 255, 0.06);
    color: #ffffff;
  }
  .nav-item.active {
    background: var(--navy-light);
    color: #ffffff;
    border-left: 3px solid var(--orange);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }
  .nav-item svg {
    width: 18px;
    height: 18px;
    flex-shrink: 0;
  }
  .nav-badge {
    margin-left: auto;
    background: var(--orange);
    color: #0b202c;
    font-size: 11px;
    font-weight: 800;
    padding: 2px 7px;
    border-radius: 12px;
  }
  .sidebar-footer {
    padding: 16px;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .btn-live-site {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 9px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.08);
    font-size: 13px;
    font-weight: 600;
    color: #e2e8f0;
    transition: background 0.2s;
  }
  .btn-live-site:hover {
    background: rgba(255, 255, 255, 0.15);
    color: #ffffff;
  }
  .user-strip {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 13px;
    color: #94a3b8;
  }
  .btn-logout {
    color: #f87171;
    font-weight: 700;
    font-size: 12.5px;
    display: flex;
    align-items: center;
    gap: 4px;
  }
  .btn-logout:hover {
    text-decoration: underline;
  }

  /* Main Wrapper */
  .main-wrapper {
    margin-left: var(--sidebar-width);
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    min-width: 0;
  }

  /* Top Bar */
  .topbar {
    background: #ffffff;
    border-bottom: 1px solid var(--line);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 90;
  }
  .topbar-title h1 {
    font-size: 20px;
    font-weight: 800;
    color: var(--navy);
  }
  .topbar-title p {
    font-size: 13px;
    color: var(--muted);
    margin-top: 2px;
  }
  .topbar-actions {
    display: flex;
    align-items: center;
    gap: 16px;
  }
  .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
  }
  .status-new { background: var(--info-bg); color: var(--info); }
  .status-contacted { background: var(--warning-bg); color: var(--warning); }
  .status-converted { background: var(--success-bg); color: var(--success); }
  .status-archived { background: #f1f5f9; color: #64748b; }

  /* Page Content */
  .content {
    padding: 32px;
    flex: 1;
  }

  /* Cards */
  .card {
    background: var(--card-bg);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 24px;
    margin-bottom: 24px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  }
  .card-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
  }
  .card-header h2 {
    font-size: 17px;
    font-weight: 700;
    color: var(--navy);
  }

  /* Stat Grid */
  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 28px;
  }
  .stat-card {
    background: #ffffff;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 22px;
    display: flex;
    align-items: center;
    gap: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    transition: transform 0.2s, box-shadow 0.2s;
  }
  .stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.06);
  }
  .stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff7ed;
    color: var(--orange);
    flex-shrink: 0;
  }
  .stat-info span {
    font-size: 13px;
    color: var(--muted);
    font-weight: 600;
    display: block;
  }
  .stat-info strong {
    font-size: 26px;
    font-weight: 800;
    color: var(--navy);
    line-height: 1.2;
  }

  /* Table Styles */
  .table-responsive {
    overflow-x: auto;
    width: 100%;
  }
  table.data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
    text-align: left;
  }
  table.data-table th {
    background: #f8fafc;
    padding: 12px 16px;
    font-weight: 700;
    font-size: 12px;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid var(--line);
    white-space: nowrap;
  }
  table.data-table td {
    padding: 14px 16px;
    border-bottom: 1px solid var(--line);
    vertical-align: middle;
  }
  table.data-table tr:hover td {
    background: #fbfcfe;
  }

  /* Button Styles */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 9px 16px;
    border-radius: 6px;
    font-size: 13.5px;
    font-weight: 700;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
  }
  .btn-primary { background: var(--orange); color: #0b202c; }
  .btn-primary:hover { background: var(--orange-hover); }
  .btn-secondary { background: #f1f5f9; color: #334155; }
  .btn-secondary:hover { background: #e2e8f0; }
  .btn-danger { background: var(--danger-bg); color: var(--danger); }
  .btn-danger:hover { background: #fecaca; }
  .btn-sm { padding: 6px 10px; font-size: 12.5px; }

  /* Alerts */
  .alert {
    padding: 12px 18px;
    border-radius: 8px;
    font-size: 14px;
    margin-bottom: 24px;
  }
  .alert-success { background: var(--success-bg); color: var(--success); border: 1px solid #bbf7d0; }
  .alert-error { background: var(--danger-bg); color: var(--danger); border: 1px solid #fecaca; }

  @media (max-width: 900px) {
    .sidebar { width: 70px; }
    .sidebar-brand span, .nav-item span, .nav-badge, .sidebar-footer { display: none; }
    .main-wrapper { margin-left: 70px; }
    .topbar { padding: 16px; }
    .content { padding: 16px; }
  }
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-brand">
    <img src="../assets/images/logo-white.svg" alt="Ashwini Logistics">
    <div>
      <strong style="font-size: 14px; color: #fff; font-weight: 700;">CMS PORTAL</strong>
      <span>Admin Suite</span>
    </div>
  </div>

  <nav class="sidebar-nav">
    <a href="index.php" class="nav-item <?php echo ($currentPage === 'index') ? 'active' : ''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      <span>Dashboard</span>
    </a>

    <a href="enquiries.php" class="nav-item <?php echo ($currentPage === 'enquiries') ? 'active' : ''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
      <span>Quote Leads</span>
      <?php if ($newEnquiriesCount > 0): ?>
        <span class="nav-badge"><?php echo $newEnquiriesCount; ?></span>
      <?php endif; ?>
    </a>

    <a href="careers.php" class="nav-item <?php echo ($currentPage === 'careers') ? 'active' : ''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
      <span>Careers / Resumes</span>
      <?php if ($newCareersCount > 0): ?>
        <span class="nav-badge"><?php echo $newCareersCount; ?></span>
      <?php endif; ?>
    </a>

    <a href="settings.php" class="nav-item <?php echo ($currentPage === 'settings') ? 'active' : ''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      <span>Site Content &amp; Notice</span>
    </a>
  </nav>

  <div class="sidebar-footer">
    <a href="../index.php" target="_blank" class="btn-live-site">
      <span>View Live Website</span>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
    </a>
    <div class="user-strip">
      <span>Logged in as <b><?php echo htmlspecialchars($_SESSION['als_admin_user'] ?? 'Admin'); ?></b></span>
      <a href="logout.php" class="btn-logout" title="Log out">Sign out</a>
    </div>
  </div>
</aside>

<div class="main-wrapper">
  <header class="topbar">
    <div class="topbar-title">
      <h1><?php echo htmlspecialchars($pageTitle ?? 'Dashboard'); ?></h1>
      <p><?php echo htmlspecialchars($pageSubtitle ?? 'Ashwini Logistics Solutions Administrative Suite'); ?></p>
    </div>
    <div class="topbar-actions">
      <span style="font-size: 13px; color: var(--muted);"><?php echo date('D, d M Y'); ?></span>
      <a href="enquiries.php" class="btn btn-secondary btn-sm">
        <span>Recent Leads</span>
      </a>
      <a href="settings.php" class="btn btn-primary btn-sm">
        <span>Edit Site Notice</span>
      </a>
    </div>
  </header>
  <main class="content">
