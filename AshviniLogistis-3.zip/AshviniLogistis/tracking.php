<?php
$page_title = 'Live Consignment Tracking | Ashwini Logistics Solutions';
$page_description = 'Track your Ashwini Logistics consignment in real-time. Direct CTYF ERP integration, Gtropy GPS vehicle tracking and milestone notifications.';
$current_page = 'tracking';

include_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero">
<div class="wrap">
<span class="mini-label">CONSIGNMENT &amp; LR TRACKING</span>
<h1>Visibility you value.<br><b>Track your shipment.</b></h1>
<p class="hero-sub">Real-time vehicle and consignment visibility connected directly with our Gtropy fleet GPS and CTYF enterprise logistics portal.</p>
</div>
</section>

<section class="section">
<div class="wrap">
<div class="track-container" style="max-width: 860px; margin: 0 auto; background: #ffffff; border: 1px solid #e1e4e8; border-radius: 12px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
    
    <div style="margin-bottom: 24px;">
        <h2 style="font-size: 24px; margin-bottom: 8px; color: #102a38;">Enter Consignment / LR Number</h2>
        <p style="color: #57606a; margin: 0;">Enter your Lorry Receipt (LR) number, Docket number, or Container ID provided at the time of booking.</p>
    </div>

    <form id="tracking-search-form" style="display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 16px;">
        <input type="text" id="lr-input" name="lr" placeholder="e.g. AL-89210 or MH-43-902" required 
               style="flex: 1; min-width: 250px; padding: 14px 18px; border: 2px solid #d0d7de; border-radius: 8px; font-size: 16px; font-family: inherit; outline: none; transition: border-color 0.2s;"
               onfocus="this.style.borderColor='#ff6a00'" onblur="this.style.borderColor='#d0d7de'">
        <button type="submit" class="button orange" style="padding: 14px 28px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
            <span>Track Now</span>
            <svg class="icon" style="width: 18px; height: 18px;"><use href="#i-ne"/></svg>
        </button>
    </form>

    <div style="font-size: 13px; color: #6e7781; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
        <span>Sample Numbers:</span>
        <button type="button" onclick="setLrSample('AL-78401')" style="background: #f6f8fa; border: 1px solid #d0d7de; padding: 4px 10px; border-radius: 4px; font-size: 12px; cursor: pointer;">AL-78401</button>
        <button type="button" onclick="setLrSample('JNPT-5521')" style="background: #f6f8fa; border: 1px solid #d0d7de; padding: 4px 10px; border-radius: 4px; font-size: 12px; cursor: pointer;">JNPT-5521</button>
        <button type="button" onclick="setLrSample('DEL-90142')" style="background: #f6f8fa; border: 1px solid #d0d7de; padding: 4px 10px; border-radius: 4px; font-size: 12px; cursor: pointer;">DEL-90142</button>
    </div>

    <!-- Tracking Result Box -->
    <div id="tracking-result-box" style="display: none; margin-top: 32px; border-top: 2px solid #f0f2f5; padding-top: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px;">
            <div>
                <span style="font-size: 12px; text-transform: uppercase; color: #6e7781; letter-spacing: 0.5px;">Consignment Note</span>
                <h3 id="res-lr" style="margin: 0; font-size: 22px; color: #102a38;">-</h3>
            </div>
            <div>
                <span id="res-badge" style="background: #e6f4ea; color: #137333; font-weight: 700; padding: 6px 14px; border-radius: 20px; font-size: 14px; display: inline-block;">-</span>
            </div>
        </div>

        <!-- Key metrics grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 24px; border: 1px solid #e2e8f0;">
            <div>
                <span style="font-size: 12px; color: #64748b; display: block;">Origin Hub</span>
                <strong id="res-origin" style="color: #0f172a; font-size: 15px;">-</strong>
            </div>
            <div>
                <span style="font-size: 12px; color: #64748b; display: block;">Destination Location</span>
                <strong id="res-dest" style="color: #0f172a; font-size: 15px;">-</strong>
            </div>
            <div>
                <span style="font-size: 12px; color: #64748b; display: block;">Allocated Vehicle</span>
                <strong id="res-vehicle" style="color: #0f172a; font-size: 15px;">-</strong>
            </div>
            <div>
                <span style="font-size: 12px; color: #64748b; display: block;">Delivery Timeline</span>
                <strong id="res-eta" style="color: #ff6a00; font-size: 15px;">-</strong>
            </div>
        </div>

        <!-- Milestone Timeline -->
        <h4 style="margin: 0 0 16px; color: #102a38; font-size: 16px;">Movement History &amp; Checkpoints</h4>
        <div id="timeline-list" style="position: relative; padding-left: 24px; margin-bottom: 24px; border-left: 2px solid #e2e8f0;">
            <!-- Rendered by JS -->
        </div>

        <!-- Portal Redirection Box -->
        <div style="background: #102a38; color: #ffffff; padding: 20px 24px; border-radius: 8px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
            <div>
                <strong style="display: block; font-size: 16px; color: #ffffff;">Need Proof of Delivery (POD) or Invoices?</strong>
                <span style="color: #cbd5e1; font-size: 13px;">Login with your authorized consignor account on the CTYF ERP Portal.</span>
            </div>
            <a id="btn-portal-login" href="https://ctyf.co.in/SiteLogin.aspx" target="_blank" rel="noopener noreferrer" 
               class="button orange" style="padding: 10px 20px; font-size: 14px; white-space: nowrap;">
                <span>Open CTYF ERP Portal</span>
                <svg class="icon" style="width: 14px; height: 14px;"><use href="#i-ne"/></svg>
            </a>
        </div>
    </div>

    <!-- Direct CTYF Portal Callout -->
    <div style="margin-top: 32px; background: #fff8f2; border: 1px solid #ffd8bf; padding: 20px; border-radius: 8px;">
        <div style="display: flex; gap: 16px; align-items: flex-start;">
            <svg class="icon" style="width: 28px; height: 28px; color: #ff6a00; flex-shrink: 0;"><use href="#i-shield"/></svg>
            <div>
                <h4 style="margin: 0 0 6px; color: #873800; font-size: 16px;">Direct Enterprise CTYF Portal Access</h4>
                <p style="margin: 0 0 12px; color: #5c3b1e; font-size: 14px; line-height: 1.5;">
                    If you already have corporate vendor/client credentials for the <strong>CTYF Logistics System (ctyf.co.in)</strong>, you can access the full ERP dashboard directly including billing, e-way bills, vehicle trip sheets and live GPS telematics.
                </p>
                <a href="https://ctyf.co.in/SiteLogin.aspx" target="_blank" rel="noopener noreferrer" style="color: #ff6a00; font-weight: 700; text-decoration: underline; font-size: 14px;">
                    Go to CTYF Login (ctyf.co.in/SiteLogin.aspx) →
                </a>
            </div>
        </div>
    </div>

    <!-- Helpdesk Contact -->
    <div style="margin-top: 24px; padding: 16px; background: #f6f8fa; border-radius: 8px; font-size: 13px; color: #57606a; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
        <div>
            <strong>Operations Helpdesk:</strong> <?php echo CONTACT_PHONE; ?>
        </div>
        <div>
            <strong>Tracking Inquiries:</strong> <?php echo TRACKING_EMAIL; ?>
        </div>
    </div>

</div>
</div>
</section>
</main>

<script>
function setLrSample(num) {
    const input = document.getElementById('lr-input');
    input.value = num;
    document.getElementById('tracking-search-form').dispatchEvent(new Event('submit'));
}

document.getElementById('tracking-search-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const lr = document.getElementById('lr-input').value.trim();
    if (!lr) return;

    const resBox = document.getElementById('tracking-result-box');
    
    fetch('track.php?lr=' + encodeURIComponent(lr))
        .then(response => response.json())
        .then(data => {
            if (!data.success) {
                alert(data.message || 'Tracking details not found.');
                return;
            }
            const t = data.tracking_data;
            document.getElementById('res-lr').textContent = t.lr_number;
            document.getElementById('res-origin').textContent = t.origin;
            document.getElementById('res-dest').textContent = t.destination;
            document.getElementById('res-vehicle').textContent = t.vehicle_number;
            document.getElementById('res-eta').textContent = t.expected_delivery;

            const badge = document.getElementById('res-badge');
            badge.textContent = t.current_status;
            if (t.current_status === 'Delivered') {
                badge.style.background = '#e6f4ea';
                badge.style.color = '#137333';
            } else {
                badge.style.background = '#fff4e5';
                badge.style.color = '#b06000';
            }

            // Render Timeline
            const list = document.getElementById('timeline-list');
            list.innerHTML = '';
            t.timeline.forEach((item, idx) => {
                const step = document.createElement('div');
                step.style.position = 'relative';
                step.style.marginBottom = '20px';
                step.style.paddingLeft = '12px';

                const dot = document.createElement('span');
                dot.style.position = 'absolute';
                dot.style.left = '-31px';
                dot.style.top = '2px';
                dot.style.width = '14px';
                dot.style.height = '14px';
                dot.style.borderRadius = '50%';
                dot.style.background = item.done ? '#ff6a00' : '#cbd5e1';
                dot.style.border = '2px solid #ffffff';
                dot.style.boxShadow = '0 0 0 2px ' + (item.done ? '#ff6a00' : '#cbd5e1');

                step.appendChild(dot);
                step.innerHTML += `
                    <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                        <strong style="color: ${item.done ? '#102a38' : '#94a3b8'}; font-size: 15px;">${item.status}</strong>
                        <span style="font-size: 13px; color: #64748b;">${item.time}</span>
                    </div>
                    <div style="font-size: 13px; color: #475569; margin-top: 2px;">${item.location}</div>
                    <div style="font-size: 12px; color: #64748b; margin-top: 4px; font-style: italic;">${item.notes}</div>
                `;
                list.appendChild(step);
            });

            resBox.style.display = 'block';
            resBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        })
        .catch(err => {
            console.error('Error fetching tracking info:', err);
            alert('Failed to connect with tracking service. Please try again.');
        });
});
</script>

<?php
include_once __DIR__ . '/includes/footer.php';
?>
