<?php
/**
 * Native PHP TLS SMTP Socket Mailer with Attachment Support
 * Zero external dependencies, supports Gmail / cPanel / Hostinger SMTP over TLS
 */

function send_smtp_email($to, $subject, $htmlBody, $textBody = '', $replyTo = null, $replyToName = null, $attachments = []) {
    $host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
    $port = defined('SMTP_PORT') ? SMTP_PORT : 587;
    $user = defined('SMTP_USER') ? SMTP_USER : '';
    $rawPass = defined('SMTP_PASS') ? SMTP_PASS : '';
    $pass = str_replace(' ', '', $rawPass);
    $from = defined('MAIL_FROM_ADDRESS') ? MAIL_FROM_ADDRESS : $user;
    $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'Ashwini Logistics Website';
    $secure = defined('SMTP_SECURE') ? SMTP_SECURE : 'tls';

    $timeout = 10;
    $errno = 0;
    $errstr = '';

    $connectPrefix = ($secure === 'ssl') ? 'ssl://' : 'tcp://';
    $socket = @stream_socket_client("{$connectPrefix}{$host}:{$port}", $errno, $errstr, $timeout);
    if (!$socket) {
        return ['success' => false, 'error' => "SMTP Connection failed: $errstr ($errno)"];
    }

    stream_set_timeout($socket, $timeout);

    $readResponse = function() use ($socket) {
        $response = '';
        while (!feof($socket)) {
            $line = fgets($socket, 515);
            if ($line === false) break;
            $response .= $line;
            if (strlen($line) >= 4 && substr($line, 3, 1) === ' ') break;
        }
        return $response;
    };

    $sendCommand = function($cmd, $expectedCode) use ($socket, $readResponse) {
        fwrite($socket, $cmd . "\r\n");
        $res = $readResponse();
        $code = substr($res, 0, 3);
        if ($code !== (string)$expectedCode) {
            throw new Exception("SMTP command [$cmd] failed: $res");
        }
        return $res;
    };

    try {
        $greeting = $readResponse();
        if (substr($greeting, 0, 3) !== '220') {
            throw new Exception("Unexpected SMTP greeting: $greeting");
        }

        $clientHost = !empty($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost';
        $sendCommand("EHLO $clientHost", 250);

        if ($secure === 'tls') {
            $sendCommand("STARTTLS", 220);
            $cryptoMethod = STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
            }
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
                $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
            }
            if (!stream_socket_enable_crypto($socket, true, $cryptoMethod)) {
                throw new Exception("TLS encryption handshake failed");
            }
            $sendCommand("EHLO $clientHost", 250);
        }

        if (!empty($user) && !empty($pass)) {
            $sendCommand("AUTH LOGIN", 334);
            $sendCommand(base64_encode($user), 334);
            $sendCommand(base64_encode($pass), 235);
        }

        $sendCommand("MAIL FROM: <{$from}>", 250);
        $sendCommand("RCPT TO: <{$to}>", 250);
        $sendCommand("DATA", 354);

        $headers = [];
        $headers[] = "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <{$from}>";
        $headers[] = "To: <{$to}>";
        if (!empty($replyTo)) {
            $repName = $replyToName ?: $replyTo;
            $headers[] = "Reply-To: =?UTF-8?B?" . base64_encode($repName) . "?= <{$replyTo}>";
        }
        $headers[] = "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=";
        $headers[] = "Date: " . date('r');
        $headers[] = "Message-ID: <" . md5(uniqid((string)microtime(true), true)) . "@" . $host . ">";
        $headers[] = "MIME-Version: 1.0";
        $headers[] = "X-Mailer: PHP-Native-TLS-SMTP";

        $hasAttachments = !empty($attachments) && is_array($attachments);

        if ($hasAttachments) {
            $mixedBoundary = "----=_Part_Mixed_" . md5(uniqid((string)time(), true));
            $altBoundary   = "----=_Part_Alt_" . md5(uniqid((string)time(), true));

            $headers[] = "Content-Type: multipart/mixed; boundary=\"{$mixedBoundary}\"";
            $body = implode("\r\n", $headers) . "\r\n\r\n";

            // Part 1: multipart/alternative (text + html)
            $body .= "--{$mixedBoundary}\r\n";
            $body .= "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\"\r\n\r\n";

            if (!empty($textBody)) {
                $body .= "--{$altBoundary}\r\n";
                $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
                $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
                $body .= $textBody . "\r\n\r\n";
            }

            $body .= "--{$altBoundary}\r\n";
            $body .= "Content-Type: text/html; charset=UTF-8\r\n";
            $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $body .= $htmlBody . "\r\n\r\n";
            $body .= "--{$altBoundary}--\r\n\r\n";

            // Part 2: Attachments
            foreach ($attachments as $att) {
                if (empty($att['path']) || !file_exists($att['path'])) continue;
                $fileName = !empty($att['name']) ? $att['name'] : basename($att['path']);
                $mimeType = !empty($att['mime']) ? $att['mime'] : 'application/octet-stream';
                $fileData = file_get_contents($att['path']);
                $encodedData = chunk_split(base64_encode($fileData));

                $body .= "--{$mixedBoundary}\r\n";
                $body .= "Content-Type: {$mimeType}; name=\"=?UTF-8?B?" . base64_encode($fileName) . "?=\"\r\n";
                $body .= "Content-Transfer-Encoding: base64\r\n";
                $body .= "Content-Disposition: attachment; filename=\"=?UTF-8?B?" . base64_encode($fileName) . "?=\"\r\n\r\n";
                $body .= $encodedData . "\r\n";
            }

            $body .= "--{$mixedBoundary}--\r\n";
        } else {
            $altBoundary = "----=_Part_Alt_" . md5(uniqid((string)time(), true));
            $headers[] = "Content-Type: multipart/alternative; boundary=\"{$altBoundary}\"";
            $body = implode("\r\n", $headers) . "\r\n\r\n";

            if (!empty($textBody)) {
                $body .= "--{$altBoundary}\r\n";
                $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
                $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
                $body .= $textBody . "\r\n\r\n";
            }

            $body .= "--{$altBoundary}\r\n";
            $body .= "Content-Type: text/html; charset=UTF-8\r\n";
            $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $body .= $htmlBody . "\r\n\r\n";
            $body .= "--{$altBoundary}--\r\n";
        }

        fwrite($socket, $body . "\r\n.\r\n");
        $dataRes = $readResponse();
        if (substr($dataRes, 0, 3) !== '250') {
            throw new Exception("DATA rejected: $dataRes");
        }

        $sendCommand("QUIT", 221);
        fclose($socket);

        return ['success' => true, 'response' => trim($dataRes)];
    } catch (Exception $e) {
        if (is_resource($socket)) {
            @fwrite($socket, "QUIT\r\n");
            @fclose($socket);
        }
        return ['success' => false, 'error' => $e->getMessage()];
    }
}
