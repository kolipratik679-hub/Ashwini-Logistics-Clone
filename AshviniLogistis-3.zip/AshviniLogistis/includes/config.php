<?php
/**
 * Ashwini Logistics Solutions - Configuration File
 */

// Define Environment & Base URL
if (!defined('BASE_URL')) {
    // Dynamic detection of HTTP scheme and host
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    // If inside solutions/ subfolder, strip /solutions
    $projectDir = preg_replace('/\/solutions$/i', '', $scriptDir);
    define('BASE_URL', rtrim($protocol . $host . $projectDir, '/') . '/');
}

// Dynamic Content Overrides from CMS
$siteContentFile = __DIR__ . '/../data/site_content.json';
$siteContent = [];
if (file_exists($siteContentFile)) {
    $rawContent = file_get_contents($siteContentFile);
    $siteContent = json_decode($rawContent, true) ?: [];
}

// Company Contact Info (with CMS override support)
define('SITE_NAME', 'Ashwini Logistics Solutions');
define('SITE_TAGLINE', 'Reliability, Delivered.');
define('SITE_ANNOUNCEMENT', $siteContent['top_announcement'] ?? 'PAN-INDIA STRENGTH. GLOBAL POSSIBILITIES.');
define('TOP_CTA_TEXT', $siteContent['top_cta_text'] ?? 'Let’s talk logistics');
define('CONTACT_PHONE', $siteContent['contact_phone'] ?? '+91 22 4031 2345');
define('CONTACT_PHONE_RAW', $siteContent['contact_phone_raw'] ?? '+912240312345');
define('CONTACT_EMAIL', $siteContent['contact_email'] ?? 'info@ashwinilogistics.in');
define('TRACKING_EMAIL', $siteContent['tracking_email'] ?? 'tracking@ashwinilogistics.in');
define('OFFICE_ADDRESS', $siteContent['office_address'] ?? 'Shelton Sapphire, CBD Belapur, Navi Mumbai, Maharashtra 400614, India');
define('HELPDESK_HOURS', $siteContent['helpdesk_hours'] ?? 'Mon–Sat, 10:00–19:00 IST');

// Stats (with CMS override support)
define('STAT_VEHICLES', $siteContent['stat_vehicles'] ?? '500+');
define('STAT_BRANCHES', $siteContent['stat_branches'] ?? '18+');
define('STAT_EXPERIENCE', $siteContent['stat_experience'] ?? '3+');
define('STAT_TRIPS_MONTH', $siteContent['stat_trips_month'] ?? '10,000+');
define('STAT_WAREHOUSE_SQFT', $siteContent['stat_warehouse_sqft'] ?? '400,000+');

// Tracking Configuration (CTYF ERP Portal & Gtropy Fleet GPS)
define('CTYF_PORTAL_URL', 'https://ctyf.co.in/SiteLogin.aspx');
define('GTROPY_PORTAL_URL', 'https://gtropy.com');

// Mailer / SMTP Configuration
// Active driver: 'smtp' (using Gmail TLS SMTP socket transport)
define('MAIL_DRIVER', 'smtp');
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // 'tls' or 'ssl'
define('SMTP_USER', 'kolipratik679@gmail.com');
define('SMTP_PASS', 'femg xhgm sqmn qfzg');
define('MAIL_FROM_ADDRESS', 'kolipratik679@gmail.com');
define('MAIL_FROM_NAME', 'Ashwini Logistics Website');
define('MAIL_TO_ADDRESS', 'kolipratik679@gmail.com');

// Enquiry Log File Path (ensures zero lost leads even when mail server is offline)
define('ENQUIRY_LOG_FILE', __DIR__ . '/../data/enquiries.json');
define('ENQUIRY_CSV_FILE', __DIR__ . '/../data/enquiries.csv');
