<?php
$page_title = "Logistics Solutions | Transport, Warehousing, Freight &amp; Project Cargo | Ashwini Logistics Solutions";
$page_description = "One partner. Solutions for every movement — pan-India transport, global warehousing, freight forwarding & customs, ODC & project cargo, containerised cargo and tanker transport.";
$current_page = "services";
require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-hub.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> OUR SOLUTIONS</div>
<h1>One partner.<br><em>Solutions for every movement.</em></h1>
<p>Your cargo may need a regular transport route, space between production and delivery, or a carefully planned international shipment. Ashwini brings these requirements together around the way your business operates.</p>
<p class="hero-hint">Choose a solution to explore its scope and share your requirements with our team.</p>
</div></section>
<section class="services section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SOLUTION OVERVIEW</div><h2>Six solutions.<br>The same standard.</h2></div><p>Every solution runs on the same owned fleet,<br>the same people and the same standard of care.</p></div>
<div class="hub-grid">
<a class="hub-card" href="<?php echo $base_path; ?>solutions/pan-india-transport.php"><span class="hub-num">01</span><svg class="icon"><use href="#i-truck"/></svg><h3>Pan-India Transport</h3><p>Full-truckload and part-load movement backed by owned capacity and a connected branch network.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
<a class="hub-card" href="<?php echo $base_path; ?>solutions/global-warehousing.php"><span class="hub-num">02</span><svg class="icon"><use href="#i-box"/></svg><h3>Global Warehousing</h3><p>Storage, consolidation and distribution to support the flow of goods.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
<a class="hub-card" href="<?php echo $base_path; ?>solutions/freight-forwarding-customs.php"><span class="hub-num">03</span><svg class="icon"><use href="#i-globe"/></svg><h3>Freight Forwarding &amp; Customs</h3><p>Sea and air freight with customs coordination.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
<a class="hub-card" href="<?php echo $base_path; ?>solutions/odc-project-cargo.php"><span class="hub-num">04</span><svg class="icon"><use href="#i-shield"/></svg><h3>ODC &amp; Project Cargo</h3><p>Planned movement for cargo that needs specialist route and equipment assessment.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
<a class="hub-card" href="<?php echo $base_path; ?>solutions/containerised-cargo.php"><span class="hub-num">05</span><svg class="icon"><use href="#i-box"/></svg><h3>Containerised Cargo</h3><p>Container movement planned around cargo, route and handling requirements.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
<a class="hub-card" href="<?php echo $base_path; ?>solutions/tanker-transport.php"><span class="hub-num">06</span><svg class="icon"><use href="#i-truck"/></svg><h3>Tanker Transport</h3><p>Vehicle suitability assessed against cargo and operating needs.</p><span class="circle-link">Explore the solution <span><svg class="icon"><use href="#i-ne"/></svg></span></span></a>
</div>
</div></section>
<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>One partner.<br><em>Every mile.</em></h2><p>Tell us what’s moving.<br>We’ll tell you how.</p></div><a class="button orange" href="contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
