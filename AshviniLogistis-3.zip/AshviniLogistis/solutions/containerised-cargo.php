<?php
$page_title = "Containerised Cargo | Door-to-Door Container Movement | Ashwini Logistics Solutions";
$page_description = "Container movement planned around cargo, route and handling requirements — port-linked movement, factory dispatch and warehouse transfers. Discuss your container movement.";
$current_page = "containerised-cargo";
require_once __DIR__ . '/../includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-containers.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> CONTAINERISED CARGO</div>
<h1>Container movement.<br><em>Clearly coordinated.</em></h1>
<p>Containerised cargo needs a plan that considers the load, route and delivery requirements together. Ashwini supports container movement as part of its transport offering, helping customers coordinate the journey around the needs of their cargo.</p>
<a class="button orange" href="<?php echo $base_path; ?>contact.php">Discuss your container movement <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="detail section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SCOPE</div><h2>A plan for the container<br>and its cargo.</h2></div><p>The movement starts<br>with the details.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Share the details.</h3><p>Share the container type, cargo, gross weight, collection point and destination.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Route &amp; arrangement review.</h3><p>The team reviews the route and suitable movement arrangement, including the loading and delivery conditions that affect the operation.</p></article>
</div>
</section>

<section class="services section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> USE CASES</div><h2>Where container movement<br>fits your operation.</h2></div><p>Subject to route and<br>equipment availability.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Port-linked movement.</h3><p>Between ports, terminals and inland destinations.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Factory dispatch.</h3><p>Containers moved directly from production to the next leg of the journey.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Warehouse transfers.</h3><p>Stock movements between storage locations as part of a wider plan.</p></article>
</div>
<a class="text-link section-cta" href="<?php echo $base_path; ?>contact.php">Share your collection and delivery points <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> QUESTIONS</div><h2>Container cargo FAQs.</h2></div></div>
<dl class="faq-list">
<div><dt>Which containers can you move?</dt><dd>Share the type, dimensions and gross weight so the team can confirm equipment suitability.</dd></div>
<div><dt>Can you arrange a port-linked movement?</dt><dd>Send the port, terminal and inland destination for an assessment of the available scope.</dd></div>
<div><dt>How do you handle tracking and security?</dt><dd>The team will explain the tracking, seal and handover arrangements agreed for the movement.</dd></div>
</dl>
<a class="text-link faq-cta" href="<?php echo $base_path; ?>contact.php">Discuss your container movement <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>One seal.<br><em>One chain of custody.</em></h2><p>Sealed, tracked and moved door to door.<br>Tell us the container and the route.</p></div><a class="button orange" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
