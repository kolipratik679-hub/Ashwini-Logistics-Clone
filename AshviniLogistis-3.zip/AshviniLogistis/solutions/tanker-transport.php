<?php
$page_title = "Tanker Transport | Vehicle Suitability Assessment | Ashwini Logistics Solutions";
$page_description = "Tanker movement within our pan-India transport offering — vehicle suitability assessed against cargo specifications and operating requirements. Request an assessment.";
$current_page = "tanker-transport";
require_once __DIR__ . '/../includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-tanker.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> TANKER TRANSPORT</div>
<h1>The right arrangement<br><em>for your cargo.</em></h1>
<p>Tanker transport requires careful attention to the cargo and the vehicle that carries it. Ashwini includes tanker movement within its pan-India transport offering. Share your cargo specifications and operating requirements so our team can assess a suitable arrangement.</p>
<a class="button orange" href="<?php echo $base_path; ?>contact.php">Discuss your tanker requirement <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="detail section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SCOPE</div><h2>Cargo requirements<br>before vehicle selection.</h2></div><p>Suitability comes first.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Specify the cargo.</h3><p>A tanker requirement starts with the material, quantity, route and loading conditions. Share the relevant cargo specifications, compatibility requirements and any documentation needed to assess the movement.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Confirm before dispatch.</h3><p>The team confirms vehicle availability and the agreed handling scope before the movement proceeds.</p></article>
</div>
</section>

<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> QUESTIONS</div><h2>Tanker transport FAQs.</h2></div></div>
<dl class="faq-list">
<div><dt>Which materials can you carry?</dt><dd>Send the material specification and relevant safety information. Acceptance depends on confirmed vehicle suitability and operating scope.</dd></div>
<div><dt>Can you support recurring requirements?</dt><dd>Share the route, quantity and frequency so the team can assess an arrangement.</dd></div>
<div><dt>What do you need to quote?</dt><dd>Cargo specification, quantity, origin, destination, dates, loading and unloading requirements.</dd></div>
</dl>
<a class="text-link faq-cta" href="<?php echo $base_path; ?>contact.php">Request a suitability assessment <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>The right vehicle.<br><em>The same commitment.</em></h2><p>Share the cargo and the route.<br>We’ll confirm the arrangement.</p></div><a class="button orange" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
