<?php
$page_title = "Freight Forwarding &amp; Customs | Sea &amp; Air Freight | Ashwini Logistics Solutions";
$page_description = "Sea and air freight forwarding with customs coordination. Share origin, destination, cargo details and shipping date to plan your international shipment.";
$current_page = "freight-forwarding-customs";
require_once __DIR__ . '/../includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-freight.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> FREIGHT FORWARDING &amp; CUSTOMS</div>
<h1>A clearer plan for<br><em>cargo across borders.</em></h1>
<p>International shipments involve transport choices and documentation requirements that need to work together. Ashwini supports sea and air freight forwarding with customs handling, helping businesses coordinate the movement of cargo across borders.</p>
<a class="button orange" href="<?php echo $base_path; ?>contact.php">Plan your international shipment <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="detail section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SCOPE</div><h2>Sea freight, air freight<br>and customs.</h2></div><p>Transport choices and documentation<br>that work together.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Sea freight.</h3><p>Explore a sea freight arrangement based on shipment size, route and schedule. The team confirms available options for your cargo.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Air freight.</h3><p>Discuss cargo requirements and timing to assess an appropriate air freight arrangement.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Customs coordination.</h3><p>Review documentation and clearance requirements as part of the shipment plan. The agreed scope determines the support provided.</p></article>
</div>
</section>

<section class="services section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> HOW IT WORKS</div><h2>A shipment plan with<br>clear responsibilities.</h2></div><p>Clear information at the start helps the team<br>identify requirements before cargo moves.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">STEP 1</span><h3>Share the shipment.</h3><p>Share origin, destination, cargo details and the expected shipping date.</p></article>
<article class="pcard"><span class="pnum">STEP 2</span><h3>Mode review.</h3><p>Review the suitable freight mode and available movement options.</p></article>
<article class="pcard"><span class="pnum">STEP 3</span><h3>Agree the scope.</h3><p>Agree the quote, documentation responsibilities and customs support scope.</p></article>
<article class="pcard"><span class="pnum">STEP 4</span><h3>Coordinate &amp; update.</h3><p>Coordinate the shipment and relevant milestone updates.</p></article>
</div>
</div></section>

<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> QUESTIONS</div><h2>Freight FAQs.</h2></div></div>
<dl class="faq-list">
<div><dt>Should I choose sea or air freight?</dt><dd>The choice depends on shipment size, urgency, route and budget. Our team can discuss the options available.</dd></div>
<div><dt>Can you help with customs requirements?</dt><dd>Customs handling forms part of the offering. The team confirms the relevant scope for your shipment.</dd></div>
<div><dt>What details should I send?</dt><dd>Origin, destination, cargo description, weight, dimensions, shipping date and any special requirements.</dd></div>
</dl>
<a class="text-link faq-cta" href="<?php echo $base_path; ?>contact.php">Share your shipment details <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Beyond the border.<br><em>Within the plan.</em></h2><p>Tell us the origin, destination and cargo.<br>We’ll help you shape the shipment.</p></div><a class="button orange" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
