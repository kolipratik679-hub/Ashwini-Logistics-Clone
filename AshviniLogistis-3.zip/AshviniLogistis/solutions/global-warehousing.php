<?php
$page_title = "Global Warehousing | Storage, Consolidation &amp; Distribution | Ashwini Logistics Solutions";
$page_description = "Storage, consolidation and distribution to support the flow of goods — coordinated stock movement in India and beyond. Discuss your storage requirement with our team.";
$current_page = "global-warehousing";
require_once __DIR__ . '/../includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-warehousing.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> GLOBAL WAREHOUSING</div>
<h1>Space that supports<br><em>your next move.</em></h1>
<p>Goods need more than a place to wait. They need a storage plan that fits the next stage of their journey. Ashwini’s warehousing offering brings storage, consolidation and distribution together, helping businesses coordinate stock movement in India and beyond.</p>
<a class="button orange" href="<?php echo $base_path; ?>contact.php">Discuss your storage requirement <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="detail section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SCOPE</div><h2>Storage, consolidation<br>and distribution.</h2></div><p>Three parts of one plan —<br>each shaped around your cargo.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Storage.</h3><p>Discuss the space, duration and handling conditions your cargo requires. The team assesses the appropriate arrangement against available facilities.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Consolidation.</h3><p>Plan how goods from different movements come together before onward dispatch.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Distribution.</h3><p>Connect storage requirements with outbound transport so the next movement forms part of the plan.</p></article>
</div>
</section>

<section class="facility-band section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> THE FACILITY</div><h2>Built to keep<br>goods moving.</h2></div><p>Storage built around<br>the next movement.</p></div>
<div class="facility-grid">
<figure class="facility-card facility-wide"><img src="<?php echo $base_path; ?>assets/images/facility/facility.jpg" alt="Ashwini Logistics Solutions warehouse facility — front elevation" width="800" height="600" loading="lazy"></figure>
<figure class="facility-card"><img src="<?php echo $base_path; ?>assets/images/facility/facility-inside.jpg" alt="Warehouse interior — racking and handling operations" width="800" height="1067" loading="lazy"></figure>
<figure class="facility-card"><img src="<?php echo $base_path; ?>assets/images/facility/facility-landscape.jpg" alt="Warehouse approach road and yard" width="800" height="1067" loading="lazy"></figure>
</div>
</div></section>

<section class="services section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> PLANNING</div><h2>A warehouse plan starts<br>with the cargo.</h2></div><p>The right arrangement depends<br>on what you store.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Cargo &amp; handling needs.</h3><p>The nature of the goods and the conditions they require while stored.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Inbound movement.</h3><p>How goods arrive — frequency, mode and volumes feeding the storage plan.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Storage duration &amp; outbound schedule.</h3><p>Expected holding period and dispatch pattern, assessed together with space requirements.</p></article>
</div>
<p class="solutions-note">A short holding period and a continuing distribution operation need different plans. Share your cargo type, expected volumes, storage duration and dispatch pattern. This helps our team assess the space and movement requirements together — including location requirements.</p>
</div></section>

<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> QUESTIONS</div><h2>Warehousing FAQs.</h2></div></div>
<dl class="faq-list">
<div><dt>Where are your warehouse facilities?</dt><dd>Contact the team for current options relevant to your location and cargo.</dd></div>
<div><dt>Can warehousing connect with transport?</dt><dd>Share your inbound and outbound requirements so the team can assess a coordinated scope.</dd></div>
<div><dt>What information is needed for a quote?</dt><dd>Cargo type, quantity, space requirements, duration, location and handling needs.</dd></div>
</dl>
<a class="text-link faq-cta" href="<?php echo $base_path; ?>contact.php">Tell us what you need to store <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Room to store.<br><em>Room to grow.</em></h2><p>Tell us the cargo and the journey<br>that follows storage.</p></div><a class="button orange" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
