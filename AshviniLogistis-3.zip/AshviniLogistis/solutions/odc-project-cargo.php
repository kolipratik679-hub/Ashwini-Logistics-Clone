<?php
$page_title = "ODC &amp; Project Cargo | Route Surveys, Permits &amp; Escorts | Ashwini Logistics Solutions";
$page_description = "Planned movement for over-dimensional and project cargo — route surveys, permit management and escort arrangements where required. Share your cargo specifications.";
$current_page = "odc-project-cargo";
require_once __DIR__ . '/../includes/header.php';
?>

<main id="main">
<section class="page-hero photo-hero"><img class="hero-img" src="<?php echo $base_path; ?>assets/images/heroes/hero-odc.jpg" alt="" aria-hidden="true"><div class="hero-veil"></div><div class="wrap">
<div class="eyebrow light"><span></span> ODC &amp; PROJECT CARGO</div>
<h1>A considered plan<br><em>for a complex load.</em></h1>
<p>Oversized and project cargo need careful assessment before the journey begins. Ashwini plans these movements around the dimensions of the load, route conditions and handling requirements, with route surveys, permit management and escort arrangements where required.</p>
<a class="button orange" href="<?php echo $base_path; ?>contact.php">Discuss your project cargo <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="detail section wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> SCOPE</div><h2>The details that<br>shape the movement.</h2></div><p>Assessed before the journey begins,<br>not after it starts.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Cargo assessment.</h3><p>Review dimensions, weight, lifting points and handling constraints before selecting the movement arrangement.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>Route planning.</h3><p>Assess the proposed route and relevant access restrictions through the required survey process.</p></article>
<article class="pcard"><span class="pnum">03</span><h3>Movement coordination.</h3><p>Confirm equipment suitability, permit requirements and escort arrangements as part of the agreed plan.</p></article>
</div>
</section>

<section class="services section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> EXPERIENCE</div><h2>Experience with demanding<br>cargo movements.</h2></div><p>The loads other transporters<br>quote high on are our routine.</p></div>
<div class="detail-grid">
<article class="pcard"><span class="pnum">01</span><h3>Hydro project work.</h3><p>Our company profile records ODC work connected with the Tehri and Kishan Ganga hydro projects — demanding movements planned around fixed sites and heavy loads.</p></article>
<article class="pcard"><span class="pnum">02</span><h3>How we tell the story.</h3><p>Every project is documented around project context, the cargo challenge, planning scope, execution responsibilities and the documented result.</p></article>
</div>
</div></section>

<section class="values section"><div class="wrap">
<div class="section-heading"><div><div class="eyebrow"><span></span> QUESTIONS</div><h2>Project cargo FAQs.</h2></div></div>
<dl class="faq-list">
<div><dt>What counts as over-dimensional cargo?</dt><dd>Cargo exceeding relevant standard dimensions needs assessment against the proposed route and applicable requirements. Share the specifications for review.</dd></div>
<div><dt>When should we involve your team?</dt><dd>At the planning stage, before the dispatch date and movement arrangement are fixed.</dd></div>
<div><dt>What information do you need?</dt><dd>Drawings, dimensions, weight, origin, destination, schedule and handling constraints.</dd></div>
</dl>
<a class="text-link faq-cta" href="<?php echo $base_path; ?>contact.php">Send your cargo specifications <svg class="icon"><use href="#i-ne"/></svg></a>
</div></section>

<section class="cta-band"><div class="wrap cta-band-grid"><div><h2>Complex cargo.<br><em>Considered plan.</em></h2><p>Route-surveyed. Permit-managed. Escorted.<br>Tell us what needs to move.</p></div><a class="button orange" href="<?php echo $base_path; ?>contact.php">Get a quote <svg class="icon"><use href="#i-ne"/></svg></a></div></section>
</main>

<?php
require_once __DIR__ . '/../includes/footer.php';
?>
