<?php
$page_title = 'Fleet & Infrastructure | 500+ Owned Vehicles — Ashwini Logistics Solutions';
$page_description = 'Explore Ashwini Logistics fleet and infrastructure: 500+ company-owned GPS-tracked vehicles, dedicated maintenance workshops, and strategic hubs across India.';
$current_page = 'fleet';

require_once __DIR__ . '/includes/header.php';
?>

<main id="main">
<section class="page-hero">
<div class="wrap">
<span class="mini-label">FLEET &amp; INFRASTRUCTURE</span>
<h1>Capacity we control.<br><b>500+ owned vehicles.</b></h1>
<p class="hero-sub">Direct responsibility from the wheels to the steering. Our company-owned fleet and strategic maintenance infrastructure ensure predictable schedules and absolute accountability.</p>
</div>
</section>

<!-- Proof Stats -->
<section class="proof">
<div class="wrap proof-grid">
<div class="proof-intro"><span class="eyebrow">BUILT FOR SCALE</span><p>Engineered for high-volume corridors and sensitive industrial freight.</p></div>
<div class="stat"><strong>500<span>+</span></strong><span>OWNED FLEET UNITS</span></div>
<div class="stat"><strong>100<span>%</span></strong><span>GTROPY GPS EQUIPPED</span></div>
<div class="stat"><strong>24<span>/7</span></strong><span>MAINTENANCE WORKSHOPS</span></div>
</div>
</section>

<!-- Fleet Categories -->
<section class="section">
<div class="wrap">
<div class="intro-heading" style="margin-bottom: 40px;">
    <h2>Diverse fleet capacity<br><span>matched to your cargo demands.</span></h2>
    <div class="intro-copy">
        <p>Whether moving high-speed FMCG goods, sensitive pharmaceuticals, heavy industrial project machinery or bulk liquids, our diversified fleet delivers the right vehicle for every requirement.</p>
    </div>
</div>

<div class="solutions-grid">
    <article class="sol-card">
        <div class="sol-card-body">
            <span class="mini-label">LONG-HAUL FREIGHT</span>
            <h3>Multi-Axle &amp; Heavy Commercial Vehicles</h3>
            <p>High-capacity 10-wheel, 12-wheel, and 14-wheel multi-axle trucks designed for non-stop interstate linehauls with maximum payload efficiency.</p>
            <ul style="margin: 12px 0 0 18px; color: #57606a; font-size: 14px;">
                <li>Payloads up to 25–35 MT</li>
                <li>All-weather sealed bodies</li>
                <li>Dual drivers for express corridors</li>
            </ul>
        </div>
    </article>

    <article class="sol-card">
        <div class="sol-card-body">
            <span class="mini-label">CONTAINER LOGISTICS</span>
            <h3>Port &amp; Domestic Container Trailers</h3>
            <p>Specialized skeletals and flatbed trailers operating 24/7 between JNPT/Nhava Sheva, Mundra, Chennai and inland CFS depots.</p>
            <ul style="margin: 12px 0 0 18px; color: #57606a; font-size: 14px;">
                <li>20ft, 40ft &amp; High-Cube trailers</li>
                <li>Twist-lock safety certification</li>
                <li>Dedicated port clearance desks</li>
            </ul>
        </div>
    </article>

    <article class="sol-card">
        <div class="sol-card-body">
            <span class="mini-label">PROJECT CARGO</span>
            <h3>Hydraulic Axles &amp; Low-Bed Trailers</h3>
            <p>Heavy-duty multi-axle modular hydraulic trailers for Over-Dimensional Cargo (ODC), plant machinery, transformers and turbines.</p>
            <ul style="margin: 12px 0 0 18px; color: #57606a; font-size: 14px;">
                <li>Capacities up to 150+ MT</li>
                <li>Route survey and escort support</li>
                <li>Permit &amp; civil clearance management</li>
            </ul>
        </div>
    </article>

    <article class="sol-card">
        <div class="sol-card-body">
            <span class="mini-label">BULK LIQUIDS</span>
            <h3>Dedicated Chemical &amp; Food-Grade Tankers</h3>
            <p>Insulated and stainless-steel tankers engineered for chemical manufacturers, edible oil brands, and liquid raw materials.</p>
            <ul style="margin: 12px 0 0 18px; color: #57606a; font-size: 14px;">
                <li>SS304 / SS316 &amp; MS compartments</li>
                <li>Pressure-tested safety valves</li>
                <li>Certified cleaning protocols</li>
            </ul>
        </div>
    </article>
</div>

<!-- Facilities & Workshops Gallery -->
<div style="margin-top: 80px;">
    <div style="margin-bottom: 30px;">
        <span class="mini-label">MAINTENANCE &amp; HUB INFRASTRUCTURE</span>
        <h2 style="font-size: 28px; margin: 0; color: #102a38;">In-House Workshops &amp; Operating Facilities</h2>
        <p style="color: #57606a; margin-top: 8px;">Zero reliance on external repair delays. Our dedicated workshop facilities conduct regular fitness inspections, tyre balancing and engine diagnostics.</p>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
        <div style="border-radius: 8px; overflow: hidden; border: 1px solid #e1e4e8; background: #fff;">
            <img src="<?php echo $base_path; ?>assets/images/facility/facility.jpg" alt="Ashwini Logistics Hub Facility" style="width: 100%; height: 220px; object-fit: cover;">
            <div style="padding: 16px;">
                <h4 style="margin: 0 0 6px; font-size: 16px; color: #102a38;">Central Operating Hub</h4>
                <p style="margin: 0; font-size: 13px; color: #57606a;">Strategic yard handling daily vehicle dispatches and driver crew briefings.</p>
            </div>
        </div>

        <div style="border-radius: 8px; overflow: hidden; border: 1px solid #e1e4e8; background: #fff;">
            <img src="<?php echo $base_path; ?>assets/images/facility/facility-inside.jpg" alt="Ashwini Logistics Workshop" style="width: 100%; height: 220px; object-fit: cover;">
            <div style="padding: 16px;">
                <h4 style="margin: 0 0 6px; font-size: 16px; color: #102a38;">Dedicated In-House Workshop</h4>
                <p style="margin: 0; font-size: 13px; color: #57606a;">Full-service bays equipped for preventive maintenance, spare parts and tyre management.</p>
            </div>
        </div>

        <div style="border-radius: 8px; overflow: hidden; border: 1px solid #e1e4e8; background: #fff;">
            <img src="<?php echo $base_path; ?>assets/images/facility/facility-landscape.jpg" alt="Logistics Park Facility" style="width: 100%; height: 220px; object-fit: cover;">
            <div style="padding: 16px;">
                <h4 style="margin: 0 0 6px; font-size: 16px; color: #102a38;">Transit Staging Yards</h4>
                <p style="margin: 0; font-size: 13px; color: #57606a;">Secure, paved parking and transshipment aprons across prime freight corridors.</p>
            </div>
        </div>
    </div>
</div>

<!-- Telematics Banner -->
<div style="margin-top: 60px; background: #102a38; color: #ffffff; border-radius: 12px; padding: 40px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 24px;">
    <div style="max-width: 600px;">
        <span class="mini-label" style="color: #ff6a00;">LIVE TELEMATICS</span>
        <h3 style="color: #ffffff; font-size: 24px; margin: 8px 0 12px;">Powered by Gtropy Fleet GPS &amp; CTYF ERP</h3>
        <p style="color: #cbd5e1; font-size: 14px; margin: 0; line-height: 1.6;">
            Every single truck in our fleet sends continuous telematics pings. Speed monitoring, route adherence, geofencing and instant SOS alerts guarantee maximum cargo safety.
        </p>
    </div>
    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="tracking.php" class="button orange" style="padding: 12px 24px;">Track a Consignment <svg class="icon"><use href="#i-ne"/></svg></a>
        <a href="contact.php" class="button" style="background: transparent; border: 1px solid #fff; color: #fff; padding: 12px 24px;">Request Fleet Capacity</a>
    </div>
</div>

</div>
</section>
</main>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
